# Minecraft AI Control Mod

A Minecraft Forge mod that introduces AI-controlled entities that can be commanded through a web interface.

## Features

- Spawn AI-controlled entities in the Minecraft world
- Web interface for sending commands to AI entities
- Real-time game state updates in the web interface
- Natural language processing with OpenAI integration
- Voice command capabilities

## Usage

1. Install the mod in your Minecraft Forge server
2. Use the `/spawnAI` command to spawn an AI entity
3. Access the web interface at `http://localhost:5000`
4. Send commands to the AI entity through the web interface

## Commands

The AI entity can understand the following commands:

- `move x y z` - Move to specific coordinates
- `move forward` - Move forward in the direction the entity is facing
- `look north/south/east/west/up/down` - Look in a specific direction
- `look x y z` - Look at specific coordinates
- `say [message]` - Say a message in the chat
- `jump` - Jump
- `attack` - Attack nearby entities
- `use` - Use the item in hand or interact with blocks
- `stop` - Stop all movement

## OpenAI Integration

To enable OpenAI integration, set the `OPENAI_API_KEY` environment variable before starting the Minecraft server.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Credits

Developed by the AIControlMod Team