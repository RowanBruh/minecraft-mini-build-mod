# AIControl Mod - Quick Start Guide

## Getting Started in 5 Minutes

### 1. Install Prerequisites
- Minecraft 1.21.5
- Forge 42.0.1+
- Java 17+

### 2. Install the Mod
- Place the compiled JAR file in your Minecraft mods folder
- If you need to build it yourself, run `./gradlew build` in the mod directory

### 3. Set Up the Web Server
- Install Node.js
- Go to web-server folder
- Run `npm install`
- Add OpenAI API key to .env file: `OPENAI_API_KEY=your_key_here`

### 4. Launch and Play
- Start Minecraft with Forge
- Enter any world
- Type `/spawnai` in the chat
- Open the web address shown in chat
- Log in with:
  - Username: `admin`
  - Password: `admin`

### 5. Control Your AI
- Use the web interface to send commands to your AI
- View AI status and location
- Use voice commands if enabled

For detailed instructions, see the full installation guide.