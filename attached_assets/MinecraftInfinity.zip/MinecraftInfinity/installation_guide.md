# AIControl Mod Installation Guide

## Overview
The AIControl Mod lets you spawn AI-controlled entities in Minecraft that can be managed through a web interface. This mod combines Minecraft gameplay with external AI capabilities.

## Requirements
- Minecraft 1.21.5
- Forge 42.0.1 or higher
- Java 17 or higher
- OpenAI API key (for AI features)

## Installation Steps

### 1. Install Minecraft Forge
1. Download Forge installer for Minecraft 1.21.5 from [Forge's official website](https://files.minecraftforge.net/)
2. Run the installer and select "Install client"
3. Wait for installation to complete

### 2. Install the AIControl Mod
1. Locate your Minecraft mods folder:
   - Windows: `%APPDATA%\.minecraft\mods`
   - Mac: `~/Library/Application Support/minecraft/mods`
   - Linux: `~/.minecraft/mods`
2. Extract the contents of this zip file into a new folder
3. Place the compiled JAR file (after building) into your Minecraft mods folder

### 3. Building the Mod (For Developers)
1. Extract the zip file to a development directory
2. Open a terminal or command prompt in the extracted directory
3. Run `./gradlew build` (Linux/Mac) or `gradlew.bat build` (Windows)
4. The compiled JAR file will be in `build/libs/`

### 4. Setting Up the Web Server
1. Install Node.js if you don't have it already
2. Navigate to the `web-server` directory
3. Run `npm install` to install dependencies
4. Set your OpenAI API key:
   - Create a `.env` file in the web-server directory
   - Add the line: `OPENAI_API_KEY=your_api_key_here`

### 5. Starting the Game
1. Launch Minecraft with the Forge profile
2. Create a new world or load an existing one
3. Use the command `/spawnai` in-game to spawn an AI entity and start the web server
4. The server URL will be displayed in chat - open it in your web browser

### 6. Web Interface
1. Default admin login:
   - Username: `admin`
   - Password: `admin`
2. Change the default password immediately for security

## Troubleshooting
- If the web server doesn't start, check Minecraft logs for errors
- If AI responses don't work, verify your OpenAI API key is correctly set
- For other issues, check the Minecraft Forge log files

## License
This mod is distributed under the MIT License. See LICENSE file for details.