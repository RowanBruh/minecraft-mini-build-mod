package com.aicontrol.server;

import com.aicontrol.AIControlMod;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.SocketException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Enumeration;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Manages the web server for AI control
 */
public class WebServerManager {
    private static final int DEFAULT_PORT = 5000;
    private Process serverProcess;
    private final AtomicBoolean serverRunning = new AtomicBoolean(false);
    private String serverUrl;
    
    /**
     * Start the web server if it's not already running
     * 
     * @return The URL to access the web server
     */
    public String startServer() {
        if (serverRunning.get()) {
            return serverUrl;
        }
        
        try {
            // Find an available port
            int port = findAvailablePort();
            AIControlMod.LOGGER.info("Starting web server on port {}", port);
            
            // Get the path to the Node.js server script
            String serverPath = getServerPath();
            
            // Start the Node.js process
            ProcessBuilder processBuilder = new ProcessBuilder("node", serverPath);
            processBuilder.environment().put("PORT", String.valueOf(port));
            processBuilder.redirectErrorStream(true);
            
            // Start the process
            serverProcess = processBuilder.start();
            
            // Read the output for logging
            new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(serverProcess.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        AIControlMod.LOGGER.info("[AI WebServer] {}", line);
                    }
                } catch (IOException e) {
                    AIControlMod.LOGGER.error("Error reading web server output", e);
                }
            }).start();
            
            // Set server running
            serverRunning.set(true);
            
            // Get server URL
            serverUrl = "http://" + getLocalIP() + ":" + port;
            AIControlMod.LOGGER.info("Web server started at {}", serverUrl);
            
            return serverUrl;
        } catch (IOException e) {
            AIControlMod.LOGGER.error("Error starting web server", e);
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Stop the web server if it's running
     */
    public void stopServer() {
        if (!serverRunning.get() || serverProcess == null) {
            return;
        }
        
        AIControlMod.LOGGER.info("Stopping web server");
        
        try {
            // Destroy the process
            serverProcess.destroy();
            
            // Wait for it to exit
            if (serverProcess.waitFor() == 0) {
                AIControlMod.LOGGER.info("Web server stopped successfully");
            } else {
                AIControlMod.LOGGER.warn("Web server process exited with code {}", serverProcess.exitValue());
            }
        } catch (InterruptedException e) {
            AIControlMod.LOGGER.error("Error stopping web server", e);
        } finally {
            serverRunning.set(false);
            serverProcess = null;
        }
    }
    
    /**
     * Find an available port to use
     * 
     * @return An available port number
     * @throws IOException If no port is available
     */
    private int findAvailablePort() throws IOException {
        try (ServerSocket socket = new ServerSocket(0)) {
            socket.setReuseAddress(true);
            return socket.getLocalPort();
        } catch (IOException e) {
            // If we can't find a random port, try the default
            try (ServerSocket socket = new ServerSocket(DEFAULT_PORT)) {
                socket.setReuseAddress(true);
                return DEFAULT_PORT;
            } catch (IOException ex) {
                throw new IOException("No available ports for web server", ex);
            }
        }
    }
    
    /**
     * Get the path to the Node.js server script
     * 
     * @return The path to the server script
     */
    private String getServerPath() {
        // Get the Minecraft game directory
        File gameDir = new File(".").getAbsoluteFile();
        
        // Create the web-server directory path
        Path serverPath = Paths.get(gameDir.getPath(), "web-server", "server.js");
        
        return serverPath.toString();
    }
    
    /**
     * Get the local IP address to use for the server URL
     * 
     * @return The local IP address
     */
    private String getLocalIP() {
        try {
            // Try to get a non-localhost IP
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface networkInterface = interfaces.nextElement();
                if (networkInterface.isLoopback() || !networkInterface.isUp()) {
                    continue;
                }
                
                Enumeration<InetAddress> addresses = networkInterface.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress address = addresses.nextElement();
                    if (address.isLinkLocalAddress() || address.isLoopbackAddress()) {
                        continue;
                    }
                    return address.getHostAddress();
                }
            }
        } catch (SocketException e) {
            AIControlMod.LOGGER.error("Error getting local IP", e);
        }
        
        // Fallback to localhost
        return "localhost";
    }
}