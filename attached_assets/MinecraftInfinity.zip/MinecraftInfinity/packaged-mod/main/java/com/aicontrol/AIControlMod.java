package com.aicontrol;

import com.aicontrol.commands.SpawnAICommand;
import com.aicontrol.server.WebServerManager;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(AIControlMod.MOD_ID)
public class AIControlMod {
    public static final String MOD_ID = "aicontrol";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);
    
    // Instance of the web server manager
    private WebServerManager webServerManager;
    
    // Singleton instance of the mod
    private static AIControlMod instance;
    
    public AIControlMod() {
        // Register mod setup method
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::setup);
        
        // Register ourselves for server and other game events
        MinecraftForge.EVENT_BUS.register(this);
        
        // Set instance
        instance = this;
        
        LOGGER.info("AI Control Mod initialized");
    }
    
    private void setup(final FMLCommonSetupEvent event) {
        LOGGER.info("AI Control Mod setup starting");
        
        // Initialize web server manager
        webServerManager = new WebServerManager();
        
        LOGGER.info("AI Control Mod setup complete");
    }
    
    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        LOGGER.info("Registering commands for AI Control Mod");
        
        // Register the /spawnai command
        SpawnAICommand.register(event.getDispatcher());
    }
    
    /**
     * Start the web server if it's not already running
     * 
     * @return The URL to access the web server
     */
    public String startWebServer() {
        return webServerManager.startServer();
    }
    
    /**
     * Stop the web server if it's running
     */
    public void stopWebServer() {
        webServerManager.stopServer();
    }
    
    /**
     * Get the singleton instance of the mod
     * 
     * @return The mod instance
     */
    public static AIControlMod getInstance() {
        return instance;
    }
}