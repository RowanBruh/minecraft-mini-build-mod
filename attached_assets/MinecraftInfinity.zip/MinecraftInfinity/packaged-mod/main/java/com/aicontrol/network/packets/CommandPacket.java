package com.aicontrol.network.packets;

import com.aicontrol.AIControlMod;
import com.aicontrol.entity.AIPlayerEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

/**
 * Packet for sending commands to AI entities
 */
public class CommandPacket {
    private String command;
    private String arguments;
    private UUID targetEntityUUID;
    
    /**
     * Default constructor
     */
    public CommandPacket() {
        this.command = "";
        this.arguments = "";
        this.targetEntityUUID = null;
    }
    
    /**
     * Constructor with parameters
     * 
     * @param command The command
     * @param arguments The arguments
     * @param targetEntityUUID The target entity UUID
     */
    public CommandPacket(String command, String arguments, UUID targetEntityUUID) {
        this.command = command;
        this.arguments = arguments;
        this.targetEntityUUID = targetEntityUUID;
    }
    
    /**
     * Encode the packet
     * 
     * @param buf The buffer to write to
     */
    public void encode(FriendlyByteBuf buf) {
        buf.writeUtf(command);
        buf.writeUtf(arguments);
        buf.writeBoolean(targetEntityUUID != null);
        if (targetEntityUUID != null) {
            buf.writeUUID(targetEntityUUID);
        }
    }
    
    /**
     * Decode the packet
     * 
     * @param buf The buffer to read from
     * @return The decoded packet
     */
    public static CommandPacket decode(FriendlyByteBuf buf) {
        CommandPacket packet = new CommandPacket();
        
        packet.command = buf.readUtf();
        packet.arguments = buf.readUtf();
        
        if (buf.readBoolean()) {
            packet.targetEntityUUID = buf.readUUID();
        }
        
        return packet;
    }
    
    /**
     * Handle the packet
     * 
     * @param supplier The network event supplier
     * @return True if the packet was handled
     */
    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        
        context.enqueueWork(() -> {
            // This packet is sent from the client to the server
            // The client is forwarding a command from the web interface
            
            // Get the server player who sent the packet
            ServerPlayer player = context.getSender();
            
            if (player == null) {
                return;
            }
            
            // Get the server level
            ServerLevel level = player.getLevel();
            
            // Find the target entity
            if (targetEntityUUID != null) {
                Entity entity = level.getEntity(targetEntityUUID);
                
                if (entity instanceof AIPlayerEntity) {
                    AIPlayerEntity aiPlayer = (AIPlayerEntity) entity;
                    
                    // Log the command
                    AIControlMod.LOGGER.info("Executing command for AI entity: {} {}", command, arguments);
                    
                    // Execute the command
                    aiPlayer.handleCommand(command, arguments);
                }
            }
        });
        
        context.setPacketHandled(true);
        return true;
    }
    
    /**
     * Get the command
     * 
     * @return The command
     */
    public String getCommand() {
        return command;
    }
    
    /**
     * Get the arguments
     * 
     * @return The arguments
     */
    public String getArguments() {
        return arguments;
    }
    
    /**
     * Get the target entity UUID
     * 
     * @return The target entity UUID
     */
    public UUID getTargetEntityUUID() {
        return targetEntityUUID;
    }
}