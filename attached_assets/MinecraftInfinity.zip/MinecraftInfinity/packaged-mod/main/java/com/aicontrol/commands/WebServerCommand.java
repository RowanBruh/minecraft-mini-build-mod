package com.aicontrol.commands;

import com.aicontrol.AIControlMod;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;

/**
 * Command to control the web server
 */
public class WebServerCommand {
    /**
     * Start the web server
     * 
     * @param source The command source
     * @return The command result
     */
    public static int startServer(CommandSourceStack source) {
        try {
            if (AIControlMod.isWebServerRunning()) {
                source.sendFailure(Component.literal("Web server is already running on port " + 
                        AIControlMod.getWebServerPort()));
                return 0;
            }
            
            boolean success = AIControlMod.startWebServer();
            
            if (success) {
                source.sendSuccess(
                        () -> Component.literal("Web server started on port " + AIControlMod.getWebServerPort()),
                        true);
                return 1;
            } else {
                source.sendFailure(Component.literal("Failed to start web server"));
                return 0;
            }
        } catch (Exception e) {
            AIControlMod.LOGGER.error("Error starting web server", e);
            source.sendFailure(Component.literal("Error: " + e.getMessage()));
            return 0;
        }
    }
    
    /**
     * Stop the web server
     * 
     * @param source The command source
     * @return The command result
     */
    public static int stopServer(CommandSourceStack source) {
        try {
            if (!AIControlMod.isWebServerRunning()) {
                source.sendFailure(Component.literal("Web server is not running"));
                return 0;
            }
            
            AIControlMod.stopWebServer();
            
            source.sendSuccess(() -> Component.literal("Web server stopped"), true);
            return 1;
        } catch (Exception e) {
            AIControlMod.LOGGER.error("Error stopping web server", e);
            source.sendFailure(Component.literal("Error: " + e.getMessage()));
            return 0;
        }
    }
    
    /**
     * Get the status of the web server
     * 
     * @param source The command source
     * @return The command result
     */
    public static int getStatus(CommandSourceStack source) {
        try {
            if (AIControlMod.isWebServerRunning()) {
                source.sendSuccess(
                        () -> Component.literal("Web server is running on port " + AIControlMod.getWebServerPort()),
                        false);
            } else {
                source.sendSuccess(() -> Component.literal("Web server is not running"), false);
            }
            
            return 1;
        } catch (Exception e) {
            AIControlMod.LOGGER.error("Error getting web server status", e);
            source.sendFailure(Component.literal("Error: " + e.getMessage()));
            return 0;
        }
    }
}