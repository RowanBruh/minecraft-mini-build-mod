package com.aicontrol.network;

import com.aicontrol.AIControlMod;
import com.aicontrol.network.packets.GameStatePacket;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.CompletableFuture;

/**
 * Handles WebSocket communication with the web server
 */
public class WebSocketHandler {
    // Base URL for the web server
    private static String baseUrl = "http://localhost:5000";
    
    /**
     * Set the base URL for the web server
     * 
     * @param url The base URL
     */
    public static void setBaseUrl(String url) {
        baseUrl = url;
    }
    
    /**
     * Send a packet to all web clients
     * 
     * @param packet The packet to send
     */
    public static void sendToWebClients(GameStatePacket packet) {
        if (!AIControlMod.isWebServerRunning()) {
            return;
        }
        
        // Send the packet asynchronously to avoid blocking the main thread
        CompletableFuture.runAsync(() -> {
            try {
                // Convert the packet to a JSON string
                Map<String, Object> payload = new HashMap<>();
                payload.put("position", new double[]{packet.getX(), packet.getY(), packet.getZ()});
                payload.put("health", packet.getHealth());
                payload.put("maxHealth", packet.getMaxHealth());
                payload.put("dimension", packet.getDimension());
                payload.put("biome", packet.getBiome());
                payload.put("time", packet.getTime());
                payload.put("weather", packet.getWeather());
                payload.put("aiStatus", packet.getAiStatus());
                payload.put("important", packet.isImportant());
                
                if (packet.getMessage() != null) {
                    payload.put("message", packet.getMessage());
                }
                
                if (packet.getLastCommand() != null) {
                    payload.put("lastCommand", packet.getLastCommand());
                }
                
                // Convert the map to JSON
                String json = convertMapToJson(payload);
                
                // Send the payload to the web server
                sendJsonToWebServer("/api/gamestate", json);
            } catch (Exception e) {
                AIControlMod.LOGGER.error("Error sending packet to web clients", e);
            }
        });
    }
    
    /**
     * Send a JSON payload to the web server
     * 
     * @param endpoint The endpoint to send to
     * @param json The JSON payload
     * @throws IOException If an error occurs
     */
    private static void sendJsonToWebServer(String endpoint, String json) throws IOException {
        // Create the URL
        URL url = new URL(baseUrl + endpoint);
        
        // Open a connection
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        
        // Set the request method
        connection.setRequestMethod("POST");
        
        // Set the content type
        connection.setRequestProperty("Content-Type", "application/json");
        
        // Enable output
        connection.setDoOutput(true);
        
        // Write the payload
        connection.getOutputStream().write(json.getBytes(StandardCharsets.UTF_8));
        
        // Get the response code
        int responseCode = connection.getResponseCode();
        
        // Check if the request was successful
        if (responseCode != 200) {
            AIControlMod.LOGGER.error("Error sending data to web server: " + responseCode);
        }
        
        // Disconnect
        connection.disconnect();
    }
    
    /**
     * Convert a map to a JSON string
     * 
     * @param map The map to convert
     * @return The JSON string
     */
    private static String convertMapToJson(Map<String, Object> map) {
        StringBuilder json = new StringBuilder();
        json.append("{");
        
        boolean isFirst = true;
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (!isFirst) {
                json.append(",");
            }
            isFirst = false;
            
            json.append("\"").append(entry.getKey()).append("\":");
            Object value = entry.getValue();
            
            if (value == null) {
                json.append("null");
            } else if (value instanceof String) {
                json.append("\"").append(escapeJsonString((String) value)).append("\"");
            } else if (value instanceof Boolean) {
                json.append(value);
            } else if (value instanceof Number) {
                json.append(value);
            } else if (value instanceof double[]) {
                double[] array = (double[]) value;
                json.append("[");
                for (int i = 0; i < array.length; i++) {
                    if (i > 0) {
                        json.append(",");
                    }
                    json.append(array[i]);
                }
                json.append("]");
            } else {
                json.append("\"").append(escapeJsonString(value.toString())).append("\"");
            }
        }
        
        json.append("}");
        return json.toString();
    }
    
    /**
     * Escape a string for JSON
     * 
     * @param input The string to escape
     * @return The escaped string
     */
    private static String escapeJsonString(String input) {
        if (input == null) {
            return "";
        }
        
        StringBuilder escaped = new StringBuilder();
        for (char c : input.toCharArray()) {
            switch (c) {
                case '"':
                    escaped.append("\\\"");
                    break;
                case '\\':
                    escaped.append("\\\\");
                    break;
                case '\b':
                    escaped.append("\\b");
                    break;
                case '\f':
                    escaped.append("\\f");
                    break;
                case '\n':
                    escaped.append("\\n");
                    break;
                case '\r':
                    escaped.append("\\r");
                    break;
                case '\t':
                    escaped.append("\\t");
                    break;
                default:
                    if (c < ' ') {
                        escaped.append(String.format("\\u%04x", (int) c));
                    } else {
                        escaped.append(c);
                    }
            }
        }
        
        return escaped.toString();
    }
}