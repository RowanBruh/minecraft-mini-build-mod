package com.aicontrol.network.packets;

import com.aicontrol.AIControlMod;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Packet for sending game state information to clients
 */
public class GameStatePacket {
    private double x;
    private double y;
    private double z;
    private float health;
    private float maxHealth;
    private String dimension;
    private String biome;
    private String time;
    private String weather;
    private String message;
    private String lastCommand;
    private String aiStatus;
    private boolean important;
    
    /**
     * Default constructor
     */
    public GameStatePacket() {
        this.x = 0;
        this.y = 0;
        this.z = 0;
        this.health = 0;
        this.maxHealth = 0;
        this.dimension = "";
        this.biome = "";
        this.time = "";
        this.weather = "";
        this.message = null;
        this.lastCommand = null;
        this.aiStatus = "Ready";
        this.important = false;
    }
    
    /**
     * Set the position of the entity
     * 
     * @param x The x coordinate
     * @param y The y coordinate
     * @param z The z coordinate
     */
    public void setPosition(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    /**
     * Set the health of the entity
     * 
     * @param health The current health
     * @param maxHealth The maximum health
     */
    public void setHealth(float health, float maxHealth) {
        this.health = health;
        this.maxHealth = maxHealth;
    }
    
    /**
     * Set the dimension of the entity
     * 
     * @param dimension The dimension
     */
    public void setDimension(String dimension) {
        this.dimension = dimension;
    }
    
    /**
     * Set the biome of the entity
     * 
     * @param biome The biome
     */
    public void setBiome(String biome) {
        this.biome = biome;
    }
    
    /**
     * Set the time of day
     * 
     * @param time The time of day
     */
    public void setTime(String time) {
        this.time = time;
    }
    
    /**
     * Set the weather
     * 
     * @param weather The weather
     */
    public void setWeather(String weather) {
        this.weather = weather;
    }
    
    /**
     * Set a message for the client
     * 
     * @param message The message
     */
    public void setMessage(String message) {
        this.message = message;
    }
    
    /**
     * Set the last command executed
     * 
     * @param lastCommand The last command
     */
    public void setLastCommand(String lastCommand) {
        this.lastCommand = lastCommand;
    }
    
    /**
     * Set the AI status
     * 
     * @param aiStatus The AI status
     */
    public void setAiStatus(String aiStatus) {
        this.aiStatus = aiStatus;
    }
    
    /**
     * Set whether this update is important
     * 
     * @param important Whether this update is important
     */
    public void setImportant(boolean important) {
        this.important = important;
    }
    
    /**
     * Get the x coordinate
     * 
     * @return The x coordinate
     */
    public double getX() {
        return x;
    }
    
    /**
     * Get the y coordinate
     * 
     * @return The y coordinate
     */
    public double getY() {
        return y;
    }
    
    /**
     * Get the z coordinate
     * 
     * @return The z coordinate
     */
    public double getZ() {
        return z;
    }
    
    /**
     * Get the current health
     * 
     * @return The current health
     */
    public float getHealth() {
        return health;
    }
    
    /**
     * Get the maximum health
     * 
     * @return The maximum health
     */
    public float getMaxHealth() {
        return maxHealth;
    }
    
    /**
     * Get the dimension
     * 
     * @return The dimension
     */
    public String getDimension() {
        return dimension;
    }
    
    /**
     * Get the biome
     * 
     * @return The biome
     */
    public String getBiome() {
        return biome;
    }
    
    /**
     * Get the time of day
     * 
     * @return The time of day
     */
    public String getTime() {
        return time;
    }
    
    /**
     * Get the weather
     * 
     * @return The weather
     */
    public String getWeather() {
        return weather;
    }
    
    /**
     * Get the message
     * 
     * @return The message
     */
    public String getMessage() {
        return message;
    }
    
    /**
     * Get the last command executed
     * 
     * @return The last command
     */
    public String getLastCommand() {
        return lastCommand;
    }
    
    /**
     * Get the AI status
     * 
     * @return The AI status
     */
    public String getAiStatus() {
        return aiStatus;
    }
    
    /**
     * Check if this update is important
     * 
     * @return True if this update is important
     */
    public boolean isImportant() {
        return important;
    }
    
    /**
     * Encode the packet
     * 
     * @param buf The buffer to write to
     */
    public void encode(FriendlyByteBuf buf) {
        buf.writeDouble(x);
        buf.writeDouble(y);
        buf.writeDouble(z);
        buf.writeFloat(health);
        buf.writeFloat(maxHealth);
        buf.writeUtf(dimension);
        buf.writeUtf(biome);
        buf.writeUtf(time);
        buf.writeUtf(weather);
        
        // Write the message if it exists
        buf.writeBoolean(message != null);
        if (message != null) {
            buf.writeUtf(message);
        }
        
        // Write the last command if it exists
        buf.writeBoolean(lastCommand != null);
        if (lastCommand != null) {
            buf.writeUtf(lastCommand);
        }
        
        buf.writeUtf(aiStatus);
        buf.writeBoolean(important);
    }
    
    /**
     * Decode the packet
     * 
     * @param buf The buffer to read from
     * @return The decoded packet
     */
    public static GameStatePacket decode(FriendlyByteBuf buf) {
        GameStatePacket packet = new GameStatePacket();
        
        packet.x = buf.readDouble();
        packet.y = buf.readDouble();
        packet.z = buf.readDouble();
        packet.health = buf.readFloat();
        packet.maxHealth = buf.readFloat();
        packet.dimension = buf.readUtf();
        packet.biome = buf.readUtf();
        packet.time = buf.readUtf();
        packet.weather = buf.readUtf();
        
        // Read the message if it exists
        if (buf.readBoolean()) {
            packet.message = buf.readUtf();
        }
        
        // Read the last command if it exists
        if (buf.readBoolean()) {
            packet.lastCommand = buf.readUtf();
        }
        
        packet.aiStatus = buf.readUtf();
        packet.important = buf.readBoolean();
        
        return packet;
    }
    
    /**
     * Handle the packet
     * 
     * @param supplier The network event supplier
     * @return True if the packet was handled
     */
    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        
        context.enqueueWork(() -> {
            // This packet is sent from the server to the client
            // It will be forwarded to the web server by the client
            // Nothing to do on the client side yet
            AIControlMod.LOGGER.debug("Received game state packet on client");
        });
        
        context.setPacketHandled(true);
        return true;
    }
}