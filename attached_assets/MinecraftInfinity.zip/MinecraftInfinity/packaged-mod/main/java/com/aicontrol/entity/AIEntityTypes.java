package com.aicontrol.entity;

import com.aicontrol.AIControlMod;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Registry for AI entity types
 */
public class AIEntityTypes {
    // Create the deferred register for entity types
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = 
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AIControlMod.MOD_ID);
    
    // Register the AI player entity
    public static final RegistryObject<EntityType<AIPlayerEntity>> AI_PLAYER = 
            ENTITY_TYPES.register("ai_player", 
                    () -> EntityType.Builder.<AIPlayerEntity>of(AIPlayerEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.8F) // Standard player size
                    .clientTrackingRange(10)
                    .updateInterval(3)
                    .build("ai_player"));
    
    /**
     * Register entity types with the event bus
     * 
     * @param eventBus The event bus
     */
    public static void register(IEventBus eventBus) {
        ENTITY_TYPES.register(eventBus);
    }
}