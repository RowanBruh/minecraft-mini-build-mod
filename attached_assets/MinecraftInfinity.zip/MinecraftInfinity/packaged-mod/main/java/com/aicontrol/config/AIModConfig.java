package com.aicontrol.config;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

/**
 * Configuration for the AI Control mod
 */
public class AIModConfig {
    /**
     * Common configuration
     */
    public static class Common {
        // Web server port
        public final ForgeConfigSpec.IntValue webServerPort;
        
        // Maximum AI entities per server
        public final ForgeConfigSpec.IntValue maxAIEntities;
        
        // AI entity despawn time in minutes (0 = never)
        public final ForgeConfigSpec.IntValue aiEntityDespawnTime;
        
        // Enable OpenAI integration
        public final ForgeConfigSpec.BooleanValue enableOpenAI;
        
        // Enable voice commands
        public final ForgeConfigSpec.BooleanValue enableVoiceCommands;
        
        /**
         * Constructs the common configuration
         * 
         * @param builder The config builder
         */
        public Common(ForgeConfigSpec.Builder builder) {
            builder.comment("AI Control Module Configuration");
            
            // Web server settings
            builder.push("web_server");
            
            webServerPort = builder
                    .comment("The port that the web server should listen on")
                    .worldRestart()
                    .defineInRange("webServerPort", 5000, 1024, 65535);
            
            builder.pop();
            
            // AI entity settings
            builder.push("ai_entity");
            
            maxAIEntities = builder
                    .comment("The maximum number of AI entities that can exist on the server at once")
                    .worldRestart()
                    .defineInRange("maxAIEntities", 5, 1, 100);
            
            aiEntityDespawnTime = builder
                    .comment("The time in minutes after which an AI entity will despawn (0 = never)")
                    .worldRestart()
                    .defineInRange("aiEntityDespawnTime", 30, 0, 1440);
            
            builder.pop();
            
            // AI integration settings
            builder.push("ai_integration");
            
            enableOpenAI = builder
                    .comment("Whether to enable OpenAI integration")
                    .worldRestart()
                    .define("enableOpenAI", true);
            
            enableVoiceCommands = builder
                    .comment("Whether to enable voice command processing")
                    .worldRestart()
                    .define("enableVoiceCommands", true);
            
            builder.pop();
        }
    }
    
    /**
     * Common configuration spec
     */
    public static final ForgeConfigSpec COMMON_SPEC;
    
    /**
     * Common configuration
     */
    public static final Common COMMON;
    
    static {
        final Pair<Common, ForgeConfigSpec> specPair = new ForgeConfigSpec.Builder().configure(Common::new);
        COMMON_SPEC = specPair.getRight();
        COMMON = specPair.getLeft();
    }
}