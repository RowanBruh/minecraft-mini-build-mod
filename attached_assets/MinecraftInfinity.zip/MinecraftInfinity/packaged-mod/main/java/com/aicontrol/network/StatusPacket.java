package com.aicontrol.network;

import com.aicontrol.AIControlMod;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Packet for sending AI entity status updates
 */
public class StatusPacket {
    private final int entityId;
    private final float health;
    private final double posX;
    private final double posY;
    private final double posZ;
    
    /**
     * Constructor
     * 
     * @param entityId The entity ID
     * @param health The entity health
     * @param posX The X position
     * @param posY The Y position
     * @param posZ The Z position
     */
    public StatusPacket(int entityId, float health, double posX, double posY, double posZ) {
        this.entityId = entityId;
        this.health = health;
        this.posX = posX;
        this.posY = posY;
        this.posZ = posZ;
    }
    
    /**
     * Encode the packet data
     * 
     * @param buffer The packet buffer
     */
    public void encode(PacketBuffer buffer) {
        buffer.writeInt(entityId);
        buffer.writeFloat(health);
        buffer.writeDouble(posX);
        buffer.writeDouble(posY);
        buffer.writeDouble(posZ);
    }
    
    /**
     * Decode the packet data
     * 
     * @param buffer The packet buffer
     * @return The decoded packet
     */
    public static StatusPacket decode(PacketBuffer buffer) {
        int entityId = buffer.readInt();
        float health = buffer.readFloat();
        double posX = buffer.readDouble();
        double posY = buffer.readDouble();
        double posZ = buffer.readDouble();
        
        return new StatusPacket(entityId, health, posX, posY, posZ);
    }
    
    /**
     * Handle the packet
     * 
     * @param ctx The network context
     */
    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            // This would normally update the web server with entity status
            // For demonstration purposes, we just log the status
            AIControlMod.LOGGER.debug("Status update received: entity={}, health={}, pos=[{},{},{}]",
                entityId, health, posX, posY, posZ);
        });
        
        ctx.get().setPacketHandled(true);
    }
}