package com.aicontrol.network;

import com.aicontrol.AIControlMod;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.network.NetworkRegistry;
import net.minecraftforge.fml.network.simple.SimpleChannel;

/**
 * Handles network communication for the AI Control mod
 */
public class AINetworkHandler {
    // Network protocol version
    private static final String PROTOCOL_VERSION = "1.0";
    
    // Network channel
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(AIControlMod.MOD_ID, "main"),
        () -> PROTOCOL_VERSION,
        PROTOCOL_VERSION::equals,
        PROTOCOL_VERSION::equals
    );
    
    // Packet counter for registration
    private static int packetId = 0;
    
    /**
     * Register network packets
     */
    public static void registerPackets() {
        // Register command packet
        CHANNEL.registerMessage(
            packetId++,
            CommandPacket.class,
            CommandPacket::encode,
            CommandPacket::decode,
            CommandPacket::handle
        );
        
        // Register status packet
        CHANNEL.registerMessage(
            packetId++,
            StatusPacket.class,
            StatusPacket::encode,
            StatusPacket::decode,
            StatusPacket::handle
        );
        
        AIControlMod.LOGGER.info("Network packets registered");
    }
    
    /**
     * Send a command to an AI entity
     * 
     * @param entityId The entity ID
     * @param command The command to execute
     * @param args Command arguments
     */
    public static void sendCommand(int entityId, String command, String args) {
        // This would normally send a network packet
        // For demonstration purposes, we just log the command
        AIControlMod.LOGGER.info("Sending command to entity {}: {} {}", entityId, command, args);
    }
    
    /**
     * Send the status of an AI entity
     * 
     * @param entityId The entity ID
     * @param health The entity health
     * @param posX The X position
     * @param posY The Y position
     * @param posZ The Z position
     */
    public static void sendStatus(int entityId, float health, double posX, double posY, double posZ) {
        // This would normally send a network packet
        // For demonstration purposes, we just log the status
        AIControlMod.LOGGER.info("Entity {} status: health={}, pos=[{},{},{}]", 
            entityId, health, posX, posY, posZ);
    }
}