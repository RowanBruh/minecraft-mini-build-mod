package com.aicontrol.commands;

import com.aicontrol.AIControlMod;
import com.aicontrol.entity.AIPlayerEntity;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.command.CommandSource;
import net.minecraft.command.Commands;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.event.ClickEvent;
import net.minecraft.util.text.event.HoverEvent;

/**
 * Command to spawn an AI-controlled player and start the web server for control
 */
public class SpawnAICommand {
    
    /**
     * Register the command with the dispatcher
     * 
     * @param dispatcher The command dispatcher
     */
    public static void register(CommandDispatcher<CommandSource> dispatcher) {
        dispatcher.register(
            Commands.literal("spawnai")
                .requires(source -> source.hasPermissionLevel(2)) // Require permission level 2 (op)
                .executes(context -> executeSpawnAI(context.getSource()))
        );
    }
    
    /**
     * Execute the command to spawn an AI-controlled player and start the web server
     * 
     * @param source The command source
     * @return 1 if successful, 0 if failed
     */
    private static int executeSpawnAI(CommandSource source) {
        try {
            // Get the player who executed the command
            ServerPlayerEntity player = source.asPlayer();
            
            // Start the web server
            String serverUrl = AIControlMod.getInstance().startWebServer();
            
            // Spawn AI entity
            AIPlayerEntity aiEntity = AIPlayerEntity.spawnAI(player.world, player.getPosition());
            
            if (aiEntity != null) {
                // Create clickable link to the web server
                ITextComponent linkText = new StringTextComponent("Click here to control the AI")
                    .mergeStyle(TextFormatting.GREEN, TextFormatting.UNDERLINE)
                    .modifyStyle(style -> style
                        .setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, serverUrl))
                        .setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, 
                            new StringTextComponent("Open AI Control Panel")))
                    );
                
                // Send message to player
                source.sendFeedback(new StringTextComponent("AI player spawned! "), false);
                source.sendFeedback(linkText, false);
                
                return 1;
            } else {
                // Send error message
                source.sendFeedback(
                    new StringTextComponent("Failed to spawn AI player")
                        .mergeStyle(TextFormatting.RED),
                    false
                );
                
                return 0;
            }
        } catch (CommandSyntaxException e) {
            // Send error message
            source.sendFeedback(
                new StringTextComponent("This command must be executed by a player")
                    .mergeStyle(TextFormatting.RED),
                false
            );
            
            return 0;
        } catch (Exception e) {
            // Log the error
            AIControlMod.LOGGER.error("Error executing SpawnAI command", e);
            
            // Send error message
            source.sendFeedback(
                new StringTextComponent("Error: " + e.getMessage())
                    .mergeStyle(TextFormatting.RED),
                false
            );
            
            return 0;
        }
    }
}