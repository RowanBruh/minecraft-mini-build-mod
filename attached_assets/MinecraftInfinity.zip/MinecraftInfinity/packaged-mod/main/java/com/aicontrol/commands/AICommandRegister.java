package com.aicontrol.commands;

import com.aicontrol.AIControlMod;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Registers commands for the AI Control mod
 */
@Mod.EventBusSubscriber(modid = AIControlMod.MOD_ID)
public class AICommandRegister {
    /**
     * Initialize command registration
     */
    public static void init() {
        // No initialization needed, just make sure the class is loaded
    }
    
    /**
     * Register commands
     * 
     * @param event The register commands event
     */
    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        AIControlMod.LOGGER.info("Registering AI Control commands");
        
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        
        // Register spawn AI command
        registerSpawnAICommand(dispatcher);
        
        // Register web server command
        registerWebServerCommand(dispatcher);
    }
    
    /**
     * Register the spawn AI command
     * 
     * @param dispatcher The command dispatcher
     */
    private static void registerSpawnAICommand(CommandDispatcher<CommandSourceStack> dispatcher) {
        LiteralArgumentBuilder<CommandSourceStack> spawnCommand = Commands.literal("spawnAI")
                .requires(cs -> cs.hasPermission(2)) // Require permission level 2 (op)
                .executes(context -> {
                    return SpawnAICommand.execute(context.getSource(), null);
                })
                .then(Commands.argument("name", StringArgumentType.string())
                        .executes(context -> {
                            String name = StringArgumentType.getString(context, "name");
                            return SpawnAICommand.execute(context.getSource(), name);
                        }));
        
        dispatcher.register(spawnCommand);
    }
    
    /**
     * Register the web server command
     * 
     * @param dispatcher The command dispatcher
     */
    private static void registerWebServerCommand(CommandDispatcher<CommandSourceStack> dispatcher) {
        LiteralArgumentBuilder<CommandSourceStack> webServerCommand = Commands.literal("aiwebserver")
                .requires(cs -> cs.hasPermission(2)) // Require permission level 2 (op)
                .then(Commands.literal("start")
                        .executes(context -> {
                            return WebServerCommand.startServer(context.getSource());
                        }))
                .then(Commands.literal("stop")
                        .executes(context -> {
                            return WebServerCommand.stopServer(context.getSource());
                        }))
                .then(Commands.literal("status")
                        .executes(context -> {
                            return WebServerCommand.getStatus(context.getSource());
                        }));
        
        dispatcher.register(webServerCommand);
    }
}