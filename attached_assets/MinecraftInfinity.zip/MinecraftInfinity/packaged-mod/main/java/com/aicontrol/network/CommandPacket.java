package com.aicontrol.network;

import com.aicontrol.AIControlMod;
import com.aicontrol.entity.AIPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Packet for sending commands to AI entities
 */
public class CommandPacket {
    private final int entityId;
    private final String command;
    private final String args;
    
    /**
     * Constructor
     * 
     * @param entityId The entity ID
     * @param command The command
     * @param args The command arguments
     */
    public CommandPacket(int entityId, String command, String args) {
        this.entityId = entityId;
        this.command = command;
        this.args = args;
    }
    
    /**
     * Encode the packet data
     * 
     * @param buffer The packet buffer
     */
    public void encode(PacketBuffer buffer) {
        buffer.writeInt(entityId);
        buffer.writeString(command);
        buffer.writeString(args != null ? args : "");
    }
    
    /**
     * Decode the packet data
     * 
     * @param buffer The packet buffer
     * @return The decoded packet
     */
    public static CommandPacket decode(PacketBuffer buffer) {
        int entityId = buffer.readInt();
        String command = buffer.readString();
        String args = buffer.readString();
        
        return new CommandPacket(entityId, command, args);
    }
    
    /**
     * Handle the packet
     * 
     * @param ctx The network context
     */
    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            // Get the entity
            Entity entity = ctx.get().getSender().world.getEntityByID(entityId);
            
            if (entity instanceof AIPlayerEntity) {
                // Execute the command
                ((AIPlayerEntity) entity).executeCommand(command + " " + args);
            } else {
                AIControlMod.LOGGER.warn("Command packet received for non-AI entity: {}", entityId);
            }
        });
        
        ctx.get().setPacketHandled(true);
    }
}