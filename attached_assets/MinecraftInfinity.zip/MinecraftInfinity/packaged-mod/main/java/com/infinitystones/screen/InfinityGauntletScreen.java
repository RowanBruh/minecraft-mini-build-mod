package com.infinitystones.screen;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.items.custom.InfinityGauntletItem;
import com.infinitystones.items.custom.InfinityStoneItem;
import com.infinitystones.network.ModPackets;
import com.infinitystones.network.packets.StoneAbilityC2SPacket;
import com.infinitystones.util.StoneType;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/**
 * Screen for the Infinity Gauntlet
 */
public class InfinityGauntletScreen extends AbstractContainerScreen<InfinityGauntletMenu> {
    private static final ResourceLocation TEXTURE = 
            new ResourceLocation(InfinityStonesMod.MOD_ID, "textures/gui/infinity_gauntlet.png");
    
    // Map of stone type to ability buttons
    private final Map<StoneType, Button> abilityButtons = new HashMap<>();
    
    // Snap button for all stones
    private Button snapButton;
    
    // Combined powers button
    private Button combinedPowersButton;
    
    /**
     * Constructs a new screen
     * 
     * @param menu The menu
     * @param inventory The player's inventory
     * @param title The screen title
     */
    public InfinityGauntletScreen(InfinityGauntletMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        
        this.imageWidth = 176;
        this.imageHeight = 194;
    }
    
    /**
     * Initializes the screen
     */
    @Override
    protected void init() {
        super.init();
        
        // Clear previous buttons
        abilityButtons.clear();
        
        // Individual stone ability buttons
        for (StoneType stoneType : StoneType.values()) {
            int index = stoneType.ordinal();
            int x = leftPos + 105;
            int y = topPos + 20 + (index * 18);
            
            Button button = Button.builder(
                        Component.translatable("button.infinitystones." + stoneType.getSerializedName() + "_ability"),
                        btn -> activateStoneAbility(stoneType))
                    .pos(x, y)
                    .size(60, 16)
                    .build();
            
            abilityButtons.put(stoneType, button);
            addRenderableWidget(button);
            
            // Disable buttons initially
            updateAbilityButtonState(stoneType);
        }
        
        // Snap button (requires all stones)
        snapButton = Button.builder(
                Component.translatable("button.infinitystones.snap"),
                btn -> activateSnapAbility())
                .pos(leftPos + 105, topPos + 140)
                .size(60, 20)
                .build();
        addRenderableWidget(snapButton);
        
        // Combined powers button
        combinedPowersButton = Button.builder(
                Component.translatable("button.infinitystones.combined_powers"),
                btn -> activateCombinedPowers())
                .pos(leftPos + 29, topPos + 140)
                .size(60, 20)
                .build();
        addRenderableWidget(combinedPowersButton);
        
        // Update button states
        updateSnapButtonState();
        updateCombinedButtonState();
    }
    
    /**
     * Renders the screen background
     * 
     * @param guiGraphics The GUI graphics context
     * @param mouseX The mouse X position
     * @param mouseY The mouse Y position
     * @param partialTick The partial tick
     */
    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, TEXTURE);
        
        // Draw main background
        guiGraphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);
        
        // Draw stone receptacles
        for (StoneType stoneType : StoneType.values()) {
            int index = stoneType.ordinal();
            InfinityGauntletMenu.StoneSlot slot = (InfinityGauntletMenu.StoneSlot) menu.slots.get(index);
            
            // Color tint based on stone type
            float[] color = stoneType.getColor();
            RenderSystem.setShaderColor(color[0], color[1], color[2], 0.7F);
            
            // Draw stone receptacle if empty
            if (slot.getItem().isEmpty()) {
                int slotX = slot.x - 1;
                int slotY = slot.y - 1;
                guiGraphics.blit(TEXTURE, leftPos + slotX, topPos + slotY, 176, 0, 18, 18);
            }
        }
        
        // Reset color
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }
    
    /**
     * Renders the foreground
     * 
     * @param guiGraphics The GUI graphics context
     * @param mouseX The mouse X position
     * @param mouseY The mouse Y position
     */
    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        guiGraphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, 4210752, false);
        guiGraphics.drawString(this.font, this.playerInventoryTitle, this.inventoryLabelX, this.inventoryLabelY, 4210752, false);
    }
    
    /**
     * Checks for changes and updates the screen
     */
    @Override
    public void containerTick() {
        super.containerTick();
        
        // Update button states
        for (StoneType stoneType : StoneType.values()) {
            updateAbilityButtonState(stoneType);
        }
        
        updateSnapButtonState();
        updateCombinedButtonState();
    }
    
    /**
     * Updates the state of a stone ability button
     * 
     * @param stoneType The stone type
     */
    private void updateAbilityButtonState(StoneType stoneType) {
        Button button = abilityButtons.get(stoneType);
        boolean hasStone = false;
        boolean isInfected = false;
        
        // Check if stone is in slot
        int slotIndex = stoneType.ordinal();
        ItemStack stack = menu.getStoneContainer().getItem(slotIndex);
        if (!stack.isEmpty() && stack.getItem() instanceof InfinityStoneItem stoneItem) {
            hasStone = true;
            isInfected = stoneItem.isInfected();
        }
        
        // Update button
        button.active = hasStone;
        
        // Update button text for infected stones
        if (isInfected) {
            button.setMessage(Component.translatable("button.infinitystones.infected_" + 
                    stoneType.getSerializedName() + "_ability"));
        } else {
            button.setMessage(Component.translatable("button.infinitystones." + 
                    stoneType.getSerializedName() + "_ability"));
        }
    }
    
    /**
     * Updates the state of the snap button
     */
    private void updateSnapButtonState() {
        // Check if all stones are present
        boolean allStones = true;
        boolean anyInfected = false;
        
        for (StoneType stoneType : StoneType.values()) {
            int slotIndex = stoneType.ordinal();
            ItemStack stack = menu.getStoneContainer().getItem(slotIndex);
            
            if (stack.isEmpty()) {
                allStones = false;
                break;
            } else if (stack.getItem() instanceof InfinityStoneItem stoneItem && stoneItem.isInfected()) {
                anyInfected = true;
            }
        }
        
        // Update button
        snapButton.active = allStones;
        
        // Update button text for infected stones
        if (anyInfected) {
            snapButton.setMessage(Component.translatable("button.infinitystones.infected_snap"));
        } else {
            snapButton.setMessage(Component.translatable("button.infinitystones.snap"));
        }
    }
    
    /**
     * Updates the state of the combined powers button
     */
    private void updateCombinedButtonState() {
        // Need at least 2 stones for combined powers
        int stoneCount = 0;
        boolean anyInfected = false;
        
        for (StoneType stoneType : StoneType.values()) {
            int slotIndex = stoneType.ordinal();
            ItemStack stack = menu.getStoneContainer().getItem(slotIndex);
            
            if (!stack.isEmpty()) {
                stoneCount++;
                
                if (stack.getItem() instanceof InfinityStoneItem stoneItem && stoneItem.isInfected()) {
                    anyInfected = true;
                }
            }
        }
        
        // Update button
        combinedPowersButton.active = stoneCount >= 2;
        
        // Update button text for infected stones
        if (anyInfected) {
            combinedPowersButton.setMessage(Component.translatable("button.infinitystones.infected_combined_powers"));
        } else {
            combinedPowersButton.setMessage(Component.translatable("button.infinitystones.combined_powers"));
        }
    }
    
    /**
     * Activates a stone ability
     * 
     * @param stoneType The stone type
     */
    private void activateStoneAbility(StoneType stoneType) {
        int slotIndex = stoneType.ordinal();
        ItemStack stack = menu.getStoneContainer().getItem(slotIndex);
        
        if (!stack.isEmpty() && stack.getItem() instanceof InfinityStoneItem stoneItem) {
            boolean isInfected = stoneItem.isInfected();
            
            // Send activation packet to server
            ModPackets.sendToServer(new StoneAbilityC2SPacket(stoneType, isInfected));
            
            // Close the screen
            this.minecraft.player.closeContainer();
        }
    }
    
    /**
     * Activates the snap ability
     */
    private void activateSnapAbility() {
        // Check if any stone is infected
        boolean anyInfected = false;
        
        for (StoneType stoneType : StoneType.values()) {
            int slotIndex = stoneType.ordinal();
            ItemStack stack = menu.getStoneContainer().getItem(slotIndex);
            
            if (!stack.isEmpty() && stack.getItem() instanceof InfinityStoneItem stoneItem && stoneItem.isInfected()) {
                anyInfected = true;
                break;
            }
        }
        
        // Send activation packet to server
        ModPackets.sendToServer(new StoneAbilityC2SPacket(null, anyInfected, true));
        
        // Close the screen
        this.minecraft.player.closeContainer();
    }
    
    /**
     * Activates combined powers
     */
    private void activateCombinedPowers() {
        // Determine which stones are used
        StringBuilder combinationId = new StringBuilder();
        boolean anyInfected = false;
        
        for (StoneType stoneType : StoneType.values()) {
            int slotIndex = stoneType.ordinal();
            ItemStack stack = menu.getStoneContainer().getItem(slotIndex);
            
            if (!stack.isEmpty()) {
                combinationId.append(stoneType.getSerializedName()).append("_");
                
                if (stack.getItem() instanceof InfinityStoneItem stoneItem && stoneItem.isInfected()) {
                    anyInfected = true;
                }
            }
        }
        
        // Send activation packet to server
        ModPackets.sendToServer(new StoneAbilityC2SPacket(null, anyInfected, false, combinationId.toString()));
        
        // Close the screen
        this.minecraft.player.closeContainer();
    }
}