package com.infinitystones.blocks;

import com.infinitystones.blockentities.GoogleComputerBlockEntity;
import com.infinitystones.blockentities.ModBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.network.NetworkHooks;

/**
 * Block implementation for the Google Computer
 */
public class GoogleComputerBlock extends BaseEntityBlock {
    // Direction property
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
    
    // Shapes for different orientations
    private static final VoxelShape SHAPE_NS = Shapes.box(0.0625, 0, 0.0625, 0.9375, 0.875, 0.9375);
    private static final VoxelShape SHAPE_EW = Shapes.box(0.0625, 0, 0.0625, 0.9375, 0.875, 0.9375);
    
    /**
     * Constructs a new Google Computer block
     * 
     * @param properties The block properties
     */
    public GoogleComputerBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(FACING, Direction.NORTH));
    }
    
    /**
     * Gets the render shape
     * 
     * @param state The block state
     * @return The render shape
     */
    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }
    
    /**
     * Gets the block's collision shape
     * 
     * @param state The block state
     * @param level The level
     * @param pos The block position
     * @param context The collision context
     * @return The shape
     */
    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return switch (state.getValue(FACING)) {
            case EAST, WEST -> SHAPE_EW;
            default -> SHAPE_NS;
        };
    }
    
    /**
     * Gets the state for placement
     * 
     * @param context The block place context
     * @return The block state
     */
    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState()
                .setValue(FACING, context.getHorizontalDirection().getOpposite());
    }
    
    /**
     * Rotates the block
     * 
     * @param state The block state
     * @param rotation The rotation
     * @return The rotated state
     */
    @Override
    public BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }
    
    /**
     * Mirrors the block
     * 
     * @param state The block state
     * @param mirror The mirror
     * @return The mirrored state
     */
    @Override
    public BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }
    
    /**
     * Creates the state definition
     * 
     * @param builder The state definition builder
     */
    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }
    
    /**
     * Handles block interaction
     * 
     * @param state The block state
     * @param level The level
     * @param pos The block position
     * @param player The player
     * @param hand The hand
     * @param hit The hit result
     * @return The interaction result
     */
    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide() && player instanceof ServerPlayer serverPlayer) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            
            if (blockEntity instanceof GoogleComputerBlockEntity computer) {
                NetworkHooks.openScreen(serverPlayer, computer, pos);
            }
        }
        
        return InteractionResult.sidedSuccess(level.isClientSide());
    }
    
    /**
     * Creates a block entity
     * 
     * @param pos The block position
     * @param state The block state
     * @return The block entity
     */
    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new GoogleComputerBlockEntity(pos, state);
    }
    
    /**
     * Gets a ticker for the block entity
     * 
     * @param level The level
     * @param state The block state
     * @param blockEntityType The block entity type
     * @return The ticker
     */
    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                BlockEntityType<T> blockEntityType) {
        return createTickerHelper(
                blockEntityType,
                ModBlockEntities.GOOGLE_COMPUTER.get(),
                GoogleComputerBlockEntity::tick);
    }
    
    /**
     * Handles block removal
     * 
     * @param state The block state
     * @param level The level
     * @param pos The block position
     * @param newState The new block state
     * @param isMoving Whether the block is moving
     */
    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.is(newState.getBlock())) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            
            if (blockEntity instanceof GoogleComputerBlockEntity computer) {
                GoogleComputerBlockEntity.dropContents(level, pos, computer);
            }
        }
        
        super.onRemove(state, level, pos, newState, isMoving);
    }
}