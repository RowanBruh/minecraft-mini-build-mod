package com.infinitystones.ai.commands;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.ai.AIControlMod;
import com.infinitystones.ai.config.AIModConfig;
import com.infinitystones.ai.entity.AIEntityTypes;
import com.infinitystones.ai.entity.AIPlayerEntity;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Registers commands for AI Control
 */
@Mod.EventBusSubscriber(modid = InfinityStonesMod.MOD_ID)
public class AICommandRegister {
    /**
     * Initialize the command register
     */
    public static void init() {
        AIControlMod.LOGGER.info("Initializing AI commands");
    }
    
    /**
     * Register commands event handler
     * 
     * @param event The event
     */
    @SubscribeEvent
    public static void registerCommands(RegisterCommandsEvent event) {
        AIControlMod.LOGGER.info("Registering AI commands");
        
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        
        // Register the SpawnAI command
        dispatcher.register(
                Commands.literal("SpawnAI")
                        .requires(source -> source.hasPermission(2)) // Require op level 2
                        .executes(context -> executeSpawnAI(context.getSource(), null, null))
                        .then(Commands.argument("position", BlockPosArgument.blockPos())
                                .executes(context -> executeSpawnAI(context.getSource(), 
                                        BlockPosArgument.getLoadedBlockPos(context, "position"), null))
                                .then(Commands.argument("name", StringArgumentType.string())
                                        .executes(context -> executeSpawnAI(context.getSource(), 
                                                BlockPosArgument.getLoadedBlockPos(context, "position"), 
                                                StringArgumentType.getString(context, "name")))))
        );
        
        // Register the StopAI command
        dispatcher.register(
                Commands.literal("StopAI")
                        .requires(source -> source.hasPermission(2)) // Require op level 2
                        .executes(context -> executeStopAI(context.getSource()))
        );
        
        // Register the ListAI command
        dispatcher.register(
                Commands.literal("ListAI")
                        .requires(source -> source.hasPermission(2)) // Require op level 2
                        .executes(context -> executeListAI(context.getSource()))
        );
    }
    
    /**
     * Execute the SpawnAI command
     * 
     * @param source The command source
     * @param position The position to spawn at (null for sender's position)
     * @param name The name of the AI entity (null for default)
     * @return The command result
     */
    private static int executeSpawnAI(CommandSourceStack source, BlockPos position, String name) {
        try {
            // Check if web server can be started
            if (!AIControlMod.isWebServerRunning() && !AIControlMod.startWebServer()) {
                source.sendFailure(Component.literal("Failed to start web server. Check logs for details."));
                return 0;
            }
            
            ServerLevel level = source.getLevel();
            
            // Get the position to spawn at
            BlockPos spawnPos;
            if (position != null) {
                spawnPos = position;
            } else {
                try {
                    // Use the command sender's position
                    spawnPos = new BlockPos(source.getPosition());
                } catch (CommandSyntaxException e) {
                    source.sendFailure(Component.literal("Could not determine spawn position."));
                    return 0;
                }
            }
            
            // Count existing AI entities
            List<AIPlayerEntity> existingEntities = level.getEntitiesOfClass(AIPlayerEntity.class, 
                    source.getEntity().getBoundingBox().inflate(256.0));
            
            if (existingEntities.size() >= AIModConfig.COMMON.maxAIEntities.get()) {
                source.sendFailure(Component.literal("Maximum number of AI entities reached. " +
                        "Use /StopAI to remove existing entities."));
                return 0;
            }
            
            // Spawn the AI entity
            AIPlayerEntity entity = AIEntityTypes.AI_PLAYER.get().spawn(
                    level, null, null, spawnPos, MobSpawnType.COMMAND, true, false);
            
            if (entity != null) {
                // Set the entity name if provided
                if (name != null && !name.isEmpty()) {
                    entity.setCustomName(Component.literal(name));
                    entity.setOwnerName(name);
                } else if (source.getEntity() != null) {
                    // Use the command sender's name
                    entity.setOwnerName(source.getEntity().getName().getString());
                }
                
                // Send success message
                String webAddress = "http://localhost:" + AIControlMod.getWebServerPort();
                source.sendSuccess(() -> Component.literal("AI entity spawned. " +
                        "Access the control panel at " + webAddress), true);
                
                return 1;
            } else {
                source.sendFailure(Component.literal("Failed to spawn AI entity. " +
                        "Make sure the position is valid and try again."));
                return 0;
            }
        } catch (Exception e) {
            AIControlMod.LOGGER.error("Error executing SpawnAI command", e);
            source.sendFailure(Component.literal("An error occurred: " + e.getMessage()));
            return 0;
        }
    }
    
    /**
     * Execute the StopAI command
     * 
     * @param source The command source
     * @return The command result
     */
    private static int executeStopAI(CommandSourceStack source) {
        try {
            ServerLevel level = source.getLevel();
            
            // Find all AI entities
            List<AIPlayerEntity> entities = level.getEntitiesOfClass(AIPlayerEntity.class, 
                    source.getEntity().getBoundingBox().inflate(256.0));
            
            if (entities.isEmpty()) {
                source.sendFailure(Component.literal("No AI entities found."));
                return 0;
            }
            
            // Remove all AI entities
            int count = 0;
            for (AIPlayerEntity entity : entities) {
                entity.remove(net.minecraft.world.entity.Entity.RemovalReason.DISCARDED);
                count++;
            }
            
            // Check if web server should be stopped
            if (AIControlMod.isWebServerRunning()) {
                AIControlMod.stopWebServer();
                source.sendSuccess(() -> Component.literal("Stopped web server."), true);
            }
            
            source.sendSuccess(() -> Component.literal("Removed " + count + " AI entities."), true);
            return count;
        } catch (Exception e) {
            AIControlMod.LOGGER.error("Error executing StopAI command", e);
            source.sendFailure(Component.literal("An error occurred: " + e.getMessage()));
            return 0;
        }
    }
    
    /**
     * Execute the ListAI command
     * 
     * @param source The command source
     * @return The command result
     */
    private static int executeListAI(CommandSourceStack source) {
        try {
            ServerLevel level = source.getLevel();
            
            // Find all AI entities
            List<AIPlayerEntity> entities = level.getEntitiesOfClass(AIPlayerEntity.class, 
                    source.getEntity().getBoundingBox().inflate(256.0));
            
            if (entities.isEmpty()) {
                source.sendFailure(Component.literal("No AI entities found."));
                return 0;
            }
            
            // List all AI entities
            List<String> entityInfo = entities.stream()
                    .map(e -> {
                        BlockPos pos = e.blockPosition();
                        String ownerName = e.getOwnerName();
                        String name = e.getCustomName().getString();
                        return name + " (Owner: " + (ownerName.isEmpty() ? "None" : ownerName) + 
                                ") at [" + pos.getX() + ", " + pos.getY() + ", " + pos.getZ() + "]";
                    })
                    .collect(Collectors.toList());
            
            source.sendSuccess(() -> Component.literal("AI entities (" + entityInfo.size() + "):"), false);
            for (String info : entityInfo) {
                source.sendSuccess(() -> Component.literal("- " + info), false);
            }
            
            // Show web server status
            String webStatus = AIControlMod.isWebServerRunning() ? 
                    "Web server running on port " + AIControlMod.getWebServerPort() :
                    "Web server not running";
            source.sendSuccess(() -> Component.literal(webStatus), false);
            
            return entityInfo.size();
        } catch (Exception e) {
            AIControlMod.LOGGER.error("Error executing ListAI command", e);
            source.sendFailure(Component.literal("An error occurred: " + e.getMessage()));
            return 0;
        }
    }
}