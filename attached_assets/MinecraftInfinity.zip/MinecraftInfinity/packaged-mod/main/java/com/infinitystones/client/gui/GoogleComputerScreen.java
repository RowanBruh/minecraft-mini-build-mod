package com.infinitystones.client.gui;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.menu.GoogleComputerMenu;
import com.infinitystones.network.ModPackets;
import com.infinitystones.network.packet.GoogleSearchRequestPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

import java.util.ArrayList;
import java.util.List;

public class GoogleComputerScreen extends AbstractContainerScreen<GoogleComputerMenu> {
    private static final ResourceLocation TEXTURE = 
            new ResourceLocation(InfinityStonesMod.MOD_ID, "textures/gui/google_computer.png");
    
    private EditBox searchBox;
    private Button searchButton;
    private List<String> searchResults = new ArrayList<>();
    private int scrollOffset = 0;
    private static final int MAX_DISPLAY_LINES = 10;
    
    public GoogleComputerScreen(GoogleComputerMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 256;
        this.imageHeight = 200;
    }
    
    @Override
    protected void init() {
        super.init();
        
        // Calculate positions relative to the top-left corner of the GUI
        int centerX = (width - imageWidth) / 2;
        int centerY = (height - imageHeight) / 2;
        
        // Add search box
        searchBox = new EditBox(this.font, centerX + 20, centerY + 20, 180, 20, Component.translatable("infinitystones.google_computer.search"));
        searchBox.setMaxLength(100);
        searchBox.setValue("");
        searchBox.setFocused(true);
        addRenderableWidget(searchBox);
        
        // Add search button
        searchButton = Button.builder(Component.translatable("infinitystones.google_computer.search_button"), this::onSearchButtonPress)
                .pos(centerX + 205, centerY + 20)
                .size(30, 20)
                .build();
        addRenderableWidget(searchButton);
        
        // Add scroll buttons
        Button scrollUpButton = Button.builder(Component.literal("▲"), this::onScrollUp)
                .pos(centerX + 235, centerY + 50)
                .size(15, 15)
                .build();
        addRenderableWidget(scrollUpButton);
        
        Button scrollDownButton = Button.builder(Component.literal("▼"), this::onScrollDown)
                .pos(centerX + 235, centerY + 170)
                .size(15, 15)
                .build();
        addRenderableWidget(scrollDownButton);
        
        // Set initial focus to the search box
        setFocused(searchBox);
    }
    
    private void onSearchButtonPress(Button button) {
        String query = searchBox.getValue().trim();
        if (!query.isEmpty()) {
            // Send search request to server
            ModPackets.sendToServer(new GoogleSearchRequestPacket(query, menu.getBlockEntity().getBlockPos()));
        }
    }
    
    private void onScrollUp(Button button) {
        if (scrollOffset > 0) {
            scrollOffset--;
        }
    }
    
    private void onScrollDown(Button button) {
        if (scrollOffset < Math.max(0, searchResults.size() - MAX_DISPLAY_LINES)) {
            scrollOffset++;
        }
    }
    
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257) { // Enter key
            onSearchButtonPress(searchButton);
            return true;
        }
        
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
    
    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        // Render background texture
        int centerX = (width - imageWidth) / 2;
        int centerY = (height - imageHeight) / 2;
        guiGraphics.blit(TEXTURE, centerX, centerY, 0, 0, imageWidth, imageHeight);
    }
    
    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        
        // Render search results
        int centerX = (width - imageWidth) / 2;
        int centerY = (height - imageHeight) / 2;
        
        // Draw search results title
        guiGraphics.drawString(font, Component.translatable("infinitystones.google_computer.search_results"), 
                centerX + 20, centerY + 50, 0x404040, false);
        
        // Draw search results
        int yPos = centerY + 70;
        int resultsToDisplay = Math.min(MAX_DISPLAY_LINES, searchResults.size() - scrollOffset);
        
        for (int i = 0; i < resultsToDisplay; i++) {
            String result = searchResults.get(i + scrollOffset);
            List<String> wrappedText = font.getSplitter().splitLines(result, 200);
            
            for (String line : wrappedText) {
                if (yPos < centerY + 180) { // Stay within gui bounds
                    guiGraphics.drawString(font, line, centerX + 20, yPos, 0x000000, false);
                    yPos += 10;
                }
            }
            
            yPos += 5; // Space between results
        }
        
        // Draw waiting message if empty
        if (searchResults.isEmpty()) {
            guiGraphics.drawString(font, Component.translatable("infinitystones.google_computer.enter_search"), 
                    centerX + 20, centerY + 90, 0x808080, false);
        }
        
        // Render tooltips
        renderTooltip(guiGraphics, mouseX, mouseY);
    }
    
    public void updateSearchResults(List<String> results) {
        this.searchResults = results;
        this.scrollOffset = 0;
    }
}