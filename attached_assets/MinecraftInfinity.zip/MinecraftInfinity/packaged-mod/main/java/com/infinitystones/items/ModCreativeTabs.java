package com.infinitystones.items;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.blocks.ModBlocks;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/**
 * Registry for creative mode tabs
 */
public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = 
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, InfinityStonesMod.MOD_ID);
    
    // Main mod tab
    public static final RegistryObject<CreativeModeTab> INFINITY_STONES_TAB = CREATIVE_MODE_TABS.register(
            "infinity_stones_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("creativetab.infinity_stones_tab"))
                    .icon(() -> new ItemStack(ModItems.POWER_STONE.get()))
                    .displayItems((parameters, output) -> {
                        // Add Infinity Stones
                        output.accept(ModItems.POWER_STONE.get());
                        output.accept(ModItems.SPACE_STONE.get());
                        output.accept(ModItems.REALITY_STONE.get());
                        output.accept(ModItems.TIME_STONE.get());
                        output.accept(ModItems.MIND_STONE.get());
                        output.accept(ModItems.SOUL_STONE.get());
                        
                        // Add Infinity Gauntlets
                        output.accept(ModItems.INFINITY_GAUNTLET.get());
                        output.accept(ModItems.ADVANCED_INFINITY_GAUNTLET.get());
                        
                        // Add Google Computer
                        output.accept(ModBlocks.GOOGLE_COMPUTER.get());
                    })
                    .build()
    );
    
    // Rowan Industries tab
    public static final RegistryObject<CreativeModeTab> ROWAN_INDUSTRIES_TAB = CREATIVE_MODE_TABS.register(
            "rowan_industries_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("creativetab.rowan_industries_tab"))
                    .icon(() -> new ItemStack(ModItems.INFECTED_POWER_STONE.get()))
                    .displayItems((parameters, output) -> {
                        // Add Infected Infinity Stones
                        output.accept(ModItems.INFECTED_POWER_STONE.get());
                        output.accept(ModItems.INFECTED_SPACE_STONE.get());
                        output.accept(ModItems.INFECTED_REALITY_STONE.get());
                        output.accept(ModItems.INFECTED_TIME_STONE.get());
                        output.accept(ModItems.INFECTED_MIND_STONE.get());
                        output.accept(ModItems.INFECTED_SOUL_STONE.get());
                        
                        // Add Infected Infinity Gauntlets
                        output.accept(ModItems.INFECTED_INFINITY_GAUNTLET.get());
                        output.accept(ModItems.INFECTED_ADVANCED_INFINITY_GAUNTLET.get());
                        
                        // Add Rowan Industries items
                        // Will add other items like nano tech, etc.
                    })
                    .build()
    );
    
    // Bonc's Items tab
    public static final RegistryObject<CreativeModeTab> BONC_ITEMS_TAB = CREATIVE_MODE_TABS.register(
            "bonc_items_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("creativetab.bonc_items_tab"))
                    .icon(() -> new ItemStack(ModItems.POWER_STONE.get())) // Placeholder icon
                    .displayItems((parameters, output) -> {
                        // Will add Bionic/Bonc's items here
                    })
                    .build()
    );
    
    // Greek Gods tab
    public static final RegistryObject<CreativeModeTab> GREEK_GODS_TAB = CREATIVE_MODE_TABS.register(
            "greek_gods_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("creativetab.greek_gods_tab"))
                    .icon(() -> new ItemStack(ModItems.TIME_STONE.get())) // Placeholder icon
                    .displayItems((parameters, output) -> {
                        // Will add Greek god items here
                    })
                    .build()
    );
    
    /**
     * Registers all creative mode tabs
     * 
     * @param eventBus The mod event bus
     */
    public static void register(IEventBus eventBus) {
        CREATIVE_MODE_TABS.register(eventBus);
    }
}