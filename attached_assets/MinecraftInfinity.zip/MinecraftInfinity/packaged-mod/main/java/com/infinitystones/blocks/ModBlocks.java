package com.infinitystones.blocks;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.items.ModItems;
import java.util.function.Supplier;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Registry for mod blocks
 */
public class ModBlocks {
    // Deferred register for blocks
    public static final DeferredRegister<Block> BLOCKS = 
            DeferredRegister.create(ForgeRegistries.BLOCKS, InfinityStonesMod.MOD_ID);
    
    /**
     * The Google Computer block
     */
    public static final RegistryObject<Block> GOOGLE_COMPUTER = registerBlock("google_computer",
            () -> new GoogleComputerBlock(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)
                    .strength(4.0f)
                    .requiresCorrectToolForDrops()
                    .lightLevel(state -> 8)));
    
    /**
     * Registers the blocks with the event bus
     * 
     * @param eventBus The event bus to register with
     */
    public static void register(IEventBus eventBus) {
        BLOCKS.register(eventBus);
    }
    
    /**
     * Helper method to register a block and its item form
     * 
     * @param name The registry name
     * @param blockSupplier The block supplier
     * @return The block registry object
     */
    private static <T extends Block> RegistryObject<T> registerBlock(String name, Supplier<T> blockSupplier) {
        RegistryObject<T> block = BLOCKS.register(name, blockSupplier);
        registerBlockItem(name, block);
        return block;
    }
    
    /**
     * Helper method to register a block item
     * 
     * @param name The registry name
     * @param block The block
     * @return The block item registry object
     */
    private static <T extends Block> RegistryObject<Item> registerBlockItem(String name, RegistryObject<T> block) {
        return ModItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
    }
}