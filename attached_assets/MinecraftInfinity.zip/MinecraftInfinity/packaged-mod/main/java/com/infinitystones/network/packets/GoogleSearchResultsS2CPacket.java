package com.infinitystones.network.packets;

import com.infinitystones.blockentities.GoogleComputerBlockEntity;
import com.infinitystones.screen.GoogleComputerMenu;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraftforge.network.NetworkEvent;

/**
 * Packet to send Google search results to clients
 */
public class GoogleSearchResultsS2CPacket {
    private final List<String> results;
    private final BlockPos blockPos;
    
    /**
     * Constructs a new packet with the given results and block position
     * 
     * @param results The search results
     * @param blockPos The position of the Google Computer block
     */
    public GoogleSearchResultsS2CPacket(List<String> results, BlockPos blockPos) {
        this.results = results;
        this.blockPos = blockPos;
    }
    
    /**
     * Creates a packet from the buffer
     * 
     * @param buf The buffer to read from
     */
    public GoogleSearchResultsS2CPacket(FriendlyByteBuf buf) {
        // Read the block position
        this.blockPos = buf.readBlockPos();
        
        // Read the number of results
        int count = buf.readInt();
        this.results = new ArrayList<>(count);
        
        // Read each result
        for (int i = 0; i < count; i++) {
            results.add(buf.readUtf());
        }
    }
    
    /**
     * Encodes the packet to the buffer
     * 
     * @param buf The buffer to write to
     */
    public void encode(FriendlyByteBuf buf) {
        // Write the block position
        buf.writeBlockPos(blockPos);
        
        // Write the number of results
        buf.writeInt(results.size());
        
        // Write each result
        for (String result : results) {
            buf.writeUtf(result);
        }
    }
    
    /**
     * Handles the packet on the client
     * 
     * @param supplier The supplier for the network event
     * @return True if the packet was handled successfully
     */
    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // Client-side handling
            if (Minecraft.getInstance().player != null) {
                AbstractContainerMenu menu = Minecraft.getInstance().player.containerMenu;
                
                // Update the menu if it's a Google Computer menu
                if (menu instanceof GoogleComputerMenu googleMenu && googleMenu.getBlockPos().equals(blockPos)) {
                    googleMenu.setSearchResults(results);
                }
            }
        });
        
        context.setPacketHandled(true);
        return true;
    }
}