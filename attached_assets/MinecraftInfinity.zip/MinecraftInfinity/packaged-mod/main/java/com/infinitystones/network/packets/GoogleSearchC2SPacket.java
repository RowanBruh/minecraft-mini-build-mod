package com.infinitystones.network.packets;

import com.infinitystones.blockentities.GoogleComputerBlockEntity;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.network.NetworkEvent;

/**
 * Packet to send a Google search query
 */
public class GoogleSearchC2SPacket {
    private final String query;
    private final BlockPos blockPos;
    
    /**
     * Constructs a new packet with the given query and block position
     * 
     * @param query The search query
     * @param blockPos The position of the Google Computer block
     */
    public GoogleSearchC2SPacket(String query, BlockPos blockPos) {
        this.query = query;
        this.blockPos = blockPos;
    }
    
    /**
     * Creates a packet from the buffer
     * 
     * @param buf The buffer to read from
     */
    public GoogleSearchC2SPacket(FriendlyByteBuf buf) {
        this.query = buf.readUtf();
        this.blockPos = buf.readBlockPos();
    }
    
    /**
     * Encodes the packet to the buffer
     * 
     * @param buf The buffer to write to
     */
    public void encode(FriendlyByteBuf buf) {
        buf.writeUtf(query);
        buf.writeBlockPos(blockPos);
    }
    
    /**
     * Handles the packet on the server
     * 
     * @param supplier The supplier for the network event
     * @return True if the packet was handled successfully
     */
    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // Server-side handling
            ServerPlayer player = context.getSender();
            if (player != null) {
                // Get the block entity
                BlockEntity blockEntity = player.level().getBlockEntity(blockPos);
                
                if (blockEntity instanceof GoogleComputerBlockEntity googleComputer) {
                    // Set the search query
                    googleComputer.setSearchQuery(query);
                }
            }
        });
        
        context.setPacketHandled(true);
        return true;
    }
}