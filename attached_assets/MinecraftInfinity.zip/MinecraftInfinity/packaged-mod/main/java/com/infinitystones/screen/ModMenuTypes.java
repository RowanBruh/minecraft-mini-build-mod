package com.infinitystones.screen;

import com.infinitystones.InfinityStonesMod;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Registry for mod menu types
 */
public class ModMenuTypes {
    // Deferred Register for menu types
    public static final DeferredRegister<MenuType<?>> MENUS = 
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, InfinityStonesMod.MOD_ID);
    
    /**
     * The Infinity Gauntlet menu type
     */
    public static final RegistryObject<MenuType<InfinityGauntletMenu>> INFINITY_GAUNTLET =
            MENUS.register("infinity_gauntlet",
                    () -> IForgeMenuType.create(InfinityGauntletMenu::new));
    
    /**
     * The Google Computer menu type
     */
    public static final RegistryObject<MenuType<GoogleComputerMenu>> GOOGLE_COMPUTER =
            MENUS.register("google_computer",
                    () -> IForgeMenuType.create((windowId, inv, data) -> {
                        return new GoogleComputerMenu(windowId, inv, data.readBlockPos());
                    }));
    
    /**
     * Register menu types with the event bus
     * 
     * @param eventBus The event bus to register with
     */
    public static void register(IEventBus eventBus) {
        MENUS.register(eventBus);
    }
}