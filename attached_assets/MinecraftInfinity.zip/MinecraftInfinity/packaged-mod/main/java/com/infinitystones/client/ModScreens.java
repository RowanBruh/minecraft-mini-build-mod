package com.infinitystones.client;

import com.infinitystones.menu.ModMenuTypes;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Registry for client screens
 */
@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ModScreens {
    
    /**
     * Registers all screen types
     */
    @OnlyIn(Dist.CLIENT)
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            // Register the Google Computer screen
            MenuScreens.register(ModMenuTypes.GOOGLE_COMPUTER_MENU.get(), GoogleComputerScreen::new);
            
            // Register the Infinity Gauntlet screen
            MenuScreens.register(ModMenuTypes.INFINITY_GAUNTLET_MENU.get(), InfinityGauntletScreen::new);
        });
    }
}