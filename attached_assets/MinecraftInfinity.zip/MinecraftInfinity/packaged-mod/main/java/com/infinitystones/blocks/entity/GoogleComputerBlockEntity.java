package com.infinitystones.blocks.entity;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.infinitystones.InfinityStonesMod;
import com.infinitystones.blocks.ModBlockEntities;
import com.infinitystones.items.ModItems;
import com.infinitystones.networking.ModMessages;
import com.infinitystones.networking.packet.GoogleSearchResultS2CPacket;
import com.infinitystones.util.GoogleSearchResult;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;

public class GoogleComputerBlockEntity extends BlockEntity implements MenuProvider {
    private final ItemStackHandler itemHandler = new ItemStackHandler(9) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }
    };
    
    private LazyOptional<IItemHandler> lazyItemHandler = LazyOptional.empty();
    
    private final ContainerData data;
    private int progress = 0;
    private int maxProgress = 100;
    private AtomicBoolean isProcessing = new AtomicBoolean(false);
    private String lastQuery = "";
    private List<GoogleSearchResult> lastResults = new ArrayList<>();

    public GoogleComputerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.GOOGLE_COMPUTER.get(), pos, state);
        this.data = new ContainerData() {
            @Override
            public int get(int index) {
                return switch (index) {
                    case 0 -> GoogleComputerBlockEntity.this.progress;
                    case 1 -> GoogleComputerBlockEntity.this.maxProgress;
                    default -> 0;
                };
            }

            @Override
            public void set(int index, int value) {
                switch (index) {
                    case 0 -> GoogleComputerBlockEntity.this.progress = value;
                    case 1 -> GoogleComputerBlockEntity.this.maxProgress = value;
                }
            }

            @Override
            public int getCount() {
                return 2;
            }
        };
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.infinitystones.google_computer");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
        return new GoogleComputerMenu(id, inventory, this, this.data);
    }

    @Override
    public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
            return lazyItemHandler.cast();
        }
        
        return super.getCapability(cap, side);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        lazyItemHandler = LazyOptional.of(() -> itemHandler);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        lazyItemHandler.invalidate();
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        tag.put("inventory", itemHandler.serializeNBT());
        tag.putInt("google_computer.progress", this.progress);
        tag.putString("google_computer.last_query", this.lastQuery);
        
        // Save last search results
        CompoundTag resultsTag = new CompoundTag();
        resultsTag.putInt("count", lastResults.size());
        for (int i = 0; i < lastResults.size(); i++) {
            CompoundTag resultTag = new CompoundTag();
            GoogleSearchResult result = lastResults.get(i);
            resultTag.putString("title", result.getTitle());
            resultTag.putString("link", result.getLink());
            resultTag.putString("snippet", result.getSnippet());
            resultsTag.put("result_" + i, resultTag);
        }
        tag.put("google_computer.results", resultsTag);
        
        super.saveAdditional(tag);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        itemHandler.deserializeNBT(tag.getCompound("inventory"));
        progress = tag.getInt("google_computer.progress");
        lastQuery = tag.getString("google_computer.last_query");
        
        // Load last search results
        lastResults.clear();
        if (tag.contains("google_computer.results")) {
            CompoundTag resultsTag = tag.getCompound("google_computer.results");
            int count = resultsTag.getInt("count");
            for (int i = 0; i < count; i++) {
                CompoundTag resultTag = resultsTag.getCompound("result_" + i);
                String title = resultTag.getString("title");
                String link = resultTag.getString("link");
                String snippet = resultTag.getString("snippet");
                lastResults.add(new GoogleSearchResult(title, link, snippet));
            }
        }
    }

    public void dropContents() {
        SimpleContainer inventory = new SimpleContainer(itemHandler.getSlots());
        for (int i = 0; i < itemHandler.getSlots(); i++) {
            inventory.setItem(i, itemHandler.getStackInSlot(i));
        }

        if (this.level != null) {
            Containers.dropContents(this.level, this.worldPosition, inventory);
        }
    }

    public static void tick(Level level, BlockPos pos, BlockState state, GoogleComputerBlockEntity entity) {
        if (level.isClientSide()) {
            return;
        }

        // You can implement logic here to check for items or energy consumption
    }

    public void performGoogleSearch(String query, Player player) {
        if (query.isEmpty() || isProcessing.get()) {
            return;
        }

        if (query.equals(lastQuery) && !lastResults.isEmpty()) {
            // Return cached results
            ModMessages.sendToPlayer(new GoogleSearchResultS2CPacket(lastResults), (ServerPlayer) player);
            return;
        }

        isProcessing.set(true);
        this.progress = 0;
        this.lastQuery = query;
        
        // Use a CompletableFuture to perform the API call asynchronously
        CompletableFuture.supplyAsync(() -> {
            try {
                String apiKey = System.getenv("GOOGLE_API_KEY");
                if (apiKey == null || apiKey.isEmpty()) {
                    InfinityStonesMod.LOGGER.error("Google API key not found!");
                    return new ArrayList<GoogleSearchResult>();
                }
                
                // Replace with your actual Custom Search Engine ID
                String searchEngineId = "YOUR_SEARCH_ENGINE_ID"; 
                
                String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8);
                URL url = new URL("https://www.googleapis.com/customsearch/v1?key=" + apiKey +
                        "&cx=" + searchEngineId + "&q=" + encodedQuery);
                
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    
                    JsonObject jsonResponse = JsonParser.parseString(response.toString()).getAsJsonObject();
                    List<GoogleSearchResult> results = new ArrayList<>();
                    
                    if (jsonResponse.has("items")) {
                        JsonArray items = jsonResponse.getAsJsonArray("items");
                        for (int i = 0; i < Math.min(items.size(), 10); i++) {
                            JsonObject item = items.get(i).getAsJsonObject();
                            String title = item.has("title") ? item.get("title").getAsString() : "";
                            String link = item.has("link") ? item.get("link").getAsString() : "";
                            String snippet = item.has("snippet") ? item.get("snippet").getAsString() : "";
                            
                            results.add(new GoogleSearchResult(title, link, snippet));
                        }
                    }
                    
                    return results;
                } else {
                    InfinityStonesMod.LOGGER.error("Error response from Google API: " + responseCode);
                    return new ArrayList<GoogleSearchResult>();
                }
            } catch (Exception e) {
                InfinityStonesMod.LOGGER.error("Error during Google search: " + e.getMessage());
                return new ArrayList<GoogleSearchResult>();
            }
        }).thenAccept(results -> {
            // Back on the main thread
            this.progress = maxProgress;
            this.lastResults = results;
            isProcessing.set(false);
            
            if (player != null && player.isAlive() && this.level != null) {
                ModMessages.sendToPlayer(new GoogleSearchResultS2CPacket(results), (ServerPlayer) player);
                
                // Generate items based on search results
                if (!results.isEmpty()) {
                    for (int i = 0; i < Math.min(results.size(), 3); i++) {
                        generateItemFromResult(results.get(i));
                    }
                }
                
                setChanged();
            }
        });
    }
    
    private void generateItemFromResult(GoogleSearchResult result) {
        if (this.level == null) return;
        
        // Create a custom item based on the search result
        ItemStack generatedItem = new ItemStack(getItemForSearchResult(result.getTitle()));
        
        CompoundTag tag = new CompoundTag();
        tag.putString("GoogleResult", result.getTitle());
        tag.putString("GoogleLink", result.getLink());
        tag.putString("GoogleSnippet", result.getSnippet());
        generatedItem.setTag(tag);
        
        // Customize name
        generatedItem.setHoverName(Component.literal(result.getTitle()));
        
        // Find an empty slot in the inventory
        for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
            if (itemHandler.getStackInSlot(slot).isEmpty()) {
                itemHandler.setStackInSlot(slot, generatedItem);
                break;
            }
        }
    }
    
    private Item getItemForSearchResult(String title) {
        // Choose different items based on keywords in the title
        String lowerTitle = title.toLowerCase();
        
        if (lowerTitle.contains("weapon") || lowerTitle.contains("sword") || 
                lowerTitle.contains("gun") || lowerTitle.contains("attack")) {
            return ModItems.POWER_STONE.get();
        } else if (lowerTitle.contains("magic") || lowerTitle.contains("spell") || 
                lowerTitle.contains("wizard") || lowerTitle.contains("enchant")) {
            return ModItems.MIND_STONE.get();
        } else if (lowerTitle.contains("travel") || lowerTitle.contains("portal") || 
                lowerTitle.contains("teleport") || lowerTitle.contains("location")) {
            return ModItems.SPACE_STONE.get();
        } else if (lowerTitle.contains("time") || lowerTitle.contains("clock") || 
                lowerTitle.contains("history") || lowerTitle.contains("age")) {
            return ModItems.TIME_STONE.get();
        } else if (lowerTitle.contains("change") || lowerTitle.contains("transform") || 
                lowerTitle.contains("alter") || lowerTitle.contains("reality")) {
            return ModItems.REALITY_STONE.get();
        } else if (lowerTitle.contains("soul") || lowerTitle.contains("spirit") || 
                lowerTitle.contains("life") || lowerTitle.contains("death")) {
            return ModItems.SOUL_STONE.get();
        } else {
            // Default item if no keywords match
            return ModItems.NANO_TECH_MATERIAL.get();
        }
    }

    public boolean isProcessing() {
        return isProcessing.get();
    }

    public int getProgress() {
        return progress;
    }

    public String getLastQuery() {
        return lastQuery;
    }

    public List<GoogleSearchResult> getLastResults() {
        return lastResults;
    }
}