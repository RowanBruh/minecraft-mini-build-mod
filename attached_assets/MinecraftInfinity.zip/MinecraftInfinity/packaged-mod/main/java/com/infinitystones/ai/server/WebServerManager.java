package com.infinitystones.ai.server;

import com.infinitystones.ai.AIControlMod;
import com.infinitystones.ai.config.AIModConfig;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Manages the Node.js web server
 */
public class WebServerManager {
    private static final String NODE_EXECUTABLE = "node";
    private static final String WEB_SERVER_PATH = "web-server/server.js";
    
    private Process serverProcess;
    private int port;
    private final AtomicBoolean running = new AtomicBoolean(false);
    
    /**
     * Constructs a new web server manager
     */
    public WebServerManager() {
        this.port = AIModConfig.COMMON.webServerPort.get();
    }
    
    /**
     * Start the web server
     *
     * @return True if the server was started successfully
     */
    public boolean startServer() {
        if (running.get()) {
            AIControlMod.LOGGER.info("Web server is already running");
            return true;
        }
        
        // Check if the port is available
        if (!isPortAvailable(port)) {
            AIControlMod.LOGGER.error("Port {} is not available", port);
            return false;
        }
        
        // Check if Node.js is installed
        if (!isNodeInstalled()) {
            AIControlMod.LOGGER.error("Node.js is not installed or not in PATH");
            return false;
        }
        
        // Check if the web server file exists
        File serverFile = new File(WEB_SERVER_PATH);
        if (!serverFile.exists()) {
            AIControlMod.LOGGER.error("Web server file not found: {}", WEB_SERVER_PATH);
            return false;
        }
        
        try {
            // Build the command to start the Node.js server
            ProcessBuilder processBuilder = new ProcessBuilder(
                    NODE_EXECUTABLE,
                    WEB_SERVER_PATH
            );
            
            // Set environment variables
            processBuilder.environment().put("PORT", String.valueOf(port));
            
            // Redirect output to console
            processBuilder.redirectErrorStream(true);
            
            // Start the process
            serverProcess = processBuilder.start();
            
            // Start a thread to log the server output
            new Thread(() -> {
                try {
                    java.io.InputStream inputStream = serverProcess.getInputStream();
                    java.io.BufferedReader reader = new java.io.BufferedReader(
                            new java.io.InputStreamReader(inputStream));
                    
                    String line;
                    while ((line = reader.readLine()) != null) {
                        AIControlMod.LOGGER.info("Web server: {}", line);
                    }
                } catch (IOException e) {
                    AIControlMod.LOGGER.error("Error reading web server output", e);
                }
            }).start();
            
            // Start a thread to check if the process is still running
            new Thread(() -> {
                try {
                    int exitCode = serverProcess.waitFor();
                    running.set(false);
                    AIControlMod.LOGGER.info("Web server exited with code {}", exitCode);
                } catch (InterruptedException e) {
                    AIControlMod.LOGGER.error("Error waiting for web server process", e);
                    running.set(false);
                }
            }).start();
            
            // Wait a bit for the server to start
            Thread.sleep(1000);
            
            // Check if the process is still running
            if (serverProcess.isAlive()) {
                running.set(true);
                AIControlMod.LOGGER.info("Web server started on port {}", port);
                return true;
            } else {
                AIControlMod.LOGGER.error("Web server failed to start");
                return false;
            }
        } catch (IOException | InterruptedException e) {
            AIControlMod.LOGGER.error("Error starting web server", e);
            return false;
        }
    }
    
    /**
     * Stop the web server
     */
    public void stopServer() {
        if (!running.get() || serverProcess == null) {
            AIControlMod.LOGGER.info("Web server is not running");
            return;
        }
        
        try {
            AIControlMod.LOGGER.info("Stopping web server");
            
            // Destroy the process
            serverProcess.destroy();
            
            // Wait for the process to exit
            boolean exited = serverProcess.waitFor(5, java.util.concurrent.TimeUnit.SECONDS);
            
            if (!exited) {
                // Force kill the process
                AIControlMod.LOGGER.warn("Web server did not exit gracefully, forcing termination");
                serverProcess.destroyForcibly();
            }
            
            running.set(false);
            AIControlMod.LOGGER.info("Web server stopped");
        } catch (InterruptedException e) {
            AIControlMod.LOGGER.error("Error stopping web server", e);
        }
    }
    
    /**
     * Check if the web server is running
     *
     * @return True if the web server is running
     */
    public boolean isRunning() {
        return running.get() && serverProcess != null && serverProcess.isAlive();
    }
    
    /**
     * Get the port the web server is running on
     *
     * @return The port
     */
    public int getPort() {
        return port;
    }
    
    /**
     * Check if a port is available
     *
     * @param port The port to check
     * @return True if the port is available
     */
    private boolean isPortAvailable(int port) {
        try (ServerSocket socket = new ServerSocket(port, 0, InetAddress.getLoopbackAddress())) {
            return true;
        } catch (IOException e) {
            return false;
        }
    }
    
    /**
     * Check if Node.js is installed
     *
     * @return True if Node.js is installed
     */
    private boolean isNodeInstalled() {
        try {
            Process process = Runtime.getRuntime().exec(NODE_EXECUTABLE + " --version");
            int exitCode = process.waitFor();
            return exitCode == 0;
        } catch (IOException | InterruptedException e) {
            return false;
        }
    }
    
    /**
     * Get the absolute path of the web server directory
     *
     * @return The absolute path
     */
    private String getWebServerDirectory() {
        Path currentDirectory = Paths.get("").toAbsolutePath();
        return currentDirectory.resolve(WEB_SERVER_PATH).getParent().toString();
    }
}