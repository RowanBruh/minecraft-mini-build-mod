package com.infinitystones.blockentities;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.blocks.ModBlocks;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/**
 * Registry for mod block entities
 */
public class ModBlockEntities {
    // Deferred Register for block entities
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = 
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, InfinityStonesMod.MOD_ID);
    
    /**
     * Google Computer block entity
     */
    public static final RegistryObject<BlockEntityType<GoogleComputerBlockEntity>> GOOGLE_COMPUTER = 
            BLOCK_ENTITIES.register("google_computer",
            () -> BlockEntityType.Builder.of(GoogleComputerBlockEntity::new, 
                    ModBlocks.GOOGLE_COMPUTER.get()).build(null));
    
    /**
     * Registers the block entities with the event bus
     * 
     * @param eventBus The event bus to register with
     */
    public static void register(IEventBus eventBus) {
        BLOCK_ENTITIES.register(eventBus);
    }
}