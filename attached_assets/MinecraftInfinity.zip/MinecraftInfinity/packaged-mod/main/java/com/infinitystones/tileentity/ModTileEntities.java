package com.infinitystones.tileentity;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.blocks.ModBlocks;
import net.minecraft.block.Block;
import net.minecraft.tileentity.TileEntityType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModTileEntities {
    public static final DeferredRegister<TileEntityType<?>> TILE_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, InfinityStonesMod.MOD_ID);

    public static final RegistryObject<TileEntityType<GoogleComputerTileEntity>> GOOGLE_COMPUTER =
            TILE_ENTITIES.register("google_computer",
                    () -> TileEntityType.Builder.of(GoogleComputerTileEntity::new,
                            ModBlocks.GOOGLE_COMPUTER.get()).build(null));

    public static void register(IEventBus eventBus) {
        TILE_ENTITIES.register(eventBus);
    }
}