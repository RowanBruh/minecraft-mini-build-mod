package com.infinitystones.config;

import com.infinitystones.InfinityStonesMod;
import java.util.Arrays;
import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import org.apache.commons.lang3.tuple.Pair;

/**
 * Configuration for the mod
 */
@Mod.EventBusSubscriber(modid = InfinityStonesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModConfig {
    public static final ForgeConfigSpec COMMON_SPEC;
    public static final CommonConfig COMMON;
    
    static {
        final Pair<CommonConfig, ForgeConfigSpec> specPair = new ForgeConfigSpec.Builder()
                .configure(CommonConfig::new);
        COMMON_SPEC = specPair.getRight();
        COMMON = specPair.getLeft();
    }
    
    /**
     * Google API key for search functionality
     */
    public static ForgeConfigSpec.ConfigValue<String> GOOGLE_API_KEY;
    
    /**
     * Google Search Engine ID for custom search
     */
    public static ForgeConfigSpec.ConfigValue<String> GOOGLE_SEARCH_ENGINE_ID;
    
    /**
     * Stone ability cooldown in ticks
     */
    public static ForgeConfigSpec.IntValue STONE_ABILITY_COOLDOWN;
    
    /**
     * Stone ability range in blocks
     */
    public static ForgeConfigSpec.IntValue STONE_ABILITY_RANGE;
    
    /**
     * Whether infected stones have stronger abilities
     */
    public static ForgeConfigSpec.BooleanValue INFECTED_STRONGER_ABILITIES;
    
    /**
     * List of dimensions where stone abilities are restricted
     */
    public static ForgeConfigSpec.ConfigValue<List<? extends String>> RESTRICTED_DIMENSIONS;
    
    /**
     * Common configuration
     */
    public static class CommonConfig {
        /**
         * Creates a new common config
         * 
         * @param builder The config builder
         */
        public CommonConfig(ForgeConfigSpec.Builder builder) {
            builder.comment("Infinity Stones Mod Configuration")
                   .push("general");
            
            STONE_ABILITY_COOLDOWN = builder
                    .comment("Cooldown time (in ticks) between stone ability uses")
                    .defineInRange("stoneAbilityCooldown", 100, 20, 6000);
            
            STONE_ABILITY_RANGE = builder
                    .comment("Range (in blocks) for stone abilities that affect an area")
                    .defineInRange("stoneAbilityRange", 16, 1, 64);
            
            INFECTED_STRONGER_ABILITIES = builder
                    .comment("Whether infected stones have stronger abilities but with side effects")
                    .define("infectedStrongerAbilities", true);
            
            RESTRICTED_DIMENSIONS = builder
                    .comment("List of dimension IDs where stone abilities are restricted")
                    .defineList("restrictedDimensions", 
                            Arrays.asList("minecraft:the_end"), obj -> obj instanceof String);
            
            builder.pop();
            
            builder.comment("Google API Configuration")
                   .push("google_api");
            
            GOOGLE_API_KEY = builder
                    .comment("Google API Key for search functionality (required for Google Computer)")
                    .define("googleApiKey", System.getenv().getOrDefault("GOOGLE_API_KEY", ""));
            
            GOOGLE_SEARCH_ENGINE_ID = builder
                    .comment("Google Search Engine ID for custom search")
                    .define("googleSearchEngineId", "");
            
            builder.pop();
        }
    }
    
    /**
     * Handles config loading
     * 
     * @param event The config loading event
     */
    @SubscribeEvent
    public static void onLoad(final ModConfigEvent.Loading event) {
        InfinityStonesMod.LOGGER.info("Loaded Infinity Stones Mod config file {}", event.getConfig().getFileName());
    }
    
    /**
     * Handles config reloading
     * 
     * @param event The config reloading event
     */
    @SubscribeEvent
    public static void onReload(final ModConfigEvent.Reloading event) {
        InfinityStonesMod.LOGGER.info("Infinity Stones Mod config reloaded");
    }
}