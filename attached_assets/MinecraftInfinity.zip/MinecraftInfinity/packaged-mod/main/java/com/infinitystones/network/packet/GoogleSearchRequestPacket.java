package com.infinitystones.network.packet;

import com.infinitystones.blockentities.GoogleComputerBlockEntity;
import com.infinitystones.network.ModPackets;
import com.infinitystones.util.GoogleSearchHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class GoogleSearchRequestPacket {
    private final String searchQuery;
    private final BlockPos computerPos;
    
    public GoogleSearchRequestPacket(String searchQuery, BlockPos computerPos) {
        this.searchQuery = searchQuery;
        this.computerPos = computerPos;
    }
    
    public GoogleSearchRequestPacket(FriendlyByteBuf buf) {
        this.searchQuery = buf.readUtf();
        this.computerPos = buf.readBlockPos();
    }
    
    public void toBytes(FriendlyByteBuf buf) {
        buf.writeUtf(searchQuery);
        buf.writeBlockPos(computerPos);
    }
    
    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // Execute on the server
            ServerPlayer player = context.getSender();
            if (player != null) {
                ServerLevel level = player.serverLevel();
                BlockEntity blockEntity = level.getBlockEntity(computerPos);
                
                if (blockEntity instanceof GoogleComputerBlockEntity googleComputer) {
                    // Set the search query in the block entity
                    googleComputer.setSearchQuery(searchQuery);
                    
                    // Attempt to perform search immediately for faster response
                    List<String> results = new ArrayList<>();
                    try {
                        results = GoogleSearchHandler.search(searchQuery);
                    } catch (Exception e) {
                        results.add("Error: " + e.getMessage());
                    }
                    
                    // Send results back to client
                    ModPackets.sendToPlayer(new GoogleSearchResponsePacket(results, computerPos), player);
                }
            }
        });
        
        return true;
    }
}