package com.infinitystones.util;

import com.infinitystones.InfinityStonesMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;

/**
 * Custom tags for the Infinity Stones mod
 */
public class ModTags {
    public static class Items {
        /**
         * Tag for all Infinity Stone items
         */
        public static final TagKey<Item> INFINITY_STONES = 
                tag("infinity_stones");
        
        /**
         * Tag for all infected Infinity Stone items
         */
        public static final TagKey<Item> INFECTED_INFINITY_STONES = 
                tag("infected_infinity_stones");
        
        /**
         * Tag for all gauntlet items
         */
        public static final TagKey<Item> GAUNTLETS = 
                tag("gauntlets");
        
        /**
         * Tag for Rowan Industries items
         */
        public static final TagKey<Item> ROWAN_INDUSTRIES = 
                tag("rowan_industries");
        
        /**
         * Tag for Bonc's items
         */
        public static final TagKey<Item> BONC_ITEMS = 
                tag("bonc_items");
        
        /**
         * Tag for Greek Gods items
         */
        public static final TagKey<Item> GREEK_GODS = 
                tag("greek_gods");
        
        /**
         * Creates a tag with the given name
         * 
         * @param name The tag name
         * @return The created tag
         */
        private static TagKey<Item> tag(String name) {
            return ItemTags.create(new ResourceLocation(InfinityStonesMod.MOD_ID, name));
        }
    }
}