package com.infinitystones.ai.network.packets;

import com.infinitystones.ai.AIControlMod;
import com.infinitystones.ai.entity.AIPlayerEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

/**
 * Packet for sending commands to AI entities
 */
public class CommandPacket {
    private UUID entityId;
    private String command;
    private String args;
    
    /**
     * Default constructor
     */
    public CommandPacket() {
    }
    
    /**
     * Constructor with parameters
     * 
     * @param entityId The entity ID
     * @param command The command
     * @param args The command arguments
     */
    public CommandPacket(UUID entityId, String command, String args) {
        this.entityId = entityId;
        this.command = command;
        this.args = args;
    }
    
    /**
     * Encode the packet
     * 
     * @param buf The buffer
     */
    public void encode(FriendlyByteBuf buf) {
        buf.writeUUID(entityId);
        buf.writeUtf(command);
        buf.writeUtf(args != null ? args : "");
    }
    
    /**
     * Decode the packet
     * 
     * @param buf The buffer
     * @return The packet
     */
    public static CommandPacket decode(FriendlyByteBuf buf) {
        CommandPacket packet = new CommandPacket();
        packet.entityId = buf.readUUID();
        packet.command = buf.readUtf();
        packet.args = buf.readUtf();
        return packet;
    }
    
    /**
     * Handle the packet
     * 
     * @param context The context
     * @return void
     */
    public void handle(Supplier<NetworkEvent.Context> context) {
        context.get().enqueueWork(() -> {
            // This must be server-side
            if (context.get().getDirection().getReceptionSide().isServer()) {
                handleServer(context);
            }
        });
        context.get().setPacketHandled(true);
    }
    
    /**
     * Handle the packet on the server
     * 
     * @param context The context
     */
    private void handleServer(Supplier<NetworkEvent.Context> context) {
        // Get the sender's server
        var server = context.get().getSender().getServer();
        if (server == null) {
            AIControlMod.LOGGER.error("Server is null");
            return;
        }
        
        // Find the AI entity
        for (ServerLevel level : server.getAllLevels()) {
            Entity entity = level.getEntity(entityId);
            if (entity instanceof AIPlayerEntity) {
                AIPlayerEntity aiEntity = (AIPlayerEntity) entity;
                
                // Execute the command
                AIControlMod.LOGGER.info("Executing command '{}' with args '{}' for AI entity {}", 
                        command, args, entityId);
                aiEntity.handleCommand(command, args);
                return;
            }
        }
        
        AIControlMod.LOGGER.warn("Could not find AI entity with ID {}", entityId);
    }
}