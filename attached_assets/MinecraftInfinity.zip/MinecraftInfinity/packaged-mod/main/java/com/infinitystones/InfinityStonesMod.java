package com.infinitystones;

import com.infinitystones.ai.AIControlMod;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Main class for the Infinity Stones mod
 */
@Mod(InfinityStonesMod.MOD_ID)
public class InfinityStonesMod {
    // Define mod id
    public static final String MOD_ID = "infinitystones";
    
    // Directly reference a log4j logger
    private static final Logger LOGGER = LogManager.getLogger();
    
    /**
     * Constructor for the mod
     */
    public InfinityStonesMod() {
        LOGGER.info("Initializing Infinity Stones Mod");
        
        // Get the mod event bus
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        
        // Register the setup method for mod loading
        modEventBus.addListener(this::setup);
        
        // Register ourselves for server and other game events
        MinecraftForge.EVENT_BUS.register(this);
        
        // Initialize AI Control Module
        AIControlMod.init();
    }
    
    /**
     * Setup method for the mod
     *
     * @param event The setup event
     */
    private void setup(final FMLCommonSetupEvent event) {
        LOGGER.info("Infinity Stones Mod setup");
    }
}