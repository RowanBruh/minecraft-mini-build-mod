package com.infinitystones.client;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.menu.InfinityGauntletMenu;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import org.jetbrains.annotations.NotNull;

/**
 * Screen implementation for the Infinity Gauntlet
 */
public class InfinityGauntletScreen extends AbstractContainerScreen<InfinityGauntletMenu> {
    private static final ResourceLocation TEXTURE = 
            new ResourceLocation(InfinityStonesMod.MOD_ID, "textures/gui/infinity_gauntlet.png");
    
    public InfinityGauntletScreen(InfinityGauntletMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        
        // Adjust the size of the screen
        this.imageWidth = 176;
        this.imageHeight = 166;
    }
    
    @Override
    protected void renderBg(@NotNull GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, TEXTURE);
        
        int x = this.leftPos;
        int y = this.topPos;
        guiGraphics.blit(TEXTURE, x, y, 0, 0, this.imageWidth, this.imageHeight);
    }
    
    @Override
    public void render(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(guiGraphics);
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        renderTooltip(guiGraphics, mouseX, mouseY);
        
        // Draw gauntlet title
        guiGraphics.drawString(this.font, this.title, 
                this.leftPos + 8, this.topPos + 6, 4210752, false);
        
        // Draw stone slots info
        guiGraphics.drawString(this.font, 
                Component.translatable("container.infinitystones.infinity_gauntlet.stone_slots"), 
                this.leftPos + 8, this.topPos + 20, 4210752, false);
    }
}