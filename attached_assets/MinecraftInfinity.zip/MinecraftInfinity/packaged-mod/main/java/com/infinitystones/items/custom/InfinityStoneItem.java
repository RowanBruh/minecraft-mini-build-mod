package com.infinitystones.items.custom;

import com.infinitystones.network.ModPackets;
import com.infinitystones.network.packets.StoneAbilityC2SPacket;
import com.infinitystones.util.CooldownTracker;
import com.infinitystones.util.StoneType;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * Item implementation for Infinity Stones
 */
public class InfinityStoneItem extends Item {
    // The type of stone
    private final StoneType stoneType;
    
    // Whether this is an infected stone
    private final boolean infected;
    
    /**
     * Creates a new Infinity Stone item
     * 
     * @param properties The item properties
     * @param stoneType The type of stone
     * @param infected Whether this is an infected stone
     */
    public InfinityStoneItem(Properties properties, StoneType stoneType, boolean infected) {
        super(properties);
        this.stoneType = stoneType;
        this.infected = infected;
    }
    
    /**
     * Gets the stone type
     * 
     * @return The stone type
     */
    public StoneType getStoneType() {
        return stoneType;
    }
    
    /**
     * Gets whether this is an infected stone
     * 
     * @return True if infected
     */
    public boolean isInfected() {
        return infected;
    }
    
    /**
     * Gets the display name with formatting
     * 
     * @param stack The item stack
     * @return The display name
     */
    @Override
    public Component getName(ItemStack stack) {
        Component name = super.getName(stack);
        
        // Format the name based on the stone type
        ChatFormatting formatting = getStoneFormatting();
        
        return name.copy().withStyle(formatting);
    }
    
    /**
     * Gets the formatting for the stone
     * 
     * @return The chat formatting
     */
    private ChatFormatting getStoneFormatting() {
        if (infected) {
            return ChatFormatting.DARK_RED;
        }
        
        return switch (stoneType) {
            case SPACE -> ChatFormatting.BLUE;
            case MIND -> ChatFormatting.YELLOW;
            case REALITY -> ChatFormatting.RED;
            case POWER -> ChatFormatting.LIGHT_PURPLE;
            case TIME -> ChatFormatting.GREEN;
            case SOUL -> ChatFormatting.GOLD;
        };
    }
    
    /**
     * Adds tooltip information
     * 
     * @param stack The item stack
     * @param level The level
     * @param components The tooltip components
     * @param flag The tooltip flag
     */
    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> components, TooltipFlag flag) {
        super.appendHoverText(stack, level, components, flag);
        
        // Add stone description
        components.add(Component.translatable("tooltip.infinitystones." + stoneType.getSerializedName() + "_stone")
                .withStyle(ChatFormatting.GRAY));
        
        // Add infected warning if applicable
        if (infected) {
            components.add(Component.translatable("tooltip.infinitystones.infected")
                    .withStyle(ChatFormatting.DARK_RED));
        }
        
        // Add usage instructions
        components.add(Component.translatable("tooltip.infinitystones.stone_use")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
    
    /**
     * Handles item use
     * 
     * @param level The level
     * @param player The player
     * @param hand The hand
     * @return The interaction result
     */
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack itemstack = player.getItemInHand(hand);
        
        if (!level.isClientSide) {
            // Server-side handling
            if (hand == InteractionHand.MAIN_HAND) {
                // Check cooldown
                if (CooldownTracker.isOnCooldown(player.getUUID(), stoneType)) {
                    player.displayClientMessage(
                            Component.translatable("message.infinitystones.cooldown", 
                                    CooldownTracker.getRemainingCooldown(player.getUUID(), stoneType) / 20),
                            true);
                    return InteractionResultHolder.fail(itemstack);
                }
                
                // Use stone ability directly
                StoneAbilityC2SPacket packet = new StoneAbilityC2SPacket(stoneType, infected);
                packet.handle(() -> new net.minecraftforge.network.NetworkEvent.Context(
                        null, new java.util.function.Supplier<net.minecraft.server.level.ServerPlayer>() {
                            @Override
                            public net.minecraft.server.level.ServerPlayer get() {
                                return (net.minecraft.server.level.ServerPlayer) player;
                            }
                        }, null));
            }
        } else {
            // Client-side handling - send packet to server
            if (hand == InteractionHand.MAIN_HAND) {
                ModPackets.sendToServer(new StoneAbilityC2SPacket(stoneType, infected));
            }
        }
        
        return InteractionResultHolder.sidedSuccess(itemstack, level.isClientSide);
    }
    
    /**
     * Handles item inventory tick
     * 
     * @param stack The item stack
     * @param level The level
     * @param entity The entity
     * @param slotId The slot ID
     * @param isSelected Whether the item is selected
     */
    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slotId, boolean isSelected) {
        super.inventoryTick(stack, level, entity, slotId, isSelected);
        
        // Apply effects when in inventory for infected stones
        if (infected && entity instanceof Player player && level.getGameTime() % 200 == 0) {
            if (level.random.nextFloat() < 0.05f) {
                applyInfectedEffect(player);
            }
        }
    }
    
    /**
     * Applies an effect for infected stones
     * 
     * @param player The player
     */
    private void applyInfectedEffect(Player player) {
        if (player.level().isClientSide) {
            return;
        }
        
        // Small negative effect based on stone type
        switch (stoneType) {
            case SPACE -> player.teleport(
                    player.getX() + (player.level().random.nextDouble() - 0.5) * 2,
                    player.getY(),
                    player.getZ() + (player.level().random.nextDouble() - 0.5) * 2);
            case MIND -> player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.CONFUSION, 100, 0));
            case REALITY -> player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.BLINDNESS, 40, 0));
            case POWER -> player.hurt(player.damageSources().magic(), 1.0f);
            case TIME -> player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 100, 0));
            case SOUL -> player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.HUNGER, 100, 0));
        }
    }
    
    /**
     * Gets whether the item is enchantable
     * 
     * @param stack The item stack
     * @return True if enchantable
     */
    @Override
    public boolean isEnchantable(ItemStack stack) {
        return false;
    }
    
    /**
     * Gets whether the item is foil (glowing)
     * 
     * @param stack The item stack
     * @return True if foil
     */
    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}