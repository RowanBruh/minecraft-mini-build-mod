package com.infinitystones.util;

import com.infinitystones.InfinityStonesMod;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.function.Supplier;

public class ModArmorMaterials {
    public static final ArmorMaterial INFINITY_GAUNTLET = new ModArmorMaterial(
            "infinity_gauntlet",
            50, // Durability multiplier
            new int[] {5, 8, 10, 5}, // Protection values for boots, leggings, chestplate, helmet
            30, // Enchantability
            SoundEvents.ARMOR_EQUIP_NETHERITE, // Sound when equipped
            5.0f, // Toughness
            1.0f, // Knockback resistance
            () -> Ingredient.EMPTY // Repair ingredient (not needed for gauntlet)
    );
    
    public static final ArmorMaterial INFECTED_INFINITY_GAUNTLET = new ModArmorMaterial(
            "infected_infinity_gauntlet",
            60, // Durability multiplier
            new int[] {6, 9, 12, 6}, // Protection values for boots, leggings, chestplate, helmet
            25, // Enchantability
            SoundEvents.ARMOR_EQUIP_NETHERITE, // Sound when equipped
            6.0f, // Toughness
            1.5f, // Knockback resistance
            () -> Ingredient.EMPTY // Repair ingredient (not needed for gauntlet)
    );
    
    public static final ArmorMaterial NANO_TECH = new ModArmorMaterial(
            "nano_tech",
            40, // Durability multiplier
            new int[] {4, 7, 9, 4}, // Protection values for boots, leggings, chestplate, helmet
            20, // Enchantability
            SoundEvents.ARMOR_EQUIP_NETHERITE, // Sound when equipped
            3.5f, // Toughness
            0.4f, // Knockback resistance
            () -> Ingredient.EMPTY // Repair ingredient
    );
    
    public static final ArmorMaterial BONC = new ModArmorMaterial(
            "bonc",
            45, // Durability multiplier
            new int[] {5, 8, 10, 5}, // Protection values for boots, leggings, chestplate, helmet
            22, // Enchantability
            SoundEvents.ARMOR_EQUIP_NETHERITE, // Sound when equipped
            4.0f, // Toughness
            0.5f, // Knockback resistance
            () -> Ingredient.EMPTY // Repair ingredient
    );
    
    private static class ModArmorMaterial implements ArmorMaterial {
        private static final int[] HEALTH_PER_SLOT = new int[] {13, 15, 16, 11};
        private final String name;
        private final int durabilityMultiplier;
        private final int[] protectionAmounts;
        private final int enchantmentValue;
        private final SoundEvent equipSound;
        private final float toughness;
        private final float knockbackResistance;
        private final Supplier<Ingredient> repairIngredient;
    
        ModArmorMaterial(String name, int durabilityMultiplier, int[] protectionAmounts,
                         int enchantmentValue, SoundEvent equipSound, float toughness,
                         float knockbackResistance, Supplier<Ingredient> repairIngredient) {
            this.name = name;
            this.durabilityMultiplier = durabilityMultiplier;
            this.protectionAmounts = protectionAmounts;
            this.enchantmentValue = enchantmentValue;
            this.equipSound = equipSound;
            this.toughness = toughness;
            this.knockbackResistance = knockbackResistance;
            this.repairIngredient = repairIngredient;
        }
    
        @Override
        public int getDurabilityForType(ArmorItem.Type type) {
            return HEALTH_PER_SLOT[type.getSlot().getIndex()] * this.durabilityMultiplier;
        }
    
        @Override
        public int getDefenseForType(ArmorItem.Type type) {
            return this.protectionAmounts[type.getSlot().getIndex()];
        }
    
        @Override
        public int getEnchantmentValue() {
            return this.enchantmentValue;
        }
    
        @Override
        public SoundEvent getEquipSound() {
            return this.equipSound;
        }
    
        @Override
        public Ingredient getRepairIngredient() {
            return this.repairIngredient.get();
        }
    
        @Override
        public String getName() {
            return InfinityStonesMod.MOD_ID + ":" + this.name;
        }
    
        @Override
        public float getToughness() {
            return this.toughness;
        }
    
        @Override
        public float getKnockbackResistance() {
            return this.knockbackResistance;
        }
    }
}