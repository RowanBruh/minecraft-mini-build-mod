package com.infinitystones.items;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.blocks.ModBlocks;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/**
 * Registry for mod creative tabs
 */
public class ModTabs {
    // Deferred register for creative tabs
    public static final DeferredRegister<CreativeModeTab> TABS = 
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, InfinityStonesMod.MOD_ID);
    
    /**
     * The Infinity Stones tab
     */
    public static final RegistryObject<CreativeModeTab> INFINITY_STONES_TAB = TABS.register("infinity_stones_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.infinitystones"))
                    .icon(() -> new ItemStack(ModItems.INFINITY_GAUNTLET.get()))
                    .displayItems((parameters, output) -> {
                        // Add Infinity Stones
                        output.accept(ModItems.SPACE_STONE.get());
                        output.accept(ModItems.MIND_STONE.get());
                        output.accept(ModItems.REALITY_STONE.get());
                        output.accept(ModItems.POWER_STONE.get());
                        output.accept(ModItems.TIME_STONE.get());
                        output.accept(ModItems.SOUL_STONE.get());
                        
                        // Add Infinity Gauntlet
                        output.accept(ModItems.INFINITY_GAUNTLET.get());
                        
                        // Add Google Computer
                        output.accept(ModBlocks.GOOGLE_COMPUTER.get());
                    })
                    .build());
    
    /**
     * The Rowan Industries tab
     */
    public static final RegistryObject<CreativeModeTab> ROWAN_INDUSTRIES_TAB = TABS.register("rowan_industries_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.rowanindustries"))
                    .icon(() -> new ItemStack(ModItems.INFECTED_INFINITY_GAUNTLET.get()))
                    .displayItems((parameters, output) -> {
                        // Add Infected Infinity Stones
                        output.accept(ModItems.INFECTED_SPACE_STONE.get());
                        output.accept(ModItems.INFECTED_MIND_STONE.get());
                        output.accept(ModItems.INFECTED_REALITY_STONE.get());
                        output.accept(ModItems.INFECTED_POWER_STONE.get());
                        output.accept(ModItems.INFECTED_TIME_STONE.get());
                        output.accept(ModItems.INFECTED_SOUL_STONE.get());
                        
                        // Add Infected Infinity Gauntlet
                        output.accept(ModItems.INFECTED_INFINITY_GAUNTLET.get());
                    })
                    .build());
    
    /**
     * The Bonc's Items tab
     */
    public static final RegistryObject<CreativeModeTab> BONCS_ITEMS_TAB = TABS.register("boncs_items_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.boncsitems"))
                    .icon(() -> new ItemStack(ModItems.POWER_STONE.get()))
                    .displayItems((parameters, output) -> {
                        // Will be populated with Bionic's items
                    })
                    .build());
    
    /**
     * Registers the creative tabs with the event bus
     * 
     * @param eventBus The event bus to register with
     */
    public static void register(IEventBus eventBus) {
        TABS.register(eventBus);
    }
}