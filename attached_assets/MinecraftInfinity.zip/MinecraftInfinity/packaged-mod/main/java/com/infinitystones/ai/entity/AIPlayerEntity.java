package com.infinitystones.ai.entity;

import com.infinitystones.ai.AIControlMod;
import com.infinitystones.ai.network.AINetworkHandler;
import com.infinitystones.ai.network.packets.GameStatePacket;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.phys.Vec3;

/**
 * Entity that represents an AI-controlled player
 */
public class AIPlayerEntity extends PathfinderMob {
    // The owner of this AI entity
    private String ownerName = "";
    private Component customName = Component.literal("AI Player");
    private int updateCounter = 0;
    private boolean isExecutingCommand = false;
    private String currentCommand = "";
    private BlockPos targetPosition = null;
    private int stuckTicks = 0;
    private final int MAX_STUCK_TICKS = 60; // 3 seconds at 20 ticks per second
    
    /**
     * Constructs a new AI player entity
     * 
     * @param entityType The entity type
     * @param level The level
     */
    public AIPlayerEntity(EntityType<? extends AIPlayerEntity> entityType, Level level) {
        super(entityType, level);
        this.setCustomName(Component.literal("AI Player"));
        this.setCustomNameVisible(true);
    }
    
    @Override
    protected void registerGoals() {
        // Basic AI goals
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(3, new RandomLookAroundGoal(this));
    }
    
    /**
     * Create default attributes for the entity
     * 
     * @return The default attributes
     */
    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }
    
    /**
     * Called on each tick
     */
    @Override
    public void tick() {
        super.tick();
        
        // Send periodic updates to the web interface
        if (this.level().isClientSide) {
            return;
        }
        
        // Count update ticks
        updateCounter++;
        
        // Send state update to web clients every 20 ticks (1 second)
        if (updateCounter >= 20) {
            sendGameStateUpdate(false);
            updateCounter = 0;
        }
        
        // Check if we're stuck when navigating to a target
        if (targetPosition != null && this.getNavigation().isInProgress()) {
            // Check if we're making progress
            double distanceSq = this.distanceToSqr(Vec3.atCenterOf(targetPosition));
            
            // If we're close enough, we're done
            if (distanceSq < 4.0D) { // 2 blocks distance squared
                this.targetPosition = null;
                this.getNavigation().stop();
                sendGameStateUpdate(true, "Reached destination");
            } else {
                // Check if we're stuck
                if (this.getNavigation().isStuck()) {
                    stuckTicks++;
                    
                    if (stuckTicks >= MAX_STUCK_TICKS) {
                        // We're stuck, stop navigation
                        this.targetPosition = null;
                        this.getNavigation().stop();
                        sendGameStateUpdate(true, "Got stuck while navigating");
                        stuckTicks = 0;
                    }
                } else {
                    stuckTicks = 0;
                }
            }
        }
    }
    
    /**
     * Handle incoming commands from the web interface
     * 
     * @param command The command name
     * @param args The command arguments
     */
    public void handleCommand(String command, String args) {
        if (this.isExecutingCommand) {
            sendGameStateUpdate(true, "Already executing a command, please wait");
            return;
        }
        
        this.isExecutingCommand = true;
        this.currentCommand = command + " " + args;
        
        try {
            switch (command.toLowerCase()) {
                case "move":
                    handleMoveCommand(args);
                    break;
                case "look":
                    handleLookCommand(args);
                    break;
                case "say":
                    handleSayCommand(args);
                    break;
                case "jump":
                    handleJumpCommand();
                    break;
                case "attack":
                    handleAttackCommand();
                    break;
                case "use":
                    handleUseCommand();
                    break;
                case "stop":
                    handleStopCommand();
                    break;
                default:
                    sendGameStateUpdate(true, "Unknown command: " + command);
                    break;
            }
        } catch (Exception e) {
            AIControlMod.LOGGER.error("Error executing command: {}", e.getMessage());
            sendGameStateUpdate(true, "Error executing command: " + e.getMessage());
        } finally {
            this.isExecutingCommand = false;
        }
    }
    
    /**
     * Handle a move command
     * 
     * @param args The arguments
     */
    private void handleMoveCommand(String args) {
        // Check if we have x, y, z coordinates
        String[] parts = args.trim().split("\\s+");
        
        if (parts.length == 3) {
            try {
                // Parse coordinates
                double x = Double.parseDouble(parts[0]);
                double y = Double.parseDouble(parts[1]);
                double z = Double.parseDouble(parts[2]);
                
                // Create target position
                BlockPos targetPos = new BlockPos(Mth.floor(x), Mth.floor(y), Mth.floor(z));
                
                // Navigate to position
                boolean success = this.getNavigation().moveTo(x, y, z, 1.0D);
                
                if (success) {
                    this.targetPosition = targetPos;
                    sendGameStateUpdate(true, "Moving to " + x + ", " + y + ", " + z);
                } else {
                    sendGameStateUpdate(true, "Cannot find path to " + x + ", " + y + ", " + z);
                }
            } catch (NumberFormatException e) {
                sendGameStateUpdate(true, "Invalid coordinates");
            }
        } else if (parts.length == 1 && parts[0].equalsIgnoreCase("forward")) {
            // Move forward
            Vec3 forward = Vec3.directionFromRotation(this.getXRot(), this.getYRot());
            forward = forward.scale(3.0D); // Move 3 blocks forward
            
            Vec3 targetPos = this.position().add(forward);
            boolean success = this.getNavigation().moveTo(targetPos.x, targetPos.y, targetPos.z, 1.0D);
            
            if (success) {
                this.targetPosition = new BlockPos(Mth.floor(targetPos.x), Mth.floor(targetPos.y), Mth.floor(targetPos.z));
                sendGameStateUpdate(true, "Moving forward");
            } else {
                sendGameStateUpdate(true, "Cannot move forward");
            }
        } else {
            sendGameStateUpdate(true, "Invalid move command. Use 'move x y z' or 'move forward'");
        }
    }
    
    /**
     * Handle a look command
     * 
     * @param args The arguments
     */
    private void handleLookCommand(String args) {
        String[] parts = args.trim().split("\\s+");
        
        if (parts.length >= 1) {
            // Look at coordinates
            if (parts.length == 3) {
                try {
                    double x = Double.parseDouble(parts[0]);
                    double y = Double.parseDouble(parts[1]);
                    double z = Double.parseDouble(parts[2]);
                    
                    // Calculate the look vector
                    double dx = x - this.getX();
                    double dy = y - this.getY() - this.getEyeHeight();
                    double dz = z - this.getZ();
                    
                    // Calculate pitch and yaw
                    double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
                    float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
                    float pitch = (float) Math.toDegrees(Math.atan2(-dy, horizontalDistance));
                    
                    // Set rotation
                    this.setYRot(yaw);
                    this.setXRot(pitch);
                    this.setYHeadRot(yaw);
                    
                    sendGameStateUpdate(true, "Looking at " + x + ", " + y + ", " + z);
                } catch (NumberFormatException e) {
                    sendGameStateUpdate(true, "Invalid coordinates");
                }
            } else {
                // Look at direction
                String direction = parts[0].toLowerCase();
                
                switch (direction) {
                    case "north":
                        this.setYRot(180.0F);
                        this.setXRot(0.0F);
                        this.setYHeadRot(180.0F);
                        sendGameStateUpdate(true, "Looking north");
                        break;
                    case "south":
                        this.setYRot(0.0F);
                        this.setXRot(0.0F);
                        this.setYHeadRot(0.0F);
                        sendGameStateUpdate(true, "Looking south");
                        break;
                    case "east":
                        this.setYRot(270.0F);
                        this.setXRot(0.0F);
                        this.setYHeadRot(270.0F);
                        sendGameStateUpdate(true, "Looking east");
                        break;
                    case "west":
                        this.setYRot(90.0F);
                        this.setXRot(0.0F);
                        this.setYHeadRot(90.0F);
                        sendGameStateUpdate(true, "Looking west");
                        break;
                    case "up":
                        this.setXRot(-90.0F);
                        sendGameStateUpdate(true, "Looking up");
                        break;
                    case "down":
                        this.setXRot(90.0F);
                        sendGameStateUpdate(true, "Looking down");
                        break;
                    default:
                        sendGameStateUpdate(true, "Invalid direction. Use north, south, east, west, up, or down");
                        break;
                }
            }
        } else {
            sendGameStateUpdate(true, "Invalid look command. Use 'look x y z' or 'look direction'");
        }
    }
    
    /**
     * Handle a say command
     * 
     * @param args The arguments
     */
    private void handleSayCommand(String args) {
        if (!args.isEmpty()) {
            // Say the message in chat
            if (!this.level().isClientSide && this.level() instanceof ServerLevel) {
                ((ServerLevel) this.level()).getServer().getPlayerList()
                        .broadcastSystemMessage(Component.literal("<AI Player> " + args), false);
                sendGameStateUpdate(true, "Said: " + args);
            }
        } else {
            sendGameStateUpdate(true, "Nothing to say");
        }
    }
    
    /**
     * Handle a jump command
     */
    private void handleJumpCommand() {
        this.jumpFromGround();
        sendGameStateUpdate(true, "Jumped");
    }
    
    /**
     * Handle an attack command
     */
    private void handleAttackCommand() {
        // Look for nearby entities and attack the closest one
        LivingEntity target = this.level().getNearestEntity(
                LivingEntity.class, 
                this.level().getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(3.0D), 
                        e -> e != this && !(e instanceof AIPlayerEntity)), 
                this.getX(), this.getY(), this.getZ(), 3.0D);
        
        if (target != null) {
            this.lookAt(target, 30.0F, 30.0F);
            this.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
            this.doHurtTarget(target);
            sendGameStateUpdate(true, "Attacked " + target.getName().getString());
        } else {
            sendGameStateUpdate(true, "No target found within range");
        }
    }
    
    /**
     * Handle a use command
     */
    private void handleUseCommand() {
        // Use the item in hand or interact with a block
        this.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
        sendGameStateUpdate(true, "Used item in hand");
    }
    
    /**
     * Handle a stop command
     */
    private void handleStopCommand() {
        // Stop all movement
        this.getNavigation().stop();
        this.targetPosition = null;
        sendGameStateUpdate(true, "Stopped all movement");
    }
    
    /**
     * Send a game state update to web clients
     * 
     * @param important Whether this update is important
     */
    private void sendGameStateUpdate(boolean important) {
        sendGameStateUpdate(important, null);
    }
    
    /**
     * Send a game state update to web clients
     * 
     * @param important Whether this update is important
     * @param message An optional message to include
     */
    private void sendGameStateUpdate(boolean important, String message) {
        if (this.level().isClientSide) {
            return;
        }
        
        // Get the entity's position
        Vec3 pos = this.position();
        
        // Get the entity's health
        float health = this.getHealth();
        float maxHealth = this.getMaxHealth();
        
        // Get the entity's dimension
        ResourceKey<Level> dimension = this.level().dimension();
        
        // Get the biome at the entity's position
        Biome biome = this.level().getBiome(this.blockPosition()).value();
        String biomeName = biome.toString();
        
        // Get the time of day
        long time = this.level().getDayTime() % 24000;
        String timeString = getTimeString(time);
        
        // Get the weather
        String weather = getWeatherString();
        
        // Create the game state packet
        GameStatePacket packet = new GameStatePacket();
        packet.setPosition(pos.x, pos.y, pos.z);
        packet.setHealth(health, maxHealth);
        packet.setDimension(dimension.location().toString());
        packet.setBiome(biomeName);
        packet.setTime(timeString);
        packet.setWeather(weather);
        packet.setImportant(important);
        
        if (message != null) {
            packet.setMessage(message);
        }
        
        if (currentCommand != null && !currentCommand.isEmpty()) {
            packet.setLastCommand(currentCommand);
        }
        
        if (this.isExecutingCommand) {
            packet.setAiStatus("Busy");
        } else {
            packet.setAiStatus("Ready");
        }
        
        // Send the packet
        AINetworkHandler.sendToAllWebClients(packet);
    }
    
    /**
     * Get a string representation of the time
     * 
     * @param time The time
     * @return The time string
     */
    private String getTimeString(long time) {
        if (time < 1000) {
            return "Sunrise";
        } else if (time < 6000) {
            return "Day";
        } else if (time < 12000) {
            return "Noon";
        } else if (time < 13000) {
            return "Sunset";
        } else if (time < 18000) {
            return "Night";
        } else if (time < 23000) {
            return "Midnight";
        } else {
            return "Pre-dawn";
        }
    }
    
    /**
     * Get a string representation of the weather
     * 
     * @return The weather string
     */
    private String getWeatherString() {
        if (this.level().isThundering()) {
            return "Thunderstorm";
        } else if (this.level().isRaining()) {
            return "Rain";
        } else {
            return "Clear";
        }
    }
    
    /**
     * Set the owner of this AI entity
     * 
     * @param ownerName The owner's name
     */
    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
        this.setCustomName(Component.literal("AI Player (" + ownerName + ")"));
    }
    
    /**
     * Get the owner of this AI entity
     * 
     * @return The owner's name
     */
    public String getOwnerName() {
        return ownerName;
    }
    
    /**
     * Save entity data to NBT
     * 
     * @param compound The NBT compound
     */
    @Override
    public void addAdditionalSaveData(CompoundTag compound) {
        super.addAdditionalSaveData(compound);
        compound.putString("OwnerName", this.ownerName);
    }
    
    /**
     * Load entity data from NBT
     * 
     * @param compound The NBT compound
     */
    @Override
    public void readAdditionalSaveData(CompoundTag compound) {
        super.readAdditionalSaveData(compound);
        this.ownerName = compound.getString("OwnerName");
        if (!this.ownerName.isEmpty()) {
            this.setCustomName(Component.literal("AI Player (" + ownerName + ")"));
        }
    }
}