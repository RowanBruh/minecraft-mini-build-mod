package com.infinitystones.google;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.infinitystones.config.ModConfig;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Service for performing Google searches
 */
public class GoogleSearchService {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final Gson GSON = new Gson();
    private static final String SEARCH_API_URL = 
            "https://www.googleapis.com/customsearch/v1?key=%s&cx=%s&q=%s";
    
    // Executor for async searches
    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(2);
    
    /**
     * Performs a Google search asynchronously
     * 
     * @param query The search query
     * @return A CompletableFuture with the search results
     */
    public static CompletableFuture<List<String>> searchAsync(String query) {
        return CompletableFuture.supplyAsync(() -> search(query), EXECUTOR);
    }
    
    /**
     * Performs a Google search synchronously
     * 
     * @param query The search query
     * @return The search results
     */
    public static List<String> search(String query) {
        List<String> results = new ArrayList<>();
        
        try {
            // Check if API key is configured
            String apiKey = ModConfig.GOOGLE_API_KEY.get();
            String searchEngineId = ModConfig.GOOGLE_SEARCH_ENGINE_ID.get();
            
            if (apiKey.isEmpty() || searchEngineId.isEmpty()) {
                LOGGER.error("Google API key or search engine ID not configured");
                results.add("Error: Google API not properly configured");
                return results;
            }
            
            // Encode the query
            String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8.toString());
            
            // Build the URL
            String urlString = String.format(SEARCH_API_URL, apiKey, searchEngineId, encodedQuery);
            URL url = new URL(urlString);
            
            // Connect to the API
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
            
            // Check response code
            int responseCode = connection.getResponseCode();
            if (responseCode != 200) {
                LOGGER.error("Failed to get search results: HTTP error code {}", responseCode);
                results.add("Error: Failed to get search results (HTTP " + responseCode + ")");
                return results;
            }
            
            // Read the response
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                
                // Parse the JSON response
                JsonObject response = GSON.fromJson(br, JsonObject.class);
                
                // Check for items
                if (response.has("items")) {
                    JsonArray items = response.getAsJsonArray("items");
                    
                    // Process search items
                    for (JsonElement item : items) {
                        JsonObject itemObj = item.getAsJsonObject();
                        
                        // Get title and snippet
                        String title = itemObj.has("title") ? itemObj.get("title").getAsString() : "No title";
                        String snippet = itemObj.has("snippet") ? itemObj.get("snippet").getAsString() : "No description";
                        
                        // Add to results
                        results.add(title);
                        results.add("  " + snippet);
                        results.add(""); // Empty line
                    }
                } else {
                    results.add("No results found for: " + query);
                }
            }
            
            // Disconnect
            connection.disconnect();
            
        } catch (IOException e) {
            LOGGER.error("Error performing Google search", e);
            results.add("Error: " + e.getMessage());
        }
        
        return results;
    }
}