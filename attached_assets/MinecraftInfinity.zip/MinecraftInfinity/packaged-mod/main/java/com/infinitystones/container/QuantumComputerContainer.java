package com.infinitystones.container;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.blocks.ModBlocks;
import com.infinitystones.items.ModItems;
import com.infinitystones.items.bionic.BionicItems;
import com.infinitystones.items.skiddzie.SkiddzieItems;
import com.infinitystones.items.gods.GreekGodItems;
import com.infinitystones.network.ModNetworking;
import com.infinitystones.network.packet.SearchRequestPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.SlotItemHandler;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.ObjectHolder;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public class QuantumComputerContainer extends AbstractContainerMenu {
    @ObjectHolder(value = InfinityStonesMod.MODID + ":quantum_computer_container", registryName = "minecraft:menu")
    public static MenuType<QuantumComputerContainer> QUANTUM_COMPUTER_CONTAINER;
    
    private final ContainerLevelAccess containerLevelAccess;
    private final BlockPos pos;
    
    // This handler stores the search results
    private final ItemStackHandler searchResultHandler = new ItemStackHandler(9);
    
    // Map of keywords to items for simulated search
    private static final Map<String, List<Supplier<ItemStack>>> SEARCH_DATABASE = new HashMap<>();
    
    static {
        // Initialize search database with keywords and corresponding items
        registerSearch("infinity", () -> new ItemStack(ModItems.SPACE_STONE), 
                () -> new ItemStack(ModItems.MIND_STONE),
                () -> new ItemStack(ModItems.REALITY_STONE),
                () -> new ItemStack(ModItems.POWER_STONE),
                () -> new ItemStack(ModItems.TIME_STONE),
                () -> new ItemStack(ModItems.SOUL_STONE),
                () -> new ItemStack(ModItems.INFINITY_GAUNTLET));
        
        registerSearch("stone", () -> new ItemStack(ModItems.SPACE_STONE), 
                () -> new ItemStack(ModItems.MIND_STONE),
                () -> new ItemStack(ModItems.REALITY_STONE),
                () -> new ItemStack(ModItems.POWER_STONE),
                () -> new ItemStack(ModItems.TIME_STONE),
                () -> new ItemStack(ModItems.SOUL_STONE));
                
        registerSearch("gauntlet", () -> new ItemStack(ModItems.INFINITY_GAUNTLET),
                () -> new ItemStack(ModItems.ADVANCED_INFINITY_GAUNTLET));
                
        registerSearch("bionic", 
                () -> new ItemStack(BionicItems.BIONIC_SWORD),
                () -> new ItemStack(BionicItems.BIONIC_BOW),
                () -> new ItemStack(BionicItems.BIONIC_PICKAXE));
                
        registerSearch("skiddzie", 
                () -> new ItemStack(SkiddzieItems.LUCKY_BLOCK),
                () -> new ItemStack(SkiddzieItems.TRAP_BLOCK),
                () -> new ItemStack(SkiddzieItems.ONE_WAY_BLOCK));
                
        registerSearch("god", 
                () -> new ItemStack(GreekGodItems.ZEUS_LIGHTNING_BOLT),
                () -> new ItemStack(GreekGodItems.POSEIDON_TRIDENT),
                () -> new ItemStack(GreekGodItems.HADES_HELMET),
                () -> new ItemStack(GreekGodItems.APOLLO_BOW),
                () -> new ItemStack(GreekGodItems.ARTEMIS_BOW),
                () -> new ItemStack(GreekGodItems.ARES_SWORD),
                () -> new ItemStack(GreekGodItems.ATHENA_SHIELD),
                () -> new ItemStack(GreekGodItems.HERMES_BOOTS));
                
        registerSearch("boss", () -> new ItemStack(ModItems.SKEPPY_BOSS_SPAWN_EGG));
        
        registerSearch("diamond", () -> new ItemStack(net.minecraft.world.item.Items.DIAMOND), 
                () -> new ItemStack(net.minecraft.world.item.Items.DIAMOND_SWORD),
                () -> new ItemStack(net.minecraft.world.item.Items.DIAMOND_PICKAXE),
                () -> new ItemStack(net.minecraft.world.item.Items.DIAMOND_AXE),
                () -> new ItemStack(net.minecraft.world.item.Items.DIAMOND_SHOVEL),
                () -> new ItemStack(net.minecraft.world.item.Items.DIAMOND_HOE),
                () -> new ItemStack(net.minecraft.world.item.Items.DIAMOND_HELMET),
                () -> new ItemStack(net.minecraft.world.item.Items.DIAMOND_CHESTPLATE),
                () -> new ItemStack(net.minecraft.world.item.Items.DIAMOND_LEGGINGS),
                () -> new ItemStack(net.minecraft.world.item.Items.DIAMOND_BOOTS));
    }
    
    private static void registerSearch(String keyword, Supplier<ItemStack>... items) {
        List<Supplier<ItemStack>> itemList = new ArrayList<>();
        for (Supplier<ItemStack> item : items) {
            itemList.add(item);
        }
        SEARCH_DATABASE.put(keyword.toLowerCase(), itemList);
    }

    // Constructor for server side
    public QuantumComputerContainer(int windowId, Inventory playerInventory, BlockPos pos) {
        this(windowId, playerInventory, ContainerLevelAccess.create(playerInventory.player.level(), pos), pos);
    }

    // Constructor for client side
    public QuantumComputerContainer(int windowId, Inventory playerInventory, FriendlyByteBuf data) {
        this(windowId, playerInventory, ContainerLevelAccess.NULL, data.readBlockPos());
    }

    // Main constructor
    private QuantumComputerContainer(int windowId, Inventory playerInventory, ContainerLevelAccess containerLevelAccess, BlockPos pos) {
        super(QUANTUM_COMPUTER_CONTAINER, windowId);
        this.containerLevelAccess = containerLevelAccess;
        this.pos = pos;

        // Add search result slots
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                addSlot(new OutputSlot(searchResultHandler, col + row * 3, 116 + col * 18, 17 + row * 18));
            }
        }

        // Add player inventory slots
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }

        // Add player hotbar slots
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
        }
    }

    // This method processes the search query and updates the result slots
    public void handleSearch(String query) {
        clearSearchResults();
        
        if (query == null || query.isEmpty()) {
            return;
        }
        
        query = query.toLowerCase().trim();
        
        List<Supplier<ItemStack>> results = SEARCH_DATABASE.getOrDefault(query, new ArrayList<>());
        
        // Fill result slots with found items
        for (int i = 0; i < Math.min(results.size(), 9); i++) {
            searchResultHandler.setStackInSlot(i, results.get(i).get());
        }
    }
    
    // Clear all search results
    private void clearSearchResults() {
        for (int i = 0; i < searchResultHandler.getSlots(); i++) {
            searchResultHandler.setStackInSlot(i, ItemStack.EMPTY);
        }
    }
    
    // This method is called when the player clicks in the GUI window
    @Override
    public @NotNull ItemStack quickMoveStack(@NotNull Player player, int index) {
        ItemStack itemStack = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        
        if (slot.hasItem()) {
            ItemStack slotStack = slot.getItem();
            itemStack = slotStack.copy();
            
            if (index < 9) {
                // If clicking in result area, try to move to player inventory
                if (!this.moveItemStackTo(slotStack, 9, 45, true)) {
                    return ItemStack.EMPTY;
                }
            } else {
                // Cannot move items into the result area
                return ItemStack.EMPTY;
            }
            
            if (slotStack.isEmpty()) {
                slot.set(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
        }
        
        return itemStack;
    }

    @Override
    public boolean stillValid(@NotNull Player player) {
        return stillValid(containerLevelAccess, player, ModBlocks.QUANTUM_COMPUTER);
    }
    
    // Special slot class for the output slots (can only take items out)
    private static class OutputSlot extends SlotItemHandler {
        public OutputSlot(IItemHandler itemHandler, int index, int xPosition, int yPosition) {
            super(itemHandler, index, xPosition, yPosition);
        }
        
        @Override
        public boolean mayPlace(@NotNull ItemStack stack) {
            return false; // Cannot place items into result slots
        }
    }
}