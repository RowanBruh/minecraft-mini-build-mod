package com.infinitystones.util;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.util.StringRepresentable;

/**
 * Enum of all Infinity Stone types
 */
public enum StoneType implements StringRepresentable {
    SPACE("space", new float[]{0.3f, 0.3f, 0.9f}),
    MIND("mind", new float[]{0.9f, 0.9f, 0.2f}),
    REALITY("reality", new float[]{0.9f, 0.2f, 0.2f}),
    POWER("power", new float[]{0.6f, 0.2f, 0.8f}),
    TIME("time", new float[]{0.2f, 0.8f, 0.3f}),
    SOUL("soul", new float[]{0.9f, 0.5f, 0.1f});
    
    private final String name;
    private final float[] color;
    private static final Map<String, StoneType> BY_NAME = new HashMap<>();
    
    /**
     * Creates a new stone type
     * 
     * @param name The name of the stone
     * @param color The RGB color of the stone
     */
    StoneType(String name, float[] color) {
        this.name = name;
        this.color = color;
    }
    
    /**
     * Gets the color of the stone
     * 
     * @return The RGB color as a float array
     */
    public float[] getColor() {
        return color;
    }
    
    /**
     * Gets a stone type by name
     * 
     * @param name The name to look up
     * @return The stone type, or null if not found
     */
    public static StoneType fromName(String name) {
        return BY_NAME.get(name.toLowerCase());
    }
    
    /**
     * Gets the serialized name of the stone
     * 
     * @return The name
     */
    @Override
    public String getSerializedName() {
        return this.name;
    }
    
    /**
     * Initializes the name lookup map
     */
    static {
        for (StoneType stoneType : values()) {
            BY_NAME.put(stoneType.getSerializedName(), stoneType);
        }
    }
}