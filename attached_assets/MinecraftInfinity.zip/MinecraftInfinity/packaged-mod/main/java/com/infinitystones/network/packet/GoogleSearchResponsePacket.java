package com.infinitystones.network.packet;

import com.infinitystones.blockentities.GoogleComputerBlockEntity;
import com.infinitystones.client.gui.GoogleComputerScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class GoogleSearchResponsePacket {
    private final List<String> searchResults;
    private final BlockPos computerPos;
    
    public GoogleSearchResponsePacket(List<String> searchResults, BlockPos computerPos) {
        this.searchResults = searchResults;
        this.computerPos = computerPos;
    }
    
    public GoogleSearchResponsePacket(FriendlyByteBuf buf) {
        // Read the number of results
        int resultCount = buf.readInt();
        this.searchResults = new ArrayList<>(resultCount);
        
        // Read each result string
        for (int i = 0; i < resultCount; i++) {
            this.searchResults.add(buf.readUtf());
        }
        
        // Read the computer position
        this.computerPos = buf.readBlockPos();
    }
    
    public void toBytes(FriendlyByteBuf buf) {
        // Write the number of results
        buf.writeInt(searchResults.size());
        
        // Write each result string
        for (String result : searchResults) {
            buf.writeUtf(result);
        }
        
        // Write the computer position
        buf.writeBlockPos(computerPos);
    }
    
    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // Execute on the client
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
                Minecraft minecraft = Minecraft.getInstance();
                if (minecraft.level != null) {
                    BlockEntity blockEntity = minecraft.level.getBlockEntity(computerPos);
                    if (blockEntity instanceof GoogleComputerBlockEntity googleComputer) {
                        // Update the block entity with search results
                        updateComputerResults(googleComputer);
                        
                        // Update the screen if it's open
                        if (minecraft.screen instanceof GoogleComputerScreen screen) {
                            screen.updateSearchResults(searchResults);
                        }
                    }
                }
            });
        });
        
        return true;
    }
    
    private void updateComputerResults(GoogleComputerBlockEntity computer) {
        // This would need to be implemented to update the computer's stored results
        // But we would need client-side access to the block entity's fields
        // This is typically handled by the screen rendering the results directly
    }
}