package com.infinitystones.menu;

import com.infinitystones.blockentities.GoogleComputerBlockEntity;
import com.infinitystones.blocks.ModBlocks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.items.SlotItemHandler;

/**
 * Menu for the Google Computer block
 */
public class GoogleComputerMenu extends AbstractContainerMenu {
    private final GoogleComputerBlockEntity blockEntity;
    private final ContainerLevelAccess levelAccess;
    
    // Client constructor
    public GoogleComputerMenu(int containerId, Inventory inventory, FriendlyByteBuf extraData) {
        this(containerId, inventory, inventory.player.level().getBlockEntity(extraData.readBlockPos()), 
                ContainerLevelAccess.NULL);
    }
    
    // Server constructor
    public GoogleComputerMenu(int containerId, Inventory inventory, BlockEntity entity, 
                             ContainerLevelAccess levelAccess) {
        super(ModMenuTypes.GOOGLE_COMPUTER_MENU.get(), containerId);
        
        this.blockEntity = (GoogleComputerBlockEntity) entity;
        this.levelAccess = levelAccess;
        
        // Add player inventory slots
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(inventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
        
        // Add player hotbar slots
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(inventory, col, 8 + col * 18, 142));
        }
    }
    
    /**
     * Gets the search query
     * 
     * @return The search query
     */
    public String getSearchQuery() {
        return this.blockEntity.getSearchQuery();
    }
    
    /**
     * Sets the search query
     * 
     * @param query The search query
     */
    public void setSearchQuery(String query) {
        this.blockEntity.setSearchQuery(query);
    }
    
    /**
     * Gets the search results
     * 
     * @return The search results
     */
    public String[] getSearchResults() {
        return this.blockEntity.getSearchResults();
    }
    
    @Override
    public boolean stillValid(Player player) {
        return AbstractContainerMenu.stillValid(this.levelAccess, player, ModBlocks.GOOGLE_COMPUTER.get());
    }
    
    // Handle shift-clicking items (not needed for this menu)
    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }
}