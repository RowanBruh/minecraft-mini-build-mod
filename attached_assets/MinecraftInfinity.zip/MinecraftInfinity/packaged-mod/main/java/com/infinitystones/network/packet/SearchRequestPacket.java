package com.infinitystones.network.packet;

import com.infinitystones.container.QuantumComputerContainer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SearchRequestPacket {
    private final String searchQuery;
    private final BlockPos pos;
    
    public SearchRequestPacket(String searchQuery, BlockPos pos) {
        this.searchQuery = searchQuery;
        this.pos = pos;
    }
    
    public static void encode(SearchRequestPacket message, FriendlyByteBuf buffer) {
        buffer.writeUtf(message.searchQuery);
        buffer.writeBlockPos(message.pos);
    }
    
    public static SearchRequestPacket decode(FriendlyByteBuf buffer) {
        String query = buffer.readUtf(32767);
        BlockPos pos = buffer.readBlockPos();
        return new SearchRequestPacket(query, pos);
    }
    
    public static void handle(SearchRequestPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) {
                AbstractContainerMenu container = player.containerMenu;
                if (container instanceof QuantumComputerContainer && player.blockPosition().closerThan(message.pos, 10)) {
                    // Process the search
                    ((QuantumComputerContainer) container).handleSearch(message.searchQuery);
                }
            }
        });
        context.setPacketHandled(true);
    }
}