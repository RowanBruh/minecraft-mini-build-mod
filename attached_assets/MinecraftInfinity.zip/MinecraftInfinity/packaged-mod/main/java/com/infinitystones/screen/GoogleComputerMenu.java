package com.infinitystones.screen;

import com.infinitystones.blockentities.GoogleComputerBlockEntity;
import com.infinitystones.network.ModPackets;
import com.infinitystones.network.packets.GoogleSearchC2SPacket;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.items.SlotItemHandler;

/**
 * Menu for the Google Computer screen
 */
public class GoogleComputerMenu extends AbstractContainerMenu {
    private final ContainerLevelAccess levelAccess;
    private final BlockPos blockPos;
    private String currentQuery = "";
    private List<String> searchResults = new ArrayList<>();

    /**
     * Constructs a new menu from the client side
     * 
     * @param windowId The window ID
     * @param playerInventory The player's inventory
     * @param data Extra data from the client
     */
    public GoogleComputerMenu(int windowId, Inventory playerInventory, FriendlyByteBuf data) {
        this(windowId, playerInventory, data.readBlockPos());
    }
    
    /**
     * Constructs a new menu
     * 
     * @param windowId The window ID
     * @param playerInventory The player's inventory
     * @param pos The block position
     */
    public GoogleComputerMenu(int windowId, Inventory playerInventory, BlockPos pos) {
        super(ModMenuTypes.GOOGLE_COMPUTER.get(), windowId);
        this.blockPos = pos;
        this.levelAccess = ContainerLevelAccess.create(playerInventory.player.level(), pos);
        
        // Get block entity and load data
        BlockEntity entity = playerInventory.player.level().getBlockEntity(pos);
        if (entity instanceof GoogleComputerBlockEntity computer) {
            this.currentQuery = computer.getSearchQuery();
            this.searchResults = computer.getSearchResults();
            
            // Add inventory slots
            entity.getCapability(ForgeCapabilities.ITEM_HANDLER).ifPresent(handler -> {
                // Power source slot
                this.addSlot(new SlotItemHandler(handler, 0, 15, 15));
            });
        }
    }
    
    /**
     * Sets the search query
     * 
     * @param query The search query
     */
    public void setSearchQuery(String query) {
        this.currentQuery = query;
        
        // Send to the server
        ModPackets.sendToServer(new GoogleSearchC2SPacket(query, blockPos));
    }
    
    /**
     * Sets the search results
     * 
     * @param results The search results
     */
    public void setSearchResults(List<String> results) {
        this.searchResults = results;
    }
    
    /**
     * Gets the current search query
     * 
     * @return The current query
     */
    public String getCurrentQuery() {
        return currentQuery;
    }
    
    /**
     * Gets the search results
     * 
     * @return The search results
     */
    public List<String> getSearchResults() {
        return searchResults;
    }
    
    /**
     * Gets the block position
     * 
     * @return The block position
     */
    public BlockPos getBlockPos() {
        return blockPos;
    }
    
    /**
     * Checks if the player can interact with the menu
     * 
     * @param player The player
     * @return True if the player can interact
     */
    @Override
    public boolean stillValid(Player player) {
        return stillValid(this.levelAccess, player, player.level().getBlockState(blockPos).getBlock());
    }
    
    /**
     * Handles item transfers between slots (none for this menu)
     * 
     * @param player The player
     * @param slotId The slot ID
     * @return The moved item stack
     */
    @Override
    public net.minecraft.world.item.ItemStack quickMoveStack(net.minecraft.world.entity.player.Player player, int slotId) {
        return net.minecraft.world.item.ItemStack.EMPTY;
    }
}