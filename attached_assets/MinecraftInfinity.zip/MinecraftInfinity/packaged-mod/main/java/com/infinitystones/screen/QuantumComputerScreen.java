package com.infinitystones.screen;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.container.QuantumComputerContainer;
import com.infinitystones.network.ModNetworking;
import com.infinitystones.network.packet.SearchRequestPacket;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import org.jetbrains.annotations.NotNull;

public class QuantumComputerScreen extends AbstractContainerScreen<QuantumComputerContainer> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(InfinityStonesMod.MODID, "textures/gui/quantum_computer.png");
    
    private EditBox searchBox;
    private Button searchButton;
    
    public QuantumComputerScreen(QuantumComputerContainer container, Inventory inventory, Component title) {
        super(container, inventory, title);
        
        // Adjust GUI size as needed
        this.imageWidth = 176;
        this.imageHeight = 166;
    }
    
    @Override
    protected void init() {
        super.init();
        
        // Center the GUI
        int x = (this.width - this.imageWidth) / 2;
        int y = (this.height - this.imageHeight) / 2;
        
        // Create search input field
        this.searchBox = new EditBox(this.font, x + 8, y + 20, 85, 18, Component.translatable("screen.infinitystones.quantum_computer.search"));
        this.searchBox.setMaxLength(50);
        this.searchBox.setBordered(true);
        this.searchBox.setVisible(true);
        this.searchBox.setTextColor(0xFFFFFF);
        this.addRenderableWidget(this.searchBox);
        
        // Create search button
        this.searchButton = Button.builder(Component.translatable("screen.infinitystones.quantum_computer.search_button"), button -> {
            if (!this.searchBox.getValue().isEmpty()) {
                // Send search query to server
                ModNetworking.INSTANCE.sendToServer(new SearchRequestPacket(this.searchBox.getValue(), this.menu.pos));
            }
        }).pos(x + 8, y + 42).size(85, 20).build();
        this.addRenderableWidget(this.searchButton);
    }
    
    @Override
    public void render(@NotNull GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTicks);
        this.renderTooltip(graphics, mouseX, mouseY);
        
        // Render the screen title
        graphics.drawString(this.font, this.title, this.leftPos + 8, this.topPos + 6, 0x404040, false);
    }
    
    @Override
    protected void renderBg(@NotNull GuiGraphics graphics, float partialTicks, int mouseX, int mouseY) {
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, TEXTURE);
        
        int x = (this.width - this.imageWidth) / 2;
        int y = (this.height - this.imageHeight) / 2;
        
        // Draw the background
        graphics.blit(TEXTURE, x, y, 0, 0, this.imageWidth, this.imageHeight);
    }
    
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.searchBox.isFocused()) {
            if (keyCode == 257 || keyCode == 335) { // Enter key
                if (!this.searchBox.getValue().isEmpty()) {
                    // Send search query to server
                    ModNetworking.INSTANCE.sendToServer(new SearchRequestPacket(this.searchBox.getValue(), this.menu.pos));
                }
                return true;
            }
            return this.searchBox.keyPressed(keyCode, scanCode, modifiers);
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}