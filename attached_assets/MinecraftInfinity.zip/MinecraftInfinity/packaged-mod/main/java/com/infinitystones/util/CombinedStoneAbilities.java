package com.infinitystones.util;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/**
 * Utility for combined stone abilities
 */
public class CombinedStoneAbilities {
    
    /**
     * Uses a combined ability
     * 
     * @param player The player
     * @param isInfected Whether the stones are infected
     * @param combinationId The combination ID
     * @return True if the ability was used
     */
    public static boolean useCombinedAbility(ServerPlayer player, boolean isInfected, String combinationId) {
        // Parse the stones in the combination
        Set<StoneType> stones = parseCombination(combinationId);
        
        if (stones.isEmpty()) {
            return false;
        }
        
        // Check for specific combinations
        if (stones.contains(StoneType.SPACE) && stones.contains(StoneType.REALITY)) {
            return useSpaceRealityCombination(player, isInfected, stones);
        } else if (stones.contains(StoneType.POWER) && stones.contains(StoneType.SOUL)) {
            return usePowerSoulCombination(player, isInfected, stones);
        } else if (stones.contains(StoneType.MIND) && stones.contains(StoneType.TIME)) {
            return useMindTimeCombination(player, isInfected, stones);
        } else {
            // Generic combination
            return useGenericCombination(player, isInfected, stones);
        }
    }
    
    /**
     * Uses the snap ability (all stones)
     * 
     * @param player The player
     * @param isInfected Whether the stones are infected
     * @return True if the ability was used
     */
    public static boolean useSnapAbility(ServerPlayer player, boolean isInfected) {
        // TODO: Implement the snap ability
        // This is a very powerful ability that should be carefully balanced
        
        // For now, just apply a set of powerful buffs
        int duration = isInfected ? 2400 : 1200; // 2 min / 1 min
        
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, duration, 3));
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, duration, 2));
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, duration, 2));
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0));
        player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, duration, 0));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 2));
        player.addEffect(new MobEffectInstance(MobEffects.JUMP, duration, 2));
        player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, duration, 0));
        player.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, duration, 4));
        
        if (isInfected) {
            // Additional power from infected stones
            player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, duration, 4));
            
            // Side effects
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 300, 1));
            player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 600, 2));
        }
        
        // Create visual effects
        for (StoneType stoneType : StoneType.values()) {
            StoneAbilities.createAbilityEffects(player.level(), player.position(), stoneType, isInfected);
        }
        
        return true;
    }
    
    /**
     * Parses a combination ID into a set of stone types
     * 
     * @param combinationId The combination ID
     * @return The set of stone types
     */
    private static Set<StoneType> parseCombination(String combinationId) {
        Set<StoneType> stones = new HashSet<>();
        
        if (combinationId == null || combinationId.isEmpty()) {
            return stones;
        }
        
        String[] parts = combinationId.split("_");
        for (String part : parts) {
            StoneType stoneType = StoneType.fromName(part);
            if (stoneType != null) {
                stones.add(stoneType);
            }
        }
        
        return stones;
    }
    
    /**
     * Uses a combination of Space and Reality stones
     * 
     * @param player The player
     * @param isInfected Whether the stones are infected
     * @param stones The set of stones
     * @return True if the ability was used
     */
    private static boolean useSpaceRealityCombination(ServerPlayer player, boolean isInfected, Set<StoneType> stones) {
        // Space + Reality = Dimensional manipulation and illusions
        int duration = isInfected ? 1200 : 600;
        
        // Basic effects
        player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, duration, 0));
        
        // Each additional stone enhances the effect
        if (stones.contains(StoneType.POWER)) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, duration, isInfected ? 2 : 1));
        }
        
        if (stones.contains(StoneType.MIND)) {
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, duration, 0));
        }
        
        if (stones.contains(StoneType.TIME)) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, isInfected ? 2 : 1));
        }
        
        if (stones.contains(StoneType.SOUL)) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, duration, isInfected ? 1 : 0));
        }
        
        // Side effects for infected stones
        if (isInfected) {
            player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 300, 1));
        }
        
        // Create visual effects for each stone
        for (StoneType stoneType : stones) {
            StoneAbilities.createAbilityEffects(player.level(), player.position(), stoneType, isInfected);
        }
        
        return true;
    }
    
    /**
     * Uses a combination of Power and Soul stones
     * 
     * @param player The player
     * @param isInfected Whether the stones are infected
     * @param stones The set of stones
     * @return True if the ability was used
     */
    private static boolean usePowerSoulCombination(ServerPlayer player, boolean isInfected, Set<StoneType> stones) {
        // Power + Soul = Life force manipulation and enhanced strength
        int duration = isInfected ? 1200 : 600;
        
        // Basic effects
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, duration, isInfected ? 2 : 1));
        player.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, duration, isInfected ? 2 : 1));
        
        // Heal player
        player.heal(isInfected ? 10.0f : 6.0f);
        
        // Each additional stone enhances the effect
        if (stones.contains(StoneType.SPACE)) {
            player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, duration, 0));
        }
        
        if (stones.contains(StoneType.MIND)) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, duration, isInfected ? 1 : 0));
        }
        
        if (stones.contains(StoneType.TIME)) {
            player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, duration, isInfected ? 2 : 1));
        }
        
        if (stones.contains(StoneType.REALITY)) {
            player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0));
        }
        
        // Side effects for infected stones
        if (isInfected) {
            player.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 0));
        }
        
        // Create visual effects for each stone
        for (StoneType stoneType : stones) {
            StoneAbilities.createAbilityEffects(player.level(), player.position(), stoneType, isInfected);
        }
        
        return true;
    }
    
    /**
     * Uses a combination of Mind and Time stones
     * 
     * @param player The player
     * @param isInfected Whether the stones are infected
     * @param stones The set of stones
     * @return True if the ability was used
     */
    private static boolean useMindTimeCombination(ServerPlayer player, boolean isInfected, Set<StoneType> stones) {
        // Mind + Time = Enhanced perception and time manipulation
        int duration = isInfected ? 1200 : 600;
        
        // Basic effects
        player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, duration, 0));
        player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, duration, isInfected ? 2 : 1));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, isInfected ? 2 : 1));
        
        // Each additional stone enhances the effect
        if (stones.contains(StoneType.SPACE)) {
            player.addEffect(new MobEffectInstance(MobEffects.JUMP, duration, isInfected ? 2 : 1));
        }
        
        if (stones.contains(StoneType.POWER)) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, duration, isInfected ? 1 : 0));
        }
        
        if (stones.contains(StoneType.SOUL)) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, duration, isInfected ? 1 : 0));
        }
        
        if (stones.contains(StoneType.REALITY)) {
            player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, duration, 0));
        }
        
        // Side effects for infected stones
        if (isInfected) {
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 0));
        }
        
        // Create visual effects for each stone
        for (StoneType stoneType : stones) {
            StoneAbilities.createAbilityEffects(player.level(), player.position(), stoneType, isInfected);
        }
        
        return true;
    }
    
    /**
     * Uses a generic combination of stones
     * 
     * @param player The player
     * @param isInfected Whether the stones are infected
     * @param stones The set of stones
     * @return True if the ability was used
     */
    private static boolean useGenericCombination(ServerPlayer player, boolean isInfected, Set<StoneType> stones) {
        // Generic combination - apply effects based on the stones present
        int duration = 400 + (stones.size() * 200);
        
        if (isInfected) {
            duration *= 1.5;
        }
        
        // Apply effects based on stones
        if (stones.contains(StoneType.SPACE)) {
            player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, duration, 0));
        }
        
        if (stones.contains(StoneType.MIND)) {
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, duration, 0));
        }
        
        if (stones.contains(StoneType.REALITY)) {
            player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0));
        }
        
        if (stones.contains(StoneType.POWER)) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, duration, isInfected ? 1 : 0));
        }
        
        if (stones.contains(StoneType.TIME)) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, isInfected ? 1 : 0));
        }
        
        if (stones.contains(StoneType.SOUL)) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, duration, isInfected ? 1 : 0));
        }
        
        // Side effects for infected stones
        if (isInfected) {
            player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 200, 1));
        }
        
        // Create visual effects for each stone
        for (StoneType stoneType : stones) {
            StoneAbilities.createAbilityEffects(player.level(), player.position(), stoneType, isInfected);
        }
        
        return true;
    }
}