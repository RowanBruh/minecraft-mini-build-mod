package com.infinitystones.network;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.network.packets.GauntletOpenC2SPacket;
import com.infinitystones.network.packets.GoogleSearchC2SPacket;
import com.infinitystones.network.packets.StoneAbilityC2SPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.ChannelBuilder;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.SimpleChannel;

/**
 * Networking setup for the mod
 */
public class ModPackets {
    /**
     * The channel for mod packets
     */
    private static SimpleChannel CHANNEL;
    
    /**
     * Registers all network packets
     */
    public static void register() {
        // Create the channel
        CHANNEL = ChannelBuilder.named(new ResourceLocation(InfinityStonesMod.MOD_ID, "main"))
                .networkProtocolVersion(1)
                .clientAcceptedVersions((status, version) -> true)
                .serverAcceptedVersions((status, version) -> true)
                .simpleChannel();
        
        // Register packets
        CHANNEL.messageBuilder(StoneAbilityC2SPacket.class)
                .encoder(StoneAbilityC2SPacket::encode)
                .decoder(StoneAbilityC2SPacket::new)
                .consumerMainThread(StoneAbilityC2SPacket::handle)
                .add();
        
        CHANNEL.messageBuilder(GauntletOpenC2SPacket.class)
                .encoder(GauntletOpenC2SPacket::encode)
                .decoder(GauntletOpenC2SPacket::new)
                .consumerMainThread(GauntletOpenC2SPacket::handle)
                .add();
        
        CHANNEL.messageBuilder(GoogleSearchC2SPacket.class)
                .encoder(GoogleSearchC2SPacket::encode)
                .decoder(GoogleSearchC2SPacket::new)
                .consumerMainThread(GoogleSearchC2SPacket::handle)
                .add();
    }
    
    /**
     * Sends a packet to the server
     * 
     * @param packet The packet to send
     */
    public static void sendToServer(Object packet) {
        CHANNEL.send(packet, PacketDistributor.SERVER.noArg());
    }
    
    /**
     * Sends a packet to a specific player
     * 
     * @param packet The packet to send
     * @param player The player to send to
     */
    public static void sendToPlayer(Object packet, ServerPlayer player) {
        CHANNEL.send(packet, PacketDistributor.PLAYER.with(player));
    }
    
    /**
     * Sends a packet to all players
     * 
     * @param packet The packet to send
     */
    public static void sendToAll(Object packet) {
        CHANNEL.send(packet, PacketDistributor.ALL.noArg());
    }
    
    /**
     * Sends a packet to all players near a position
     * 
     * @param packet The packet to send
     * @param packetDistributor The distributor with position information
     */
    public static void sendToAllNearby(Object packet, PacketDistributor.PacketTarget packetDistributor) {
        CHANNEL.send(packet, packetDistributor);
    }
}