package com.infinitystones.network.packets;

import com.infinitystones.util.CombinedStoneAbilities;
import com.infinitystones.util.StoneAbilities;
import com.infinitystones.util.StoneType;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/**
 * Packet for stone ability activation
 */
public class StoneAbilityC2SPacket {
    private final StoneType stoneType;
    private final boolean isInfected;
    private final boolean isSnap;
    private final String combinationId;
    
    /**
     * Constructs a new packet for a single stone ability
     * 
     * @param stoneType The stone type
     * @param isInfected Whether the stone is infected
     */
    public StoneAbilityC2SPacket(StoneType stoneType, boolean isInfected) {
        this.stoneType = stoneType;
        this.isInfected = isInfected;
        this.isSnap = false;
        this.combinationId = null;
    }
    
    /**
     * Constructs a new packet for a snap ability
     * 
     * @param stoneType The stone type (null for snap)
     * @param isInfected Whether the stones are infected
     * @param isSnap Whether this is a snap
     */
    public StoneAbilityC2SPacket(StoneType stoneType, boolean isInfected, boolean isSnap) {
        this.stoneType = stoneType;
        this.isInfected = isInfected;
        this.isSnap = isSnap;
        this.combinationId = null;
    }
    
    /**
     * Constructs a new packet for a combined ability
     * 
     * @param stoneType The stone type (null for combined abilities)
     * @param isInfected Whether the stones are infected
     * @param isSnap Whether this is a snap
     * @param combinationId The combination ID for combined abilities
     */
    public StoneAbilityC2SPacket(StoneType stoneType, boolean isInfected, boolean isSnap, String combinationId) {
        this.stoneType = stoneType;
        this.isInfected = isInfected;
        this.isSnap = isSnap;
        this.combinationId = combinationId;
    }
    
    /**
     * Creates a packet from the buffer
     * 
     * @param buf The buffer to read from
     */
    public StoneAbilityC2SPacket(FriendlyByteBuf buf) {
        // Read stone type (may be null)
        if (buf.readBoolean()) {
            String stoneTypeName = buf.readUtf();
            this.stoneType = StoneType.fromName(stoneTypeName);
        } else {
            this.stoneType = null;
        }
        
        this.isInfected = buf.readBoolean();
        this.isSnap = buf.readBoolean();
        
        // Read combination ID (may be null)
        if (buf.readBoolean()) {
            this.combinationId = buf.readUtf();
        } else {
            this.combinationId = null;
        }
    }
    
    /**
     * Encodes the packet to the buffer
     * 
     * @param buf The buffer to write to
     */
    public void encode(FriendlyByteBuf buf) {
        // Write stone type (may be null)
        buf.writeBoolean(stoneType != null);
        if (stoneType != null) {
            buf.writeUtf(stoneType.getSerializedName());
        }
        
        buf.writeBoolean(isInfected);
        buf.writeBoolean(isSnap);
        
        // Write combination ID (may be null)
        buf.writeBoolean(combinationId != null);
        if (combinationId != null) {
            buf.writeUtf(combinationId);
        }
    }
    
    /**
     * Handles the packet on the server
     * 
     * @param supplier The supplier for the network event
     * @return True if the packet was handled successfully
     */
    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // Server-side handling
            ServerPlayer player = context.getSender();
            if (player != null) {
                if (isSnap) {
                    // Handle snap ability
                    CombinedStoneAbilities.useSnapAbility(player, isInfected);
                } else if (combinationId != null) {
                    // Handle combined ability
                    CombinedStoneAbilities.useCombinedAbility(player, isInfected, combinationId);
                } else if (stoneType != null) {
                    // Handle single stone ability
                    StoneAbilities.useStoneAbility(player, stoneType, isInfected);
                }
            }
        });
        
        context.setPacketHandled(true);
        return true;
    }
}