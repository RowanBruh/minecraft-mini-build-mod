package com.infinitystones.util;

import com.infinitystones.config.ModConfig;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Utility for stone abilities
 */
public class StoneAbilities {
    
    /**
     * Uses a stone ability
     * 
     * @param player The player using the ability
     * @param stoneType The type of stone
     * @param isInfected Whether the stone is infected
     * @return True if the ability was used
     */
    public static boolean useStoneAbility(ServerPlayer player, StoneType stoneType, boolean isInfected) {
        // Check cooldown
        if (CooldownTracker.isOnCooldown(player.getUUID(), stoneType)) {
            return false;
        }
        
        // Apply cooldown
        CooldownTracker.applyCooldown(player.getUUID(), stoneType, ModConfig.STONE_ABILITY_COOLDOWN.get());
        
        // Use ability based on stone type
        boolean success = false;
        switch (stoneType) {
            case SPACE -> success = useSpaceStoneAbility(player, isInfected);
            case MIND -> success = useMindStoneAbility(player, isInfected);
            case REALITY -> success = useRealityStoneAbility(player, isInfected);
            case POWER -> success = usePowerStoneAbility(player, isInfected);
            case TIME -> success = useTimeStoneAbility(player, isInfected);
            case SOUL -> success = useSoulStoneAbility(player, isInfected);
        }
        
        // Create particles and play sound on success
        if (success) {
            createAbilityEffects(player.level(), player.position(), stoneType, isInfected);
        }
        
        return success;
    }
    
    /**
     * Creates visual and sound effects for an ability
     * 
     * @param level The level
     * @param position The position
     * @param stoneType The stone type
     * @param isInfected Whether the stone is infected
     */
    public static void createAbilityEffects(Level level, Vec3 position, StoneType stoneType, boolean isInfected) {
        if (level instanceof ServerLevel serverLevel) {
            // Create particles based on stone type
            float[] color = stoneType.getColor();
            
            for (int i = 0; i < 50; i++) {
                double offsetX = level.random.nextGaussian() * 0.8;
                double offsetY = level.random.nextGaussian() * 0.8;
                double offsetZ = level.random.nextGaussian() * 0.8;
                
                serverLevel.sendParticles(
                        ParticleTypes.ENTITY_EFFECT,
                        position.x + offsetX,
                        position.y + offsetY + 1.0,
                        position.z + offsetZ,
                        1,
                        color[0],
                        color[1],
                        color[2],
                        1.0
                );
            }
            
            // Add infected particles if applicable
            if (isInfected) {
                for (int i = 0; i < 20; i++) {
                    double offsetX = level.random.nextGaussian() * 0.5;
                    double offsetY = level.random.nextGaussian() * 0.5;
                    double offsetZ = level.random.nextGaussian() * 0.5;
                    
                    serverLevel.sendParticles(
                            ParticleTypes.SMOKE,
                            position.x + offsetX,
                            position.y + offsetY + 1.0,
                            position.z + offsetZ,
                            1,
                            0.0,
                            0.0,
                            0.0,
                            0.05
                    );
                }
            }
            
            // Play sound effect
            level.playSound(null, position.x, position.y, position.z,
                    isInfected ? SoundEvents.WITHER_AMBIENT : SoundEvents.ENCHANTMENT_TABLE_USE,
                    SoundSource.PLAYERS, 1.0F, isInfected ? 0.8F : 1.2F);
        }
    }
    
    /**
     * Uses the Space Stone ability
     * Space Stone: Teleportation and movement manipulation
     * 
     * @param player The player
     * @param isInfected Whether the stone is infected
     * @return True if the ability was used
     */
    private static boolean useSpaceStoneAbility(ServerPlayer player, boolean isInfected) {
        // Default ability: Teleport forward
        double distance = isInfected ? 50.0 : 30.0;
        
        Vec3 lookVec = player.getLookAngle();
        Vec3 targetPos = player.position().add(lookVec.scale(distance));
        
        // Perform ray tracing to find a safe location
        // This is a simplified approach; a full implementation would do proper collision detection
        for (int i = 0; i < (int)distance; i++) {
            Vec3 checkPos = player.position().add(lookVec.scale(i));
            if (player.level().getBlockState(player.level().getBlockPos(checkPos)).isAir()) {
                targetPos = checkPos;
            } else {
                break;
            }
        }
        
        // Teleport player
        boolean success = player.teleport(targetPos.x, targetPos.y, targetPos.z, true);
        
        // Apply side effects if infected
        if (success && isInfected) {
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 0));
            player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 1));
        }
        
        return success;
    }
    
    /**
     * Uses the Mind Stone ability
     * Mind Stone: Intelligence, mind control, and psionic powers
     * 
     * @param player The player
     * @param isInfected Whether the stone is infected
     * @return True if the ability was used
     */
    private static boolean useMindStoneAbility(ServerPlayer player, boolean isInfected) {
        // Default ability: Mind control nearby entities
        int range = ModConfig.STONE_ABILITY_RANGE.get() * (isInfected ? 2 : 1);
        
        List<LivingEntity> entities = player.level().getEntitiesOfClass(
                LivingEntity.class,
                new AABB(player.getX() - range, player.getY() - range, player.getZ() - range,
                        player.getX() + range, player.getY() + range, player.getZ() + range),
                e -> e != player && !e.isInvulnerable());
        
        boolean success = false;
        
        for (LivingEntity entity : entities) {
            // Make monsters attack each other
            if (entity.getTarget() != null && entity.getTarget() instanceof LivingEntity) {
                LivingEntity newTarget = null;
                
                // Find a new target that isn't the player
                for (LivingEntity potentialTarget : entities) {
                    if (potentialTarget != entity && potentialTarget != player) {
                        newTarget = potentialTarget;
                        break;
                    }
                }
                
                if (newTarget != null) {
                    entity.setTarget(newTarget);
                    success = true;
                }
            }
            
            // Apply effects
            if (isInfected) {
                entity.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 300, 1));
                entity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 200, 0));
            } else {
                entity.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 0));
            }
            
            success = true;
        }
        
        // Apply beneficial effects to the player
        player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1200, 0));
        
        if (isInfected) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
            player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 1200, 2));
            // Side effect
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 0));
        } else {
            player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 600, 1));
        }
        
        return success || !entities.isEmpty();
    }
    
    /**
     * Uses the Reality Stone ability
     * Reality Stone: Reality manipulation and illusions
     * 
     * @param player The player
     * @param isInfected Whether the stone is infected
     * @return True if the ability was used
     */
    private static boolean useRealityStoneAbility(ServerPlayer player, boolean isInfected) {
        // Default ability: Invisibility and illusion
        int duration = isInfected ? 1200 : 600; // 1 minute / 30 seconds
        
        // Apply invisibility to player
        player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, duration, 0));
        
        // Additional effects for infected version
        if (isInfected) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, duration, 1));
            player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0));
            
            // Side effect
            player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 300, 2));
        } else {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, duration / 2, 0));
        }
        
        return true;
    }
    
    /**
     * Uses the Power Stone ability
     * Power Stone: Energy manipulation and superhuman strength
     * 
     * @param player The player
     * @param isInfected Whether the stone is infected
     * @return True if the ability was used
     */
    private static boolean usePowerStoneAbility(ServerPlayer player, boolean isInfected) {
        // Default ability: Energy blast
        int range = ModConfig.STONE_ABILITY_RANGE.get() * (isInfected ? 2 : 1);
        float damage = isInfected ? 10.0f : 6.0f;
        
        List<LivingEntity> entities = player.level().getEntitiesOfClass(
                LivingEntity.class,
                new AABB(player.getX() - range, player.getY() - range, player.getZ() - range,
                        player.getX() + range, player.getY() + range, player.getZ() + range),
                e -> e != player && !e.isInvulnerable());
        
        boolean success = false;
        
        for (LivingEntity entity : entities) {
            // Calculate damage based on distance
            double distance = player.distanceTo(entity);
            float actualDamage = damage * (float)(1.0 - (distance / range));
            
            if (actualDamage > 0) {
                entity.hurt(player.damageSources().playerAttack(player), actualDamage);
                
                // Apply knockback
                Vec3 knockback = entity.position().subtract(player.position()).normalize();
                entity.setDeltaMovement(knockback.scale(isInfected ? 2.0 : 1.0));
                
                success = true;
            }
        }
        
        // Apply strength to player
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, isInfected ? 600 : 300, isInfected ? 2 : 1));
        
        // Side effects for infected version
        if (isInfected) {
            player.hurt(player.damageSources().magic(), 2.0f);
        }
        
        return success || !entities.isEmpty();
    }
    
    /**
     * Uses the Time Stone ability
     * Time Stone: Time manipulation
     * 
     * @param player The player
     * @param isInfected Whether the stone is infected
     * @return True if the ability was used
     */
    private static boolean useTimeStoneAbility(ServerPlayer player, boolean isInfected) {
        // Default ability: Slow time for entities, speed up for player
        int range = ModConfig.STONE_ABILITY_RANGE.get() * (isInfected ? 2 : 1);
        int duration = isInfected ? 400 : 200; // 20 seconds / 10 seconds
        
        List<LivingEntity> entities = player.level().getEntitiesOfClass(
                LivingEntity.class,
                new AABB(player.getX() - range, player.getY() - range, player.getZ() - range,
                        player.getX() + range, player.getY() + range, player.getZ() + range),
                e -> e != player && !e.isInvulnerable());
        
        boolean success = false;
        
        for (LivingEntity entity : entities) {
            // Slow down entities
            entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, duration, isInfected ? 3 : 2));
            entity.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, duration, isInfected ? 3 : 2));
            entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, duration, isInfected ? 1 : 0));
            
            success = true;
        }
        
        // Speed up player
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, isInfected ? 2 : 1));
        player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, duration, isInfected ? 2 : 1));
        
        // Side effects for infected version
        if (isInfected) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, duration, 1));
            // Side effect: player experiences time dilation
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 0));
        }
        
        return success || !entities.isEmpty();
    }
    
    /**
     * Uses the Soul Stone ability
     * Soul Stone: Soul manipulation and life/death control
     * 
     * @param player The player
     * @param isInfected Whether the stone is infected
     * @return True if the ability was used
     */
    private static boolean useSoulStoneAbility(ServerPlayer player, boolean isInfected) {
        // Default ability: Life drain
        int range = ModConfig.STONE_ABILITY_RANGE.get() * (isInfected ? 2 : 1);
        float healAmount = isInfected ? 10.0f : 6.0f;
        
        List<LivingEntity> entities = player.level().getEntitiesOfClass(
                LivingEntity.class,
                new AABB(player.getX() - range, player.getY() - range, player.getZ() - range,
                        player.getX() + range, player.getY() + range, player.getZ() + range),
                e -> e != player && !e.isInvulnerable() && e.isAlive());
        
        boolean success = false;
        float totalHealing = 0;
        
        for (LivingEntity entity : entities) {
            // Calculate damage based on distance
            double distance = player.distanceTo(entity);
            float actualDamage = 2.0f * (float)(1.0 - (distance / range));
            
            if (actualDamage > 0) {
                entity.hurt(player.damageSources().playerAttack(player), actualDamage);
                
                // Apply weakness
                entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 1));
                
                totalHealing += actualDamage;
                success = true;
            }
        }
        
        // Heal player based on damage dealt
        if (totalHealing > 0) {
            player.heal(Math.min(totalHealing, healAmount));
        }
        
        // Apply additional effects
        player.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 600, isInfected ? 2 : 1));
        
        // Side effects for infected version
        if (isInfected) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 400, 1));
            // Side effect: soul corruption
            player.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 0));
        }
        
        return success || totalHealing > 0;
    }
}