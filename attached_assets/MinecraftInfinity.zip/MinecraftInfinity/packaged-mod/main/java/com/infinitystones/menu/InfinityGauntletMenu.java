package com.infinitystones.menu;

import com.infinitystones.items.custom.InfinityGauntletItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.SlotItemHandler;

/**
 * Menu for the Infinity Gauntlet - allows players to insert and remove stones
 */
public class InfinityGauntletMenu extends AbstractContainerMenu {
    private final ItemStack gauntlet;
    private final ItemStackHandler stoneInventory;
    private final int SLOT_COUNT = 6;  // One slot for each Infinity Stone
    
    // Client constructor
    public InfinityGauntletMenu(int containerId, Inventory inventory, FriendlyByteBuf extraData) {
        this(containerId, inventory, inventory.getSelected(), new ItemStackHandler(6));
    }
    
    // Server constructor
    public InfinityGauntletMenu(int containerId, Inventory inventory, ItemStack gauntlet, IItemHandler handler) {
        super(ModMenuTypes.INFINITY_GAUNTLET_MENU.get(), containerId);
        
        this.gauntlet = gauntlet;
        this.stoneInventory = (ItemStackHandler) handler;
        
        // Add player inventory slots
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(inventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
        
        // Add player hotbar slots
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(inventory, col, 8 + col * 18, 142));
        }
        
        // Add stone slots
        // Will be arranged in a circle or pattern in the actual screen
        for (int i = 0; i < SLOT_COUNT; i++) {
            this.addSlot(new SlotItemHandler(stoneInventory, i, 80 + (i * 20), 30));
        }
    }
    
    // Check if the gauntlet is still in the player's hand
    @Override
    public boolean stillValid(Player player) {
        return !this.gauntlet.isEmpty() && player.getInventory().contains(this.gauntlet);
    }
    
    // Implementation of the quick move functionality (shift-click)
    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack itemstack = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        
        if (slot != null && slot.hasItem()) {
            ItemStack slotItem = slot.getItem();
            itemstack = slotItem.copy();
            
            if (index < 36) {
                // From player inventory to stone slots
                if (!this.moveItemStackTo(slotItem, 36, 36 + SLOT_COUNT, false)) {
                    return ItemStack.EMPTY;
                }
            } else {
                // From stone slots to player inventory
                if (!this.moveItemStackTo(slotItem, 0, 36, false)) {
                    return ItemStack.EMPTY;
                }
            }
            
            if (slotItem.isEmpty()) {
                slot.set(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
        }
        
        return itemstack;
    }
}