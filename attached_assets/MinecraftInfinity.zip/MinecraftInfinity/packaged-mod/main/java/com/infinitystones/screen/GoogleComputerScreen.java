package com.infinitystones.screen;

import com.infinitystones.InfinityStonesMod;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

/**
 * Screen for the Google Computer
 */
public class GoogleComputerScreen extends AbstractContainerScreen<GoogleComputerMenu> {
    private static final ResourceLocation TEXTURE = 
            new ResourceLocation(InfinityStonesMod.MOD_ID, "textures/gui/google_computer.png");
    
    // Search box
    private EditBox searchBox;
    
    // Search button
    private Button searchButton;
    
    // Maximum number of visible results
    private static final int MAX_VISIBLE_RESULTS = 5;
    
    /**
     * Constructs a new screen
     * 
     * @param menu The menu
     * @param inventory The player's inventory
     * @param title The screen title
     */
    public GoogleComputerScreen(GoogleComputerMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        
        this.imageWidth = 248;
        this.imageHeight = 166;
    }
    
    /**
     * Initializes the screen
     */
    @Override
    protected void init() {
        super.init();
        
        // Calculate positions
        int centerX = leftPos + (imageWidth / 2);
        
        // Create search box
        searchBox = new EditBox(this.font, centerX - 70, topPos + 20, 140, 20, Component.translatable("gui.infinitystones.google_search"));
        searchBox.setMaxLength(50);
        searchBox.setValue(menu.getCurrentQuery());
        searchBox.setEditable(true);
        addRenderableWidget(searchBox);
        
        // Create search button
        searchButton = Button.builder(
                Component.translatable("button.infinitystones.search"),
                btn -> search())
                .pos(centerX + 75, topPos + 20)
                .size(60, 20)
                .build();
        addRenderableWidget(searchButton);
        
        // Set initial keyboard focus
        setInitialFocus(searchBox);
    }
    
    /**
     * Performs a search
     */
    private void search() {
        String query = searchBox.getValue().trim();
        if (!query.isEmpty() && !query.equals(menu.getCurrentQuery())) {
            menu.setSearchQuery(query);
        }
    }
    
    /**
     * Handles keyboard input
     * 
     * @param keyCode The key code
     * @param scanCode The scan code
     * @param modifiers The modifiers
     * @return True if handled
     */
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257 || keyCode == 335) { // Enter or numpad enter
            search();
            return true;
        }
        
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
    
    /**
     * Renders the screen background
     * 
     * @param guiGraphics The GUI graphics context
     * @param mouseX The mouse X position
     * @param mouseY The mouse Y position
     * @param partialTick The partial tick
     */
    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, TEXTURE);
        
        // Draw background
        guiGraphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);
    }
    
    /**
     * Renders the foreground
     * 
     * @param guiGraphics The GUI graphics context
     * @param mouseX The mouse X position
     * @param mouseY The mouse Y position
     */
    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        // Render title
        guiGraphics.drawString(this.font, this.title, this.imageWidth / 2 - this.font.width(this.title) / 2, 6, 4210752, false);
        
        // Render search results heading
        guiGraphics.drawString(this.font, Component.translatable("gui.infinitystones.search_results"), 
                10, 50, 4210752, false);
        
        // Render results
        var results = menu.getSearchResults();
        if (results.isEmpty()) {
            if (!menu.getCurrentQuery().isEmpty()) {
                guiGraphics.drawString(this.font, Component.translatable("gui.infinitystones.no_results"), 
                        10, 65, 0x666666, false);
            }
        } else {
            int y = 65;
            int count = 0;
            
            for (String result : results) {
                if (count >= MAX_VISIBLE_RESULTS) break;
                
                guiGraphics.drawString(this.font, Component.literal(result), 10, y, 0x000000, false);
                y += 15;
                count++;
            }
            
            // Indicate more results if applicable
            if (results.size() > MAX_VISIBLE_RESULTS) {
                guiGraphics.drawString(this.font, Component.translatable("gui.infinitystones.more_results", 
                        results.size() - MAX_VISIBLE_RESULTS), 10, y, 0x666666, false);
            }
        }
    }
    
    /**
     * Checks for changes and updates the screen
     */
    @Override
    public void containerTick() {
        super.containerTick();
        
        // Update search box
        searchBox.tick();
    }
}