package com.infinitystones.util;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Utility for tracking stone ability cooldowns
 */
public class CooldownTracker {
    // Map of player UUID -> Map of stone type -> cooldown end time
    private static final Map<UUID, Map<StoneType, Long>> COOLDOWNS = new HashMap<>();
    
    // Map of player UUID -> Map of stone combination -> cooldown end time
    private static final Map<UUID, Map<String, Long>> COMBINATION_COOLDOWNS = new HashMap<>();
    
    // Snap ability cooldown
    private static final Map<UUID, Long> SNAP_COOLDOWNS = new HashMap<>();
    
    /**
     * Applies a cooldown for a stone
     * 
     * @param playerId The player ID
     * @param stoneType The stone type
     * @param ticks The cooldown duration in ticks
     */
    public static void applyCooldown(UUID playerId, StoneType stoneType, int ticks) {
        Map<StoneType, Long> playerCooldowns = COOLDOWNS.computeIfAbsent(playerId, id -> new HashMap<>());
        
        // Calculate end time
        long endTime = System.currentTimeMillis() + (ticks * 50L); // 50ms per tick
        
        // Set cooldown
        playerCooldowns.put(stoneType, endTime);
    }
    
    /**
     * Applies a cooldown for a combination of stones
     * 
     * @param playerId The player ID
     * @param combinationId The combination ID
     * @param ticks The cooldown duration in ticks
     */
    public static void applyCombinationCooldown(UUID playerId, String combinationId, int ticks) {
        Map<String, Long> playerCombinationCooldowns = COMBINATION_COOLDOWNS.computeIfAbsent(playerId, id -> new HashMap<>());
        
        // Calculate end time
        long endTime = System.currentTimeMillis() + (ticks * 50L); // 50ms per tick
        
        // Set cooldown
        playerCombinationCooldowns.put(combinationId, endTime);
    }
    
    /**
     * Applies a cooldown for the snap ability
     * 
     * @param playerId The player ID
     * @param ticks The cooldown duration in ticks
     */
    public static void applySnapCooldown(UUID playerId, int ticks) {
        // Calculate end time
        long endTime = System.currentTimeMillis() + (ticks * 50L); // 50ms per tick
        
        // Set cooldown
        SNAP_COOLDOWNS.put(playerId, endTime);
    }
    
    /**
     * Checks if a stone is on cooldown
     * 
     * @param playerId The player ID
     * @param stoneType The stone type
     * @return True if the stone is on cooldown
     */
    public static boolean isOnCooldown(UUID playerId, StoneType stoneType) {
        Map<StoneType, Long> playerCooldowns = COOLDOWNS.get(playerId);
        
        if (playerCooldowns == null) {
            return false;
        }
        
        Long endTime = playerCooldowns.get(stoneType);
        
        if (endTime == null) {
            return false;
        }
        
        // Check if cooldown has expired
        if (System.currentTimeMillis() > endTime) {
            playerCooldowns.remove(stoneType);
            return false;
        }
        
        return true;
    }
    
    /**
     * Checks if a combination is on cooldown
     * 
     * @param playerId The player ID
     * @param combinationId The combination ID
     * @return True if the combination is on cooldown
     */
    public static boolean isCombinationOnCooldown(UUID playerId, String combinationId) {
        Map<String, Long> playerCombinationCooldowns = COMBINATION_COOLDOWNS.get(playerId);
        
        if (playerCombinationCooldowns == null) {
            return false;
        }
        
        Long endTime = playerCombinationCooldowns.get(combinationId);
        
        if (endTime == null) {
            return false;
        }
        
        // Check if cooldown has expired
        if (System.currentTimeMillis() > endTime) {
            playerCombinationCooldowns.remove(combinationId);
            return false;
        }
        
        return true;
    }
    
    /**
     * Checks if the snap ability is on cooldown
     * 
     * @param playerId The player ID
     * @return True if the snap ability is on cooldown
     */
    public static boolean isSnapOnCooldown(UUID playerId) {
        Long endTime = SNAP_COOLDOWNS.get(playerId);
        
        if (endTime == null) {
            return false;
        }
        
        // Check if cooldown has expired
        if (System.currentTimeMillis() > endTime) {
            SNAP_COOLDOWNS.remove(playerId);
            return false;
        }
        
        return true;
    }
    
    /**
     * Gets the remaining cooldown time for a stone
     * 
     * @param playerId The player ID
     * @param stoneType The stone type
     * @return The remaining cooldown time in ticks, or 0 if not on cooldown
     */
    public static int getRemainingCooldown(UUID playerId, StoneType stoneType) {
        Map<StoneType, Long> playerCooldowns = COOLDOWNS.get(playerId);
        
        if (playerCooldowns == null) {
            return 0;
        }
        
        Long endTime = playerCooldowns.get(stoneType);
        
        if (endTime == null) {
            return 0;
        }
        
        // Calculate remaining time
        long remainingMillis = endTime - System.currentTimeMillis();
        
        if (remainingMillis <= 0) {
            playerCooldowns.remove(stoneType);
            return 0;
        }
        
        // Convert back to ticks
        return (int) (remainingMillis / 50L);
    }
    
    /**
     * Gets the remaining cooldown time for a combination
     * 
     * @param playerId The player ID
     * @param combinationId The combination ID
     * @return The remaining cooldown time in ticks, or 0 if not on cooldown
     */
    public static int getRemainingCombinationCooldown(UUID playerId, String combinationId) {
        Map<String, Long> playerCombinationCooldowns = COMBINATION_COOLDOWNS.get(playerId);
        
        if (playerCombinationCooldowns == null) {
            return 0;
        }
        
        Long endTime = playerCombinationCooldowns.get(combinationId);
        
        if (endTime == null) {
            return 0;
        }
        
        // Calculate remaining time
        long remainingMillis = endTime - System.currentTimeMillis();
        
        if (remainingMillis <= 0) {
            playerCombinationCooldowns.remove(combinationId);
            return 0;
        }
        
        // Convert back to ticks
        return (int) (remainingMillis / 50L);
    }
    
    /**
     * Gets the remaining cooldown time for the snap ability
     * 
     * @param playerId The player ID
     * @return The remaining cooldown time in ticks, or 0 if not on cooldown
     */
    public static int getRemainingSnapCooldown(UUID playerId) {
        Long endTime = SNAP_COOLDOWNS.get(playerId);
        
        if (endTime == null) {
            return 0;
        }
        
        // Calculate remaining time
        long remainingMillis = endTime - System.currentTimeMillis();
        
        if (remainingMillis <= 0) {
            SNAP_COOLDOWNS.remove(playerId);
            return 0;
        }
        
        // Convert back to ticks
        return (int) (remainingMillis / 50L);
    }
    
    /**
     * Clears all cooldowns for a player
     * 
     * @param playerId The player ID
     */
    public static void clearCooldowns(UUID playerId) {
        COOLDOWNS.remove(playerId);
        COMBINATION_COOLDOWNS.remove(playerId);
        SNAP_COOLDOWNS.remove(playerId);
    }
}