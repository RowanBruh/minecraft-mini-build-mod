package com.infinitystones.network.packets;

import com.infinitystones.screen.InfinityGauntletMenu;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.inventory.MenuConstructor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkHooks;

/**
 * Packet to open the gauntlet screen
 */
public class GauntletOpenC2SPacket {
    
    /**
     * Default constructor
     */
    public GauntletOpenC2SPacket() {
        // Empty constructor - no data to send
    }
    
    /**
     * Creates a packet from the buffer
     * 
     * @param buf The buffer to read from
     */
    public GauntletOpenC2SPacket(FriendlyByteBuf buf) {
        // No data to read
    }
    
    /**
     * Encodes the packet to the buffer
     * 
     * @param buf The buffer to write to
     */
    public void encode(FriendlyByteBuf buf) {
        // No data to write
    }
    
    /**
     * Handles the packet on the server
     * 
     * @param supplier The supplier for the network event
     * @return True if the packet was handled successfully
     */
    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // Server-side handling
            ServerPlayer player = context.getSender();
            if (player != null) {
                // Create menu provider
                MenuConstructor menuConstructor = (id, playerInventory, playerEntity) -> 
                        new InfinityGauntletMenu(id, playerInventory);
                
                // Open screen
                NetworkHooks.openScreen(player, 
                        new SimpleMenuProvider(menuConstructor, 
                                Component.translatable("screen.infinitystones.infinity_gauntlet")));
            }
        });
        
        context.setPacketHandled(true);
        return true;
    }
}