package com.infinitystones.items;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.items.custom.InfinityGauntletItem;
import com.infinitystones.items.custom.InfinityStoneItem;
import com.infinitystones.util.StoneType;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Registry for mod items
 */
public class ModItems {
    // Deferred register for items
    public static final DeferredRegister<Item> ITEMS = 
            DeferredRegister.create(ForgeRegistries.ITEMS, InfinityStonesMod.MOD_ID);
    
    // Infinity Stones
    public static final RegistryObject<Item> SPACE_STONE = ITEMS.register("space_stone",
            () -> new InfinityStoneItem(new Item.Properties().stacksTo(1).fireResistant(), StoneType.SPACE, false));
    
    public static final RegistryObject<Item> MIND_STONE = ITEMS.register("mind_stone",
            () -> new InfinityStoneItem(new Item.Properties().stacksTo(1).fireResistant(), StoneType.MIND, false));
    
    public static final RegistryObject<Item> REALITY_STONE = ITEMS.register("reality_stone",
            () -> new InfinityStoneItem(new Item.Properties().stacksTo(1).fireResistant(), StoneType.REALITY, false));
    
    public static final RegistryObject<Item> POWER_STONE = ITEMS.register("power_stone",
            () -> new InfinityStoneItem(new Item.Properties().stacksTo(1).fireResistant(), StoneType.POWER, false));
    
    public static final RegistryObject<Item> TIME_STONE = ITEMS.register("time_stone",
            () -> new InfinityStoneItem(new Item.Properties().stacksTo(1).fireResistant(), StoneType.TIME, false));
    
    public static final RegistryObject<Item> SOUL_STONE = ITEMS.register("soul_stone",
            () -> new InfinityStoneItem(new Item.Properties().stacksTo(1).fireResistant(), StoneType.SOUL, false));
    
    // Infected Infinity Stones
    public static final RegistryObject<Item> INFECTED_SPACE_STONE = ITEMS.register("infected_space_stone",
            () -> new InfinityStoneItem(new Item.Properties().stacksTo(1).fireResistant(), StoneType.SPACE, true));
    
    public static final RegistryObject<Item> INFECTED_MIND_STONE = ITEMS.register("infected_mind_stone",
            () -> new InfinityStoneItem(new Item.Properties().stacksTo(1).fireResistant(), StoneType.MIND, true));
    
    public static final RegistryObject<Item> INFECTED_REALITY_STONE = ITEMS.register("infected_reality_stone",
            () -> new InfinityStoneItem(new Item.Properties().stacksTo(1).fireResistant(), StoneType.REALITY, true));
    
    public static final RegistryObject<Item> INFECTED_POWER_STONE = ITEMS.register("infected_power_stone",
            () -> new InfinityStoneItem(new Item.Properties().stacksTo(1).fireResistant(), StoneType.POWER, true));
    
    public static final RegistryObject<Item> INFECTED_TIME_STONE = ITEMS.register("infected_time_stone",
            () -> new InfinityStoneItem(new Item.Properties().stacksTo(1).fireResistant(), StoneType.TIME, true));
    
    public static final RegistryObject<Item> INFECTED_SOUL_STONE = ITEMS.register("infected_soul_stone",
            () -> new InfinityStoneItem(new Item.Properties().stacksTo(1).fireResistant(), StoneType.SOUL, true));
    
    // Infinity Gauntlets
    public static final RegistryObject<Item> INFINITY_GAUNTLET = ITEMS.register("infinity_gauntlet",
            () -> new InfinityGauntletItem(new Item.Properties().stacksTo(1).fireResistant(), false));
    
    public static final RegistryObject<Item> INFECTED_INFINITY_GAUNTLET = ITEMS.register("infected_infinity_gauntlet",
            () -> new InfinityGauntletItem(new Item.Properties().stacksTo(1).fireResistant(), true));
    
    /**
     * Registers the items with the event bus
     * 
     * @param eventBus The event bus to register with
     */
    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}