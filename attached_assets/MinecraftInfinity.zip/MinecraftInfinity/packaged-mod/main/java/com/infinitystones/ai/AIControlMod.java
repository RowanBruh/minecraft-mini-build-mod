package com.infinitystones.ai;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.ai.commands.AICommandRegister;
import com.infinitystones.ai.config.AIModConfig;
import com.infinitystones.ai.entity.AIEntityTypes;
import com.infinitystones.ai.network.AINetworkHandler;
import com.infinitystones.ai.server.WebServerManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Main class for the AI Control module of the Infinity Stones mod
 */
@Mod.EventBusSubscriber(modid = InfinityStonesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class AIControlMod {
    // Logger for AI control
    public static final Logger LOGGER = LogManager.getLogger("InfinityStones-AI");
    
    // Web server manager instance
    private static WebServerManager webServerManager;
    
    /**
     * Initialize the AI Control module
     */
    public static void init() {
        LOGGER.info("Initializing AI Control Module");
        
        // Get the mod event bus
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        
        // Register entity types
        AIEntityTypes.register(modEventBus);
        
        // Register config
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, AIModConfig.COMMON_SPEC, 
                "infinitystones-ai-config.toml");
        
        // Register setup method
        modEventBus.addListener(AIControlMod::setup);
        
        // Register ourselves for server and other game events
        MinecraftForge.EVENT_BUS.register(AIControlMod.class);
        
        // Register command
        AICommandRegister.init();
    }
    
    /**
     * Common setup handler for the mod
     * 
     * @param event The setup event
     */
    private static void setup(final FMLCommonSetupEvent event) {
        // Initialize networking
        AINetworkHandler.init();
    }
    
    /**
     * Server starting event handler
     * 
     * @param event The server starting event
     */
    @SubscribeEvent
    public static void onServerStarting(ServerStartingEvent event) {
        LOGGER.info("AI Control Module - Server starting");
    }
    
    /**
     * Server stopping event handler
     * 
     * @param event The server stopping event
     */
    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        LOGGER.info("AI Control Module - Server stopping");
        
        // Stop the web server if it's running
        if (webServerManager != null && webServerManager.isRunning()) {
            webServerManager.stopServer();
        }
    }
    
    /**
     * Start the web server
     * 
     * @return True if the server was started successfully
     */
    public static boolean startWebServer() {
        if (webServerManager == null) {
            webServerManager = new WebServerManager();
        }
        
        if (!webServerManager.isRunning()) {
            return webServerManager.startServer();
        }
        
        return true;
    }
    
    /**
     * Stop the web server
     */
    public static void stopWebServer() {
        if (webServerManager != null && webServerManager.isRunning()) {
            webServerManager.stopServer();
        }
    }
    
    /**
     * Check if the web server is running
     * 
     * @return True if the web server is running
     */
    public static boolean isWebServerRunning() {
        return webServerManager != null && webServerManager.isRunning();
    }
    
    /**
     * Get the web server port
     * 
     * @return The web server port
     */
    public static int getWebServerPort() {
        if (webServerManager != null) {
            return webServerManager.getPort();
        }
        return AIModConfig.COMMON.webServerPort.get();
    }
    
    /**
     * Create a resource location for the AI Control module
     * 
     * @param path The path
     * @return The resource location
     */
    public static ResourceLocation rl(String path) {
        return new ResourceLocation(InfinityStonesMod.MOD_ID, path);
    }
}