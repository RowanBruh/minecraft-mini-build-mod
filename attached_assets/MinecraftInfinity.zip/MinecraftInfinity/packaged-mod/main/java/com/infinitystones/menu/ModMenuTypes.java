package com.infinitystones.menu;

import com.infinitystones.InfinityStonesMod;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.network.IContainerFactory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Registry for mod menu types
 */
public class ModMenuTypes {
    public static final DeferredRegister<MenuType<?>> MENU_TYPES = 
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, InfinityStonesMod.MOD_ID);
    
    // Google Computer Menu
    public static final RegistryObject<MenuType<GoogleComputerMenu>> GOOGLE_COMPUTER_MENU = 
            registerMenuType(GoogleComputerMenu::new, "google_computer_menu");
    
    // Infinity Gauntlet Menu
    public static final RegistryObject<MenuType<InfinityGauntletMenu>> INFINITY_GAUNTLET_MENU = 
            registerMenuType(InfinityGauntletMenu::new, "infinity_gauntlet_menu");
    
    /**
     * Registers a menu type
     * 
     * @param factory The container factory
     * @param name The name of the menu type
     * @return The registry object
     */
    private static <T extends AbstractContainerMenu> RegistryObject<MenuType<T>> registerMenuType(
            IContainerFactory<T> factory, String name) {
        return MENU_TYPES.register(name, () -> IForgeMenuType.create(factory));
    }
    
    /**
     * Registers all menu types
     * 
     * @param eventBus The mod event bus
     */
    public static void register(IEventBus eventBus) {
        MENU_TYPES.register(eventBus);
    }
}