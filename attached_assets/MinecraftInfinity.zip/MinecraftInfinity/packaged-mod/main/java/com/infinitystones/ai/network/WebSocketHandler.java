package com.infinitystones.ai.network;

import com.google.gson.Gson;
import com.infinitystones.ai.AIControlMod;
import com.infinitystones.ai.network.packets.GameStatePacket;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Handles WebSocket communication with the Node.js server
 */
public class WebSocketHandler {
    private static final Gson GSON = new Gson();
    
    /**
     * Send a game state packet to web clients
     * 
     * @param packet The packet to send
     */
    public static void sendToWebClients(GameStatePacket packet) {
        if (!AIControlMod.isWebServerRunning()) {
            AIControlMod.LOGGER.warn("Web server is not running, cannot send packet");
            return;
        }
        
        try {
            int port = AIControlMod.getWebServerPort();
            URL url = new URL("http://localhost:" + port + "/api/gamestate");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);
            
            // Convert packet to JSON
            String json = GSON.toJson(packet.serialize());
            
            // Send the request
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = json.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }
            
            // Get the response
            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                AIControlMod.LOGGER.warn("Failed to send game state to web server: {}", responseCode);
            }
            
            // Close the connection
            connection.disconnect();
        } catch (IOException e) {
            AIControlMod.LOGGER.error("Error sending game state to web server", e);
        }
    }
}