package com.infinitystones.blockentities;

import com.infinitystones.google.GoogleSearchService;
import com.infinitystones.network.ModPackets;
import com.infinitystones.network.packets.GoogleSearchResultsS2CPacket;
import com.infinitystones.screen.GoogleComputerMenu;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.server.ServerLifecycleHooks;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Block entity for the Google Computer
 */
public class GoogleComputerBlockEntity extends BlockEntity implements MenuProvider {
    // Item handler for power source
    private final ItemStackHandler itemHandler = new ItemStackHandler(1) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }
    };
    
    // Lazy optional for the item handler
    private LazyOptional<IItemHandler> lazyItemHandler = LazyOptional.empty();
    
    // Search state
    private String searchQuery = "";
    private List<String> searchResults = new ArrayList<>();
    private boolean isSearching = false;
    
    /**
     * Constructs a new Google Computer block entity
     * 
     * @param pos The block position
     * @param blockState The block state
     */
    public GoogleComputerBlockEntity(BlockPos pos, BlockState blockState) {
        super(ModBlockEntities.GOOGLE_COMPUTER.get(), pos, blockState);
    }
    
    /**
     * Gets the search query
     * 
     * @return The search query
     */
    public String getSearchQuery() {
        return searchQuery;
    }
    
    /**
     * Sets the search query and performs the search
     * 
     * @param query The search query
     */
    public void setSearchQuery(String query) {
        if (query.equals(this.searchQuery) || query.isEmpty() || isSearching) {
            return;
        }
        
        this.searchQuery = query;
        this.isSearching = true;
        setChanged();
        
        // Perform search asynchronously
        CompletableFuture<List<String>> future = GoogleSearchService.searchAsync(query);
        future.thenAccept(results -> {
            if (this.level != null && !this.level.isClientSide) {
                this.searchResults = results;
                this.isSearching = false;
                setChanged();
                
                // Send results to clients
                broadcastResults();
            }
        });
    }
    
    /**
     * Gets the search results
     * 
     * @return The search results
     */
    public List<String> getSearchResults() {
        return searchResults;
    }
    
    /**
     * Broadcasts search results to clients
     */
    private void broadcastResults() {
        if (level != null && !level.isClientSide && ServerLifecycleHooks.getCurrentServer() != null) {
            // Create packet with results
            GoogleSearchResultsS2CPacket packet = new GoogleSearchResultsS2CPacket(searchResults, worldPosition);
            
            // Send to all players in the dimension
            ServerLifecycleHooks.getCurrentServer().getPlayerList().getPlayers().forEach(player -> {
                if (player.level().dimension().equals(level.dimension())) {
                    ModPackets.sendToPlayer(packet, player);
                }
            });
        }
    }
    
    /**
     * Ticks the block entity
     * 
     * @param level The level
     * @param pos The block position
     * @param state The block state
     * @param blockEntity The block entity
     */
    public static void tick(Level level, BlockPos pos, BlockState state, GoogleComputerBlockEntity blockEntity) {
        if (level.isClientSide()) {
            return;
        }
        
        // Check if computer has power
        /*
        if (!blockEntity.hasPowerSource()) {
            // Clear results if no power
            if (!blockEntity.searchResults.isEmpty()) {
                blockEntity.searchResults.clear();
                blockEntity.broadcastResults();
            }
        }
        */
    }
    
    /**
     * Checks if the computer has a power source
     * 
     * @return True if powered
     */
    public boolean hasPowerSource() {
        return !itemHandler.getStackInSlot(0).isEmpty();
    }
    
    /**
     * Gets the display name
     * 
     * @return The display name
     */
    @Override
    public Component getDisplayName() {
        return Component.translatable("block.infinitystones.google_computer");
    }
    
    /**
     * Creates a menu for the block entity
     * 
     * @param containerId The container ID
     * @param inventory The player's inventory
     * @param player The player
     * @return The menu
     */
    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new GoogleComputerMenu(containerId, inventory, this.worldPosition);
    }
    
    /**
     * Gets a capability
     * 
     * @param cap The capability
     * @param side The side
     * @return The lazy optional
     */
    @Override
    public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) {
            return lazyItemHandler.cast();
        }
        
        return super.getCapability(cap, side);
    }
    
    /**
     * Invalidates capabilities
     */
    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        lazyItemHandler.invalidate();
    }
    
    /**
     * Creates capabilities
     */
    @Override
    public void onLoad() {
        super.onLoad();
        lazyItemHandler = LazyOptional.of(() -> itemHandler);
    }
    
    /**
     * Saves data to NBT
     * 
     * @param tag The tag
     */
    @Override
    protected void saveAdditional(CompoundTag tag) {
        tag.put("inventory", itemHandler.serializeNBT());
        tag.putString("searchQuery", searchQuery);
        
        // Save search results
        ListTag resultsTag = new ListTag();
        for (String result : searchResults) {
            resultsTag.add(StringTag.valueOf(result));
        }
        tag.put("searchResults", resultsTag);
        
        super.saveAdditional(tag);
    }
    
    /**
     * Loads data from NBT
     * 
     * @param tag The tag
     */
    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        itemHandler.deserializeNBT(tag.getCompound("inventory"));
        searchQuery = tag.getString("searchQuery");
        
        // Load search results
        searchResults.clear();
        ListTag resultsTag = tag.getList("searchResults", 8); // 8 is the type ID for StringTag
        for (int i = 0; i < resultsTag.size(); i++) {
            searchResults.add(resultsTag.getString(i));
        }
    }
    
    /**
     * Drops the contents of the block entity
     * 
     * @param level The level
     * @param pos The block position
     * @param blockEntity The block entity
     */
    public static void dropContents(Level level, BlockPos pos, GoogleComputerBlockEntity blockEntity) {
        if (blockEntity != null) {
            for (int i = 0; i < blockEntity.itemHandler.getSlots(); i++) {
                ItemStack stack = blockEntity.itemHandler.getStackInSlot(i);
                if (!stack.isEmpty()) {
                    net.minecraft.world.Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), stack);
                }
            }
        }
    }
}