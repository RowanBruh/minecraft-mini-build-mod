package com.infinitystones.items.custom;

import com.infinitystones.network.ModPackets;
import com.infinitystones.network.packets.GauntletOpenC2SPacket;
import com.infinitystones.util.StoneType;
import com.infinitystones.util.CooldownTracker;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * Item implementation for the Infinity Gauntlet
 */
public class InfinityGauntletItem extends Item {
    // Constants
    private static final String EQUIPPED_STONES_TAG = "EquippedStones";
    
    // Whether this is an infected gauntlet
    private final boolean infected;
    
    /**
     * Creates a new Infinity Gauntlet item
     * 
     * @param properties The item properties
     * @param infected Whether this is an infected gauntlet
     */
    public InfinityGauntletItem(Properties properties, boolean infected) {
        super(properties);
        this.infected = infected;
    }
    
    /**
     * Gets whether this is an infected gauntlet
     * 
     * @return True if infected
     */
    public boolean isInfected() {
        return infected;
    }
    
    /**
     * Gets the display name with formatting
     * 
     * @param stack The item stack
     * @return The display name
     */
    @Override
    public Component getName(ItemStack stack) {
        Component name = super.getName(stack);
        
        // Format the name based on the gauntlet type
        ChatFormatting formatting = infected ? ChatFormatting.DARK_RED : ChatFormatting.GOLD;
        
        return name.copy().withStyle(formatting);
    }
    
    /**
     * Adds tooltip information
     * 
     * @param stack The item stack
     * @param level The level
     * @param components The tooltip components
     * @param flag The tooltip flag
     */
    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> components, TooltipFlag flag) {
        super.appendHoverText(stack, level, components, flag);
        
        // Add gauntlet description
        components.add(Component.translatable("tooltip.infinitystones.infinity_gauntlet")
                .withStyle(ChatFormatting.GRAY));
        
        // Add infected warning if applicable
        if (infected) {
            components.add(Component.translatable("tooltip.infinitystones.infected")
                    .withStyle(ChatFormatting.DARK_RED));
        }
        
        // Add equipped stones
        boolean[] equippedStones = getEquippedStones(stack);
        int stoneCount = 0;
        
        for (boolean equipped : equippedStones) {
            if (equipped) {
                stoneCount++;
            }
        }
        
        if (stoneCount > 0) {
            components.add(Component.translatable("tooltip.infinitystones.equipped_stones", stoneCount)
                    .withStyle(ChatFormatting.GRAY));
            
            // List equipped stones
            for (StoneType stoneType : StoneType.values()) {
                if (equippedStones[stoneType.ordinal()]) {
                    ChatFormatting stoneColor = infected ? ChatFormatting.DARK_RED : switch (stoneType) {
                        case SPACE -> ChatFormatting.BLUE;
                        case MIND -> ChatFormatting.YELLOW;
                        case REALITY -> ChatFormatting.RED;
                        case POWER -> ChatFormatting.LIGHT_PURPLE;
                        case TIME -> ChatFormatting.GREEN;
                        case SOUL -> ChatFormatting.GOLD;
                    };
                    
                    components.add(Component.translatable("item.infinitystones." + 
                            (infected ? "infected_" : "") + stoneType.getSerializedName() + "_stone")
                            .withStyle(stoneColor));
                }
            }
        } else {
            components.add(Component.translatable("tooltip.infinitystones.no_stones")
                    .withStyle(ChatFormatting.GRAY));
        }
        
        // Add usage instructions
        components.add(Component.translatable("tooltip.infinitystones.gauntlet_use_" + 
                (stoneCount > 0 ? "equipped" : "empty"))
                .withStyle(ChatFormatting.DARK_GRAY));
    }
    
    /**
     * Handles item use
     * 
     * @param level The level
     * @param player The player
     * @param hand The hand
     * @return The interaction result
     */
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack itemstack = player.getItemInHand(hand);
        
        if (!level.isClientSide) {
            // Server-side handling
            if (hand == InteractionHand.MAIN_HAND) {
                // Check if any stones are equipped
                boolean[] equippedStones = getEquippedStones(itemstack);
                boolean hasStones = false;
                
                for (boolean equipped : equippedStones) {
                    if (equipped) {
                        hasStones = true;
                        break;
                    }
                }
                
                if (hasStones) {
                    // Open gauntlet screen
                    if (player.isShiftKeyDown()) {
                        // Open the gauntlet screen
                        openGauntletScreen(player);
                    } else {
                        // Use snap ability if all stones are equipped
                        if (areAllStonesEquipped(equippedStones)) {
                            useSnapAbility(player);
                        } else {
                            // Tell player to shift-click to open
                            player.displayClientMessage(
                                    Component.translatable("message.infinitystones.gauntlet_shift_click"),
                                    true);
                        }
                    }
                } else {
                    // Open gauntlet screen even if empty
                    openGauntletScreen(player);
                }
            }
        } else {
            // Client-side handling
            if (hand == InteractionHand.MAIN_HAND) {
                if (player.isShiftKeyDown()) {
                    // Send packet to open gauntlet screen
                    ModPackets.sendToServer(new GauntletOpenC2SPacket());
                    return InteractionResultHolder.success(itemstack);
                }
            }
        }
        
        return InteractionResultHolder.sidedSuccess(itemstack, level.isClientSide);
    }
    
    /**
     * Opens the gauntlet screen
     * 
     * @param player The player
     */
    private void openGauntletScreen(Player player) {
        if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
            // Send packet to open gauntlet screen
            net.minecraftforge.network.NetworkHooks.openScreen(
                    serverPlayer,
                    new com.infinitystones.screen.InfinityGauntletMenu(
                            0, player.getInventory()),
                    buf -> {}
            );
        }
    }
    
    /**
     * Uses the snap ability
     * 
     * @param player The player
     */
    private void useSnapAbility(Player player) {
        if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
            // Check cooldown
            if (CooldownTracker.isSnapOnCooldown(player.getUUID())) {
                player.displayClientMessage(
                        Component.translatable("message.infinitystones.snap_cooldown", 
                                CooldownTracker.getRemainingSnapCooldown(player.getUUID()) / 20),
                        true);
                return;
            }
            
            // Use snap ability
            com.infinitystones.util.CombinedStoneAbilities.useSnapAbility(serverPlayer, infected);
            
            // Apply cooldown
            CooldownTracker.applySnapCooldown(player.getUUID(), 6000); // 5-minute cooldown
        }
    }
    
    /**
     * Handles item inventory tick
     * 
     * @param stack The item stack
     * @param level The level
     * @param entity The entity
     * @param slotId The slot ID
     * @param isSelected Whether the item is selected
     */
    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slotId, boolean isSelected) {
        super.inventoryTick(stack, level, entity, slotId, isSelected);
        
        // Apply effects when in inventory for infected gauntlet
        if (infected && entity instanceof Player player && level.getGameTime() % 300 == 0) {
            // Check if any stones are equipped
            boolean[] equippedStones = getEquippedStones(stack);
            int stoneCount = 0;
            
            for (boolean equipped : equippedStones) {
                if (equipped) {
                    stoneCount++;
                }
            }
            
            // Apply effects based on the number of stones
            if (stoneCount > 0 && level.random.nextFloat() < 0.05f * stoneCount) {
                applyInfectedEffect(player, equippedStones);
            }
        }
    }
    
    /**
     * Applies an effect for infected gauntlet
     * 
     * @param player The player
     * @param equippedStones The equipped stones
     */
    private void applyInfectedEffect(Player player, boolean[] equippedStones) {
        if (player.level().isClientSide) {
            return;
        }
        
        // Choose a random equipped stone
        java.util.List<StoneType> availableStones = new java.util.ArrayList<>();
        
        for (StoneType stoneType : StoneType.values()) {
            if (equippedStones[stoneType.ordinal()]) {
                availableStones.add(stoneType);
            }
        }
        
        if (!availableStones.isEmpty()) {
            StoneType chosenStone = availableStones.get(player.level().random.nextInt(availableStones.size()));
            
            // Apply effect based on the chosen stone
            switch (chosenStone) {
                case SPACE -> player.teleport(
                        player.getX() + (player.level().random.nextDouble() - 0.5) * 3,
                        player.getY(),
                        player.getZ() + (player.level().random.nextDouble() - 0.5) * 3);
                case MIND -> player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                        net.minecraft.world.effect.MobEffects.CONFUSION, 100, 0));
                case REALITY -> player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                        net.minecraft.world.effect.MobEffects.BLINDNESS, 60, 0));
                case POWER -> player.hurt(player.damageSources().magic(), 1.0f);
                case TIME -> player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                        net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
                case SOUL -> player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                        net.minecraft.world.effect.MobEffects.HUNGER, 200, 1));
            }
        }
    }
    
    /**
     * Sets up the NBT for a new item stack
     * 
     * @param stack The item stack
     * @return The item stack
     */
    @Override
    public ItemStack getDefaultInstance() {
        ItemStack stack = super.getDefaultInstance();
        
        // Initialize equipped stones
        CompoundTag tag = stack.getOrCreateTag();
        boolean[] equippedStones = new boolean[StoneType.values().length];
        saveEquippedStones(tag, equippedStones);
        
        return stack;
    }
    
    /**
     * Gets the equipped stones from an item stack
     * 
     * @param stack The item stack
     * @return The equipped stones
     */
    public boolean[] getEquippedStones(ItemStack stack) {
        CompoundTag tag = stack.getOrCreateTag();
        
        if (!tag.contains(EQUIPPED_STONES_TAG)) {
            // Initialize equipped stones
            boolean[] equippedStones = new boolean[StoneType.values().length];
            saveEquippedStones(tag, equippedStones);
            return equippedStones;
        }
        
        // Read equipped stones
        CompoundTag stonesTag = tag.getCompound(EQUIPPED_STONES_TAG);
        boolean[] equippedStones = new boolean[StoneType.values().length];
        
        for (StoneType stoneType : StoneType.values()) {
            equippedStones[stoneType.ordinal()] = stonesTag.getBoolean(stoneType.getSerializedName());
        }
        
        return equippedStones;
    }
    
    /**
     * Sets an equipped stone
     * 
     * @param stack The item stack
     * @param stoneType The stone type
     * @param equipped Whether the stone is equipped
     */
    public void setEquippedStone(ItemStack stack, StoneType stoneType, boolean equipped) {
        CompoundTag tag = stack.getOrCreateTag();
        boolean[] equippedStones = getEquippedStones(stack);
        
        equippedStones[stoneType.ordinal()] = equipped;
        saveEquippedStones(tag, equippedStones);
    }
    
    /**
     * Saves the equipped stones to NBT
     * 
     * @param tag The tag
     * @param equippedStones The equipped stones
     */
    private void saveEquippedStones(CompoundTag tag, boolean[] equippedStones) {
        CompoundTag stonesTag = new CompoundTag();
        
        for (StoneType stoneType : StoneType.values()) {
            stonesTag.putBoolean(stoneType.getSerializedName(), equippedStones[stoneType.ordinal()]);
        }
        
        tag.put(EQUIPPED_STONES_TAG, stonesTag);
    }
    
    /**
     * Checks if all stones are equipped
     * 
     * @param equippedStones The equipped stones
     * @return True if all stones are equipped
     */
    private boolean areAllStonesEquipped(boolean[] equippedStones) {
        for (boolean equipped : equippedStones) {
            if (!equipped) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Gets the number of equipped stones
     * 
     * @param stack The item stack
     * @return The number of equipped stones
     */
    public int getStoneCount(ItemStack stack) {
        boolean[] equippedStones = getEquippedStones(stack);
        int count = 0;
        
        for (boolean equipped : equippedStones) {
            if (equipped) {
                count++;
            }
        }
        
        return count;
    }
    
    /**
     * Gets whether the item is enchantable
     * 
     * @param stack The item stack
     * @return True if enchantable
     */
    @Override
    public boolean isEnchantable(ItemStack stack) {
        return false;
    }
    
    /**
     * Gets whether the item is foil (glowing)
     * 
     * @param stack The item stack
     * @return True if foil
     */
    @Override
    public boolean isFoil(ItemStack stack) {
        boolean[] equippedStones = getEquippedStones(stack);
        
        for (boolean equipped : equippedStones) {
            if (equipped) {
                return true;
            }
        }
        
        return false;
    }
}