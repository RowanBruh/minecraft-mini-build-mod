package com.infinitystones.screen;

import com.infinitystones.items.ModItems;
import com.infinitystones.items.custom.InfinityGauntletItem;
import com.infinitystones.items.custom.InfinityStoneItem;
import com.infinitystones.util.StoneType;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/**
 * Menu for the Infinity Gauntlet screen
 */
public class InfinityGauntletMenu extends AbstractContainerMenu {
    // Player inventory reference
    private final Inventory playerInventory;
    
    // Item container for stones
    private final Container stoneContainer;
    
    // Stone slots index
    public static final int SPACE_SLOT = 0;
    public static final int MIND_SLOT = 1;
    public static final int REALITY_SLOT = 2;
    public static final int POWER_SLOT = 3;
    public static final int TIME_SLOT = 4;
    public static final int SOUL_SLOT = 5;
    
    // First inventory slot index
    private static final int INV_SLOT_START = 6;
    private static final int INV_SLOT_END = INV_SLOT_START + 26;
    private static final int USE_ROW_SLOT_START = INV_SLOT_END + 1;
    private static final int USE_ROW_SLOT_END = USE_ROW_SLOT_START + 8;
    
    /**
     * Constructs a new menu from the client side
     * 
     * @param id The window ID
     * @param playerInventory The player's inventory
     * @param extraData Extra data from the client
     */
    public InfinityGauntletMenu(int id, Inventory playerInventory, FriendlyByteBuf extraData) {
        this(id, playerInventory);
    }
    
    /**
     * Constructs a new menu
     * 
     * @param id The window ID
     * @param playerInventory The player's inventory
     */
    public InfinityGauntletMenu(int id, Inventory playerInventory) {
        super(ModMenuTypes.INFINITY_GAUNTLET.get(), id);
        this.playerInventory = playerInventory;
        this.stoneContainer = new SimpleContainer(6);
        
        // Find gauntlet in player inventory
        ItemStack gauntlet = findGauntletInInventory(playerInventory);
        
        if (gauntlet.getItem() instanceof InfinityGauntletItem gauntletItem) {
            // Get equipped stones from gauntlet
            boolean[] equippedStones = gauntletItem.getEquippedStones(gauntlet);
            
            // Pre-fill container with equipped stones
            for (StoneType stoneType : StoneType.values()) {
                int slotIndex = stoneType.ordinal();
                
                if (equippedStones[slotIndex]) {
                    // Find the stone item
                    ItemStack stoneItem = findStoneInInventory(playerInventory, stoneType, gauntletItem.isInfected());
                    
                    if (!stoneItem.isEmpty()) {
                        stoneContainer.setItem(slotIndex, stoneItem.copy());
                    }
                }
            }
        }
        
        // Create stone slots
        this.addSlot(new StoneSlot(stoneContainer, SPACE_SLOT, 44, 35, StoneType.SPACE));
        this.addSlot(new StoneSlot(stoneContainer, MIND_SLOT, 62, 17, StoneType.MIND));
        this.addSlot(new StoneSlot(stoneContainer, REALITY_SLOT, 80, 35, StoneType.REALITY));
        this.addSlot(new StoneSlot(stoneContainer, POWER_SLOT, 80, 71, StoneType.POWER));
        this.addSlot(new StoneSlot(stoneContainer, TIME_SLOT, 62, 89, StoneType.TIME));
        this.addSlot(new StoneSlot(stoneContainer, SOUL_SLOT, 44, 71, StoneType.SOUL));
        
        // Create inventory slots
        for (int row = 0; row < 3; ++row) {
            for (int col = 0; col < 9; ++col) {
                this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 112 + row * 18));
            }
        }
        
        // Create hotbar slots
        for (int hotbarSlot = 0; hotbarSlot < 9; ++hotbarSlot) {
            this.addSlot(new Slot(playerInventory, hotbarSlot, 8 + hotbarSlot * 18, 170));
        }
    }
    
    /**
     * Finds the gauntlet in the player's inventory
     * 
     * @param playerInventory The player's inventory
     * @return The gauntlet item stack
     */
    private ItemStack findGauntletInInventory(Inventory playerInventory) {
        // Check main inventory
        for (int i = 0; i < playerInventory.getContainerSize(); i++) {
            ItemStack stack = playerInventory.getItem(i);
            if (stack.getItem() instanceof InfinityGauntletItem) {
                return stack;
            }
        }
        
        // No gauntlet found
        return ItemStack.EMPTY;
    }
    
    /**
     * Finds a stone in the player's inventory
     * 
     * @param playerInventory The player's inventory
     * @param stoneType The type of stone to find
     * @param infected Whether to find an infected stone
     * @return The stone item stack
     */
    private ItemStack findStoneInInventory(Inventory playerInventory, StoneType stoneType, boolean infected) {
        // Check main inventory
        for (int i = 0; i < playerInventory.getContainerSize(); i++) {
            ItemStack stack = playerInventory.getItem(i);
            if (stack.getItem() instanceof InfinityStoneItem stoneItem &&
                    stoneItem.getStoneType() == stoneType &&
                    stoneItem.isInfected() == infected) {
                return stack;
            }
        }
        
        // No stone found
        return ItemStack.EMPTY;
    }
    
    /**
     * Checks if the player can interact with the menu
     * 
     * @param player The player
     * @return True if the player can interact
     */
    @Override
    public boolean stillValid(Player player) {
        // Check if player has a gauntlet
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack.getItem() instanceof InfinityGauntletItem) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Handles item transfers between slots
     * 
     * @param player The player
     * @param index The slot index
     * @return The moved item stack
     */
    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack itemstack = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        
        if (slot != null && slot.hasItem()) {
            ItemStack slotItem = slot.getItem();
            itemstack = slotItem.copy();
            
            if (index < INV_SLOT_START) {
                // Move from stone slots to inventory
                if (!this.moveItemStackTo(slotItem, INV_SLOT_START, USE_ROW_SLOT_END, true)) {
                    return ItemStack.EMPTY;
                }
            } else if (slotItem.getItem() instanceof InfinityStoneItem stoneItem) {
                // Move from inventory to appropriate stone slot
                int stoneSlot = stoneItem.getStoneType().ordinal();
                
                if (!this.moveItemStackTo(slotItem, stoneSlot, stoneSlot + 1, false)) {
                    return ItemStack.EMPTY;
                }
            } else if (index < INV_SLOT_END) {
                // Move from inventory to hotbar
                if (!this.moveItemStackTo(slotItem, USE_ROW_SLOT_START, USE_ROW_SLOT_END, false)) {
                    return ItemStack.EMPTY;
                }
            } else if (index < USE_ROW_SLOT_END) {
                // Move from hotbar to inventory
                if (!this.moveItemStackTo(slotItem, INV_SLOT_START, INV_SLOT_END, false)) {
                    return ItemStack.EMPTY;
                }
            }
            
            if (slotItem.isEmpty()) {
                slot.set(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
            
            if (slotItem.getCount() == itemstack.getCount()) {
                return ItemStack.EMPTY;
            }
            
            slot.onTake(player, slotItem);
        }
        
        return itemstack;
    }
    
    /**
     * Gets whether the menu has stones
     * 
     * @return True if the menu has stones
     */
    public boolean hasStones() {
        for (int i = 0; i < stoneContainer.getContainerSize(); i++) {
            if (!stoneContainer.getItem(i).isEmpty()) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Gets the stone container
     * 
     * @return The stone container
     */
    public Container getStoneContainer() {
        return stoneContainer;
    }
    
    /**
     * Slot implementation for stone slots
     */
    public static class StoneSlot extends Slot {
        private final StoneType stoneType;
        
        /**
         * Constructs a new stone slot
         * 
         * @param itemHandler The item handler
         * @param index The slot index
         * @param xPosition The x position
         * @param yPosition The y position
         * @param stoneType The stone type for this slot
         */
        public StoneSlot(Container itemHandler, int index, int xPosition, int yPosition, StoneType stoneType) {
            super(itemHandler, index, xPosition, yPosition);
            this.stoneType = stoneType;
        }
        
        /**
         * Checks if an item can be placed in this slot
         * 
         * @param stack The item stack
         * @return True if the item can be placed
         */
        @Override
        public boolean mayPlace(ItemStack stack) {
            if (stack.getItem() instanceof InfinityStoneItem stoneItem) {
                return stoneItem.getStoneType() == stoneType;
            }
            
            return false;
        }
        
        /**
         * Gets the stone type for this slot
         * 
         * @return The stone type
         */
        public StoneType getStoneType() {
            return stoneType;
        }
    }
}