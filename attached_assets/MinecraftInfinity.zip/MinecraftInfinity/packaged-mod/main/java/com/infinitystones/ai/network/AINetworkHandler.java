package com.infinitystones.ai.network;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.ai.AIControlMod;
import com.infinitystones.ai.network.packets.CommandPacket;
import com.infinitystones.ai.network.packets.GameStatePacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.Optional;

/**
 * Handles network communication for AI Control
 */
public class AINetworkHandler {
    // Protocol version
    private static final String PROTOCOL_VERSION = "1";
    
    // Network channel
    public static final SimpleChannel INSTANCE = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(InfinityStonesMod.MOD_ID, "ai_network"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );
    
    // Network message ID counter
    private static int messageID = 0;
    
    /**
     * Initialize the network handler
     */
    public static void init() {
        AIControlMod.LOGGER.info("Initializing AI network handler");
        
        // Register client-to-server messages
        INSTANCE.registerMessage(
                nextID(),
                CommandPacket.class,
                CommandPacket::encode,
                CommandPacket::decode,
                CommandPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER)
        );
        
        // Register server-to-client messages
        INSTANCE.registerMessage(
                nextID(),
                GameStatePacket.class,
                GameStatePacket::encode,
                GameStatePacket::decode,
                GameStatePacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT)
        );
    }
    
    /**
     * Get the next message ID
     * 
     * @return The next message ID
     */
    private static int nextID() {
        return messageID++;
    }
    
    /**
     * Send a packet to all web clients
     * 
     * @param packet The packet to send
     */
    public static void sendToAllWebClients(GameStatePacket packet) {
        try {
            // This will be handled by another mechanism (WebSocket)
            // The WebServerManager will handle sending messages to web clients
            // through Socket.IO instead of Forge's network system
            WebSocketHandler.sendToWebClients(packet);
        } catch (Exception e) {
            AIControlMod.LOGGER.error("Error sending packet to web clients", e);
        }
    }
}