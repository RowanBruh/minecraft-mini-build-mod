package com.infinitystones.ai.network.packets;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Packet for sending game state to web clients
 */
public class GameStatePacket {
    private double x;
    private double y;
    private double z;
    private float health;
    private float maxHealth;
    private String dimension;
    private String biome;
    private String time;
    private String weather;
    private boolean important;
    private String message;
    private String lastCommand;
    private String aiStatus;
    
    /**
     * Default constructor
     */
    public GameStatePacket() {
        this.important = false;
    }
    
    /**
     * Set the position
     * 
     * @param x The x coordinate
     * @param y The y coordinate
     * @param z The z coordinate
     */
    public void setPosition(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    /**
     * Set the health
     * 
     * @param health The health
     * @param maxHealth The maximum health
     */
    public void setHealth(float health, float maxHealth) {
        this.health = health;
        this.maxHealth = maxHealth;
    }
    
    /**
     * Set the dimension
     * 
     * @param dimension The dimension
     */
    public void setDimension(String dimension) {
        this.dimension = dimension;
    }
    
    /**
     * Set the biome
     * 
     * @param biome The biome
     */
    public void setBiome(String biome) {
        this.biome = biome;
    }
    
    /**
     * Set the time
     * 
     * @param time The time
     */
    public void setTime(String time) {
        this.time = time;
    }
    
    /**
     * Set the weather
     * 
     * @param weather The weather
     */
    public void setWeather(String weather) {
        this.weather = weather;
    }
    
    /**
     * Set whether this update is important
     * 
     * @param important Whether this update is important
     */
    public void setImportant(boolean important) {
        this.important = important;
    }
    
    /**
     * Set the message
     * 
     * @param message The message
     */
    public void setMessage(String message) {
        this.message = message;
    }
    
    /**
     * Set the last command
     * 
     * @param lastCommand The last command
     */
    public void setLastCommand(String lastCommand) {
        this.lastCommand = lastCommand;
    }
    
    /**
     * Set the AI status
     * 
     * @param aiStatus The AI status
     */
    public void setAiStatus(String aiStatus) {
        this.aiStatus = aiStatus;
    }
    
    /**
     * Encode the packet
     * 
     * @param buf The buffer
     */
    public void encode(FriendlyByteBuf buf) {
        buf.writeDouble(x);
        buf.writeDouble(y);
        buf.writeDouble(z);
        buf.writeFloat(health);
        buf.writeFloat(maxHealth);
        buf.writeUtf(dimension != null ? dimension : "");
        buf.writeUtf(biome != null ? biome : "");
        buf.writeUtf(time != null ? time : "");
        buf.writeUtf(weather != null ? weather : "");
        buf.writeBoolean(important);
        buf.writeUtf(message != null ? message : "");
        buf.writeUtf(lastCommand != null ? lastCommand : "");
        buf.writeUtf(aiStatus != null ? aiStatus : "");
    }
    
    /**
     * Decode the packet
     * 
     * @param buf The buffer
     * @return The packet
     */
    public static GameStatePacket decode(FriendlyByteBuf buf) {
        GameStatePacket packet = new GameStatePacket();
        packet.x = buf.readDouble();
        packet.y = buf.readDouble();
        packet.z = buf.readDouble();
        packet.health = buf.readFloat();
        packet.maxHealth = buf.readFloat();
        packet.dimension = buf.readUtf();
        packet.biome = buf.readUtf();
        packet.time = buf.readUtf();
        packet.weather = buf.readUtf();
        packet.important = buf.readBoolean();
        packet.message = buf.readUtf();
        packet.lastCommand = buf.readUtf();
        packet.aiStatus = buf.readUtf();
        return packet;
    }
    
    /**
     * Handle the packet
     * 
     * @param context The context
     * @return void
     */
    public void handle(Supplier<NetworkEvent.Context> context) {
        context.get().enqueueWork(() -> {
            // This is only needed for client-side handling
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> handleClient());
        });
        context.get().setPacketHandled(true);
    }
    
    /**
     * Handle the packet on the client
     */
    private void handleClient() {
        // Client-side handling if needed
    }
    
    /**
     * Serialize the packet to a map
     * 
     * @return The serialized map
     */
    public Map<String, Object> serialize() {
        Map<String, Object> map = new HashMap<>();
        
        // Add position
        Map<String, Double> position = new HashMap<>();
        position.put("x", x);
        position.put("y", y);
        position.put("z", z);
        map.put("position", position);
        
        // Add health
        map.put("health", health);
        map.put("maxHealth", maxHealth);
        
        // Add other properties
        map.put("dimension", dimension);
        map.put("biome", biome);
        map.put("time", time);
        map.put("weather", weather);
        map.put("important", important);
        
        // Add optional properties
        if (message != null && !message.isEmpty()) {
            map.put("message", message);
        }
        if (lastCommand != null && !lastCommand.isEmpty()) {
            map.put("lastCommand", lastCommand);
        }
        if (aiStatus != null && !aiStatus.isEmpty()) {
            map.put("aiStatus", aiStatus);
        }
        
        return map;
    }
}