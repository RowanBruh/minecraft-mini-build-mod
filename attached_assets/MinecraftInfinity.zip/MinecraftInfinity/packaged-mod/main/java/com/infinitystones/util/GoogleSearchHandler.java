package com.infinitystones.util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.infinitystones.config.ModConfig;
import com.infinitystones.network.ModPackets;
import com.infinitystones.network.packets.GoogleSearchResultsS2CPacket;
import net.minecraft.server.level.ServerPlayer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Handler for Google Search API functionality
 */
public class GoogleSearchHandler {
    private static final String API_BASE_URL = "https://www.googleapis.com/customsearch/v1";
    private static final String SEARCH_ENGINE_ID = "000888210889775888983:pqb3ch1ekg4"; // Example ID
    
    /**
     * Performs a Google search and sends the results to the player
     * 
     * @param searchQuery The search query
     * @param player The player who initiated the search
     */
    public static void performSearch(String searchQuery, ServerPlayer player) {
        // Get the API key from config
        String apiKey = ModConfig.COMMON.googleApiKey.get();
        
        // Check if the API key is set
        if (apiKey == null || apiKey.isEmpty()) {
            sendErrorToPlayer(player, "API key missing", true, false);
            return;
        }
        
        // Perform the search asynchronously
        CompletableFuture.runAsync(() -> {
            try {
                // Build the search URL
                String encodedQuery = URLEncoder.encode(searchQuery, StandardCharsets.UTF_8);
                String urlString = String.format("%s?key=%s&cx=%s&q=%s", 
                        API_BASE_URL, apiKey, SEARCH_ENGINE_ID, encodedQuery);
                
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                
                // Get the response
                int responseCode = connection.getResponseCode();
                if (responseCode == 200) {
                    // Parse the results
                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    in.close();
                    
                    // Process the JSON response
                    List<String> results = processResults(response.toString());
                    
                    // Send the results to the player
                    ModPackets.sendToPlayer(
                            new GoogleSearchResultsS2CPacket(results, false, false, false), 
                            player);
                } else if (responseCode == 403) {
                    // Check if it's a rate limit issue
                    sendErrorToPlayer(player, "Rate limit exceeded", false, true);
                } else {
                    // Generic error
                    sendErrorToPlayer(player, "Search failed", true, false);
                }
            } catch (IOException e) {
                sendErrorToPlayer(player, "Connection error: " + e.getMessage(), true, false);
            } catch (Exception e) {
                sendErrorToPlayer(player, "Error: " + e.getMessage(), true, false);
            }
        });
    }
    
    /**
     * Processes the JSON response from the Google API
     * 
     * @param jsonResponse The JSON response
     * @return A list of formatted search result strings
     */
    private static List<String> processResults(String jsonResponse) {
        List<String> results = new ArrayList<>();
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(jsonResponse, JsonObject.class);
        
        if (jsonObject.has("items")) {
            JsonArray items = jsonObject.getAsJsonArray("items");
            for (JsonElement item : items) {
                JsonObject resultItem = item.getAsJsonObject();
                
                // Get the title and snippet
                String title = resultItem.has("title") ? resultItem.get("title").getAsString() : "No title";
                String snippet = resultItem.has("snippet") ? resultItem.get("snippet").getAsString() : "No description";
                String link = resultItem.has("link") ? resultItem.get("link").getAsString() : "";
                
                // Format the result
                String formattedResult = String.format("§6%s§r\n%s\n§9%s§r", title, snippet, link);
                results.add(formattedResult);
            }
        }
        
        // If no results, add a message
        if (results.isEmpty()) {
            results.add("§cNo results found for your search query.");
        }
        
        return results;
    }
    
    /**
     * Sends an error message to the player
     * 
     * @param player The player
     * @param errorMessage The error message
     * @param searchFailed Whether the search failed generally
     * @param rateLimitReached Whether the rate limit was reached
     */
    private static void sendErrorToPlayer(ServerPlayer player, String errorMessage, 
                                         boolean searchFailed, boolean rateLimitReached) {
        List<String> errorList = new ArrayList<>();
        errorList.add("§cError: " + errorMessage);
        
        ModPackets.sendToPlayer(
                new GoogleSearchResultsS2CPacket(errorList, searchFailed, 
                                               ModConfig.COMMON.googleApiKey.get().isEmpty(), 
                                               rateLimitReached), 
                player);
    }
}