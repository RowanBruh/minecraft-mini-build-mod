package com.infinitystones.client;

import com.infinitystones.InfinityStonesMod;
import com.infinitystones.menu.GoogleComputerMenu;
import com.infinitystones.network.ModPackets;
import com.infinitystones.network.packets.GoogleSearchC2SPacket;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.MultiLineLabel;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/**
 * Screen implementation for the Google Computer
 */
public class GoogleComputerScreen extends AbstractContainerScreen<GoogleComputerMenu> {
    private static final ResourceLocation TEXTURE = 
            new ResourceLocation(InfinityStonesMod.MOD_ID, "textures/gui/google_computer.png");
    
    // UI components
    private EditBox searchBox;
    private Button searchButton;
    private List<String> searchResults = new ArrayList<>();
    private boolean searchFailed = false;
    private boolean apiKeyMissing = false;
    private boolean rateLimitReached = false;
    
    // Scrolling
    private int scrollOffset = 0;
    private static final int MAX_RESULTS_SHOWN = 5;
    
    public GoogleComputerScreen(GoogleComputerMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        
        // Adjust the size of the screen
        this.imageWidth = 256;
        this.imageHeight = 210;
    }
    
    @Override
    protected void init() {
        super.init();
        
        // Add the search box
        int x = this.leftPos + 20;
        int y = this.topPos + 20;
        this.searchBox = new EditBox(this.font, x, y, 160, 20, Component.translatable("container.infinitystones.google_computer.search"));
        this.searchBox.setMaxLength(100);
        this.searchBox.setValue(this.menu.getSearchQuery());
        this.searchBox.setResponder(s -> this.menu.setSearchQuery(s));
        addRenderableWidget(this.searchBox);
        
        // Add the search button
        this.searchButton = Button.builder(Component.translatable("container.infinitystones.google_computer.search_button"), this::onSearchButtonPressed)
                .pos(x + 165, y)
                .size(50, 20)
                .build();
        addRenderableWidget(this.searchButton);
        
        // Add scroll buttons
        Button scrollUpButton = Button.builder(Component.literal("▲"), this::onScrollUp)
                .pos(this.leftPos + 230, this.topPos + 50)
                .size(20, 20)
                .build();
        addRenderableWidget(scrollUpButton);
        
        Button scrollDownButton = Button.builder(Component.literal("▼"), this::onScrollDown)
                .pos(this.leftPos + 230, this.topPos + 150)
                .size(20, 20)
                .build();
        addRenderableWidget(scrollDownButton);
        
        // Set initial focus to the search box
        setInitialFocus(this.searchBox);
    }
    
    /**
     * Handler for search button clicks
     */
    private void onSearchButtonPressed(Button button) {
        String query = searchBox.getValue().trim();
        if (!query.isEmpty()) {
            // Send search query to the server
            ModPackets.sendToServer(new GoogleSearchC2SPacket(query, this.menu.getBlockEntity().getBlockPos()));
        }
    }
    
    /**
     * Handler for scroll up button
     */
    private void onScrollUp(Button button) {
        if (scrollOffset > 0) {
            scrollOffset--;
        }
    }
    
    /**
     * Handler for scroll down button
     */
    private void onScrollDown(Button button) {
        if (scrollOffset < Math.max(0, searchResults.size() - MAX_RESULTS_SHOWN)) {
            scrollOffset++;
        }
    }
    
    /**
     * Updates the search results display
     * 
     * @param results The search results
     * @param searchFailed Whether the search failed
     * @param apiKeyMissing Whether the API key is missing
     * @param rateLimitReached Whether the rate limit was reached
     */
    public void updateSearchResults(List<String> results, boolean searchFailed, 
                                   boolean apiKeyMissing, boolean rateLimitReached) {
        this.searchResults = new ArrayList<>(results);
        this.searchFailed = searchFailed;
        this.apiKeyMissing = apiKeyMissing;
        this.rateLimitReached = rateLimitReached;
        this.scrollOffset = 0;
    }
    
    @Override
    public void render(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(guiGraphics);
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        renderTooltip(guiGraphics, mouseX, mouseY);
        
        // Render search results or error messages
        int x = this.leftPos + 20;
        int y = this.topPos + 50;
        
        if (apiKeyMissing) {
            // API key missing error
            MultiLineLabel message = MultiLineLabel.create(font, 
                    List.of(Component.translatable("container.infinitystones.google_computer.api_key_missing")));
            message.renderCentered(guiGraphics, this.leftPos + this.imageWidth / 2, y);
        } else if (rateLimitReached) {
            // Rate limit error
            MultiLineLabel message = MultiLineLabel.create(font, 
                    List.of(Component.translatable("container.infinitystones.google_computer.rate_limit")));
            message.renderCentered(guiGraphics, this.leftPos + this.imageWidth / 2, y);
        } else if (searchFailed) {
            // General search failure
            MultiLineLabel message = MultiLineLabel.create(font, 
                    List.of(Component.translatable("container.infinitystones.google_computer.search_failed")));
            message.renderCentered(guiGraphics, this.leftPos + this.imageWidth / 2, y);
        } else if (searchResults.isEmpty()) {
            // No results yet
            MultiLineLabel message = MultiLineLabel.create(font, 
                    List.of(Component.translatable("container.infinitystones.google_computer.no_results")));
            message.renderCentered(guiGraphics, this.leftPos + this.imageWidth / 2, y);
        } else {
            // Show search results
            int displayedResults = Math.min(MAX_RESULTS_SHOWN, searchResults.size() - scrollOffset);
            for (int i = 0; i < displayedResults; i++) {
                String result = searchResults.get(i + scrollOffset);
                MultiLineLabel resultLabel = MultiLineLabel.create(font, Component.literal(result), 200);
                resultLabel.renderLeftAligned(guiGraphics, x, y + (i * 25), 9, 0xFFFFFF);
            }
        }
    }
    
    @Override
    protected void renderBg(@NotNull GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, TEXTURE);
        
        int x = this.leftPos;
        int y = this.topPos;
        guiGraphics.blit(TEXTURE, x, y, 0, 0, this.imageWidth, this.imageHeight);
    }
    
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.searchBox.isFocused() && keyCode == 257) { // Enter key
            onSearchButtonPressed(this.searchButton);
            return true;
        }
        
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}