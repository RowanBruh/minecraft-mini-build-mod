# AI Control Mod for Minecraft

This mod adds AI-controlled entities to Minecraft and provides a web interface for remote control and voice communication.

## Features

- Spawn AI-controlled entities in-game with the `/SpawnAI` command
- Web interface for remotely controlling AI entities
- User authentication with admin privileges
- AI-powered interactions using OpenAI's API
- Voice communication capabilities
- Update mechanism for pushing code changes directly through the web interface

## Getting Started

1. Install the mod in your Minecraft Forge server
2. Execute the `/SpawnAI` command in-game
3. Follow the link to access the web interface
4. Log in with default credentials:
   - Username: `admin`
   - Password: `admin`
   - (Be sure to change these after first login)

## For Developers

This mod consists of two main components:

1. **Minecraft Mod**: Written in Java using the Forge API
2. **Web Server**: Node.js with Express, Socket.io, and OpenAI integration

### Project Structure

- `src/main/java/com/aicontrol/`: Main mod code
  - `AIControlMod.java`: Entry point for the mod
  - `commands/`: Command implementations
  - `entity/`: AI entity implementation
  - `network/`: Network packets for communication
  - `server/`: Web server management
- `web-server/`: Web interface and server code
  - `server.js`: Main server code
  - `models/`: Database and user models
  - `routes/`: API endpoints
  - `public/`: Frontend assets
  - `middleware/`: Authentication middleware

## Configuration

### OpenAI API Key

To use the AI functionality, you need to set your OpenAI API key:

```
export OPENAI_API_KEY=your_api_key_here
```

### Admin Key

To register new admin users, use the admin key:

```
export ADMIN_KEY=minecraft-admin-key
```

## License

All Rights Reserved

---

*Created with love for Minecraft AI enthusiasts*